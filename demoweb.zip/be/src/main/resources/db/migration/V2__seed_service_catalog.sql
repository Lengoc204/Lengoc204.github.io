INSERT IGNORE INTO service_categories (id, name, description, icon, created_at)
VALUES
  (UUID_TO_BIN('0f7f5e60-6aa7-4e0d-8a6c-5c38b40e8d10'), 'Home Services', 'Dịch vụ vệ sinh tại nhà', NULL, CURRENT_TIMESTAMP),
  (UUID_TO_BIN('b5e854c3-b470-41c1-8e3f-d5d5a5bf9cda'), 'Vehicle Care', 'Dịch vụ chăm sóc xe', NULL, CURRENT_TIMESTAMP),
  (UUID_TO_BIN('d3355c35-5c15-4d13-b41e-c1e9a2f84b45'), 'Delivery', 'Vận chuyển và giao nhận', NULL, CURRENT_TIMESTAMP);

INSERT IGNORE INTO cleaning_services (id, category_id, name, description, duration_minutes, base_price, pricing_unit, is_active, created_at)
VALUES
  (UUID_TO_BIN('d9f6cd2f-6a7b-4903-9fa7-91c9a2c85371'), UUID_TO_BIN('0f7f5e60-6aa7-4e0d-8a6c-5c38b40e8d10'),
   'Home Cleaning', 'Dọn dẹp và vệ sinh nhà ở/ căn hộ', 180, 350000, 'PER_VISIT', TRUE, CURRENT_TIMESTAMP),
  (UUID_TO_BIN('8f2a4afb-4f71-4f79-8be4-4fc4b7a9e2f2'), UUID_TO_BIN('d3355c35-5c15-4d13-b41e-c1e9a2f84b45'),
   'Package Delivery', 'Giao nhận hàng hoá/ tài liệu nội thành', 90, 250000, 'PER_VISIT', TRUE, CURRENT_TIMESTAMP),
  (UUID_TO_BIN('a72b0b52-0d3f-423e-b4c2-bcb585c5f2a6'), UUID_TO_BIN('b5e854c3-b470-41c1-8e3f-d5d5a5bf9cda'),
   'Car Wash', 'Rửa xe tại nhà hoặc bãi xe', 120, 220000, 'PER_VISIT', TRUE, CURRENT_TIMESTAMP);
