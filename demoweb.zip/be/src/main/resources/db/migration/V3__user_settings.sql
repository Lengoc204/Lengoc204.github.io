CREATE TABLE IF NOT EXISTS user_payment_methods (
    id BINARY(16) NOT NULL,
    user_id BINARY(16) NOT NULL,
    method VARCHAR(30) NOT NULL,
    display_name VARCHAR(120),
    provider VARCHAR(120),
    masked_number VARCHAR(40),
    is_default TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_user_payment_methods_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_login_events (
    id BINARY(16) NOT NULL,
    user_id BINARY(16) NOT NULL,
    login_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    ip_address VARCHAR(64),
    user_agent VARCHAR(255),
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_user_login_events_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_user_payment_methods_user ON user_payment_methods (user_id);
CREATE INDEX idx_user_login_events_user ON user_login_events (user_id, login_at);
