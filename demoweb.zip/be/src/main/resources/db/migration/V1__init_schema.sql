CREATE DATABASE if not exists cleaning_home CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
use cleaning_home;

CREATE TABLE IF NOT EXISTS users (
    id BINARY(16) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    role VARCHAR(20) NOT NULL DEFAULT 'CUSTOMER',
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    avatar_url VARCHAR(255),
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS addresses (
    id BINARY(16) NOT NULL,
    user_id BINARY(16) NOT NULL,
    label VARCHAR(50),
    street TEXT NOT NULL,
    ward VARCHAR(120),
    district VARCHAR(120),
    city VARCHAR(120),
    province VARCHAR(120),
    latitude DOUBLE,
    longitude DOUBLE,
    is_default TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_addresses_users FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS cleaner_profiles (
    id BINARY(16) NOT NULL,
    user_id BINARY(16) NOT NULL UNIQUE,
    bio VARCHAR(500),
    years_experience INT,
    hourly_rate DECIMAL(12,2),
    rating_avg DOUBLE,
    completed_jobs INT,
    service_area VARCHAR(255),
    verification_status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_cleaner_profiles_users FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS cleaner_availabilities (
    id BINARY(16) NOT NULL,
    cleaner_id BINARY(16) NOT NULL,
    weekday VARCHAR(15) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_cleaner_availabilities_profiles FOREIGN KEY (cleaner_id) REFERENCES cleaner_profiles(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Service catalog
CREATE TABLE IF NOT EXISTS service_categories (
    id BINARY(16) NOT NULL,
    name VARCHAR(120) NOT NULL UNIQUE,
    description VARCHAR(500),
    icon VARCHAR(255),
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS cleaning_services (
    id BINARY(16) NOT NULL,
    category_id BINARY(16) NOT NULL,
    name VARCHAR(150) NOT NULL,
    description VARCHAR(500),
    duration_minutes INT,
    base_price DECIMAL(12,2) NOT NULL,
    pricing_unit VARCHAR(30) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_cleaning_services_categories FOREIGN KEY (category_id) REFERENCES service_categories(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS service_addons (
    id BINARY(16) NOT NULL,
    service_id BINARY(16) NOT NULL,
    name VARCHAR(150) NOT NULL,
    description VARCHAR(500),
    price_delta DECIMAL(12,2) NOT NULL,
    is_required TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_service_addons_services FOREIGN KEY (service_id) REFERENCES cleaning_services(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Booking lifecycle
CREATE TABLE IF NOT EXISTS bookings (
    id BINARY(16) NOT NULL,
    customer_id BINARY(16) NOT NULL,
    service_id BINARY(16) NOT NULL,
    address_id BINARY(16) NOT NULL,
    scheduled_start TIMESTAMP(6) NOT NULL,
    scheduled_end TIMESTAMP(6),
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    total_price DECIMAL(12,2) NOT NULL,
    notes VARCHAR(1000),
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_bookings_users FOREIGN KEY (customer_id) REFERENCES users(id),
    CONSTRAINT fk_bookings_services FOREIGN KEY (service_id) REFERENCES cleaning_services(id),
    CONSTRAINT fk_bookings_addresses FOREIGN KEY (address_id) REFERENCES addresses(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS booking_cleaners (
    id BINARY(16) NOT NULL,
    booking_id BINARY(16) NOT NULL,
    cleaner_id BINARY(16) NOT NULL,
    assigned_at TIMESTAMP(6) NOT NULL,
    assignment_status VARCHAR(255) NOT NULL DEFAULT 'ASSIGNED',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_booking_cleaners_booking FOREIGN KEY (booking_id) REFERENCES bookings(id),
    CONSTRAINT fk_booking_cleaners_cleaner FOREIGN KEY (cleaner_id) REFERENCES cleaner_profiles(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE UNIQUE INDEX uq_booking_cleaner_pair
    ON booking_cleaners (booking_id, cleaner_id);

CREATE TABLE IF NOT EXISTS payments (
    id BINARY(16) NOT NULL,
    booking_id BINARY(16) NOT NULL UNIQUE,
    amount DECIMAL(12,2) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'VND',
    transaction_ref VARCHAR(120),
    method VARCHAR(30) NOT NULL,
    status VARCHAR(20) NOT NULL,
    paid_at TIMESTAMP(6),
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_payments_bookings FOREIGN KEY (booking_id) REFERENCES bookings(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Refresh tokens
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id BINARY(16) NOT NULL,
    user_id BINARY(16) NOT NULL,
    token VARCHAR(512) NOT NULL UNIQUE,
    expires_at TIMESTAMP(6) NOT NULL,
    revoked_at TIMESTAMP(6),
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_refresh_tokens_users FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE UNIQUE INDEX uq_refresh_tokens_user
    ON refresh_tokens (user_id);

-- Helpful indexes
CREATE INDEX idx_users_email ON users (email);
CREATE INDEX idx_bookings_status ON bookings (status);
CREATE INDEX idx_cleaner_availability_weekday
    ON cleaner_availabilities (cleaner_id, weekday);
