package com.example.cleaning_be.report.dto;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class AdminDashboardSummaryResponse {
  private long totalBookings;
  private long pendingBookings;
  private long activeStaff;
  private long totalStaff;
  private long activeCustomers;
  private long totalCustomers;
}
