package com.example.cleaning_be.auth.token;

import com.example.cleaning_be.common.exception.ErrorCode;
import com.example.cleaning_be.common.exception.UnauthorizedException;
import com.example.cleaning_be.config.JwtProperties;
import com.example.cleaning_be.user.entity.User;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class RefreshTokenService {

  private final RefreshTokenRepository refreshTokenRepository;
  private final JwtProperties jwtProperties;

  @Transactional
  public String createRefreshToken(User user) {
    String token = UUID.randomUUID() + "." + UUID.randomUUID();
    Instant expiresAt =
        Instant.now().plus(jwtProperties.refreshTokenExpirationDays(), ChronoUnit.DAYS);
    RefreshToken entity =
        refreshTokenRepository
            .findByUserId(user.getId())
            .map(
                existing -> {
                  existing.setToken(token);
                  existing.setExpiresAt(expiresAt);
                  existing.setRevokedAt(null);
                  return existing;
                })
            .orElseGet(() -> new RefreshToken(user, token, expiresAt));
    refreshTokenRepository.save(entity);
    return token;
  }

  public RefreshToken validateToken(String token) {
    RefreshToken refreshToken =
        refreshTokenRepository
            .findByToken(token)
            .orElseThrow(() -> new UnauthorizedException(ErrorCode.TOKEN_INVALID));
    if (!refreshToken.isActive()) {
      throw new UnauthorizedException(ErrorCode.TOKEN_INVALID);
    }
    return refreshToken;
  }

  @Transactional
  public void revoke(RefreshToken refreshToken) {
    refreshToken.setRevokedAt(Instant.now());
    refreshTokenRepository.save(refreshToken);
  }

  @Transactional
  public void revokeAllForUser(UUID userId) {
    refreshTokenRepository.deleteByUserId(userId);
  }
}
