package com.example.cleaning_be.user.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateUserProfileRequest {

  @NotBlank(message = "Full name is required")
  private String fullName;

  private String phone;

  private String avatarUrl;
}

