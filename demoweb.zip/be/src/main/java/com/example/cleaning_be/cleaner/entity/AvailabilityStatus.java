package com.example.cleaning_be.cleaner.entity;

public enum AvailabilityStatus {
  AVAILABLE,
  UNAVAILABLE
}
