package com.example.cleaning_be.address.dto;

import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class AddressResponse {
  private UUID id;
  private String label;
  private String street;
  private String ward;
  private String district;
  private String city;
  private String province;
  private Double latitude;
  private Double longitude;
  private boolean defaultAddress;
}
