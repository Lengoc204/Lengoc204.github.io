package com.example.cleaning_be.user.controller;

import com.example.cleaning_be.address.dto.AddressRequest;
import com.example.cleaning_be.address.dto.AddressResponse;
import com.example.cleaning_be.payment.dto.PaymentMethodRequest;
import com.example.cleaning_be.payment.dto.PaymentMethodResponse;
import com.example.cleaning_be.user.dto.ChangePasswordRequest;
import com.example.cleaning_be.user.dto.UpdateUserProfileRequest;
import com.example.cleaning_be.user.dto.UpdateUserStatusRequest;
import com.example.cleaning_be.user.dto.UserProfileResponse;
import com.example.cleaning_be.user.service.UserSettingsService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users/{userId}/settings")
@RequiredArgsConstructor
public class UserSettingsController {

  private final UserSettingsService userSettingsService;

  @GetMapping("/profile")
  public ResponseEntity<UserProfileResponse> getProfile(@PathVariable UUID userId) {
    return ResponseEntity.ok(userSettingsService.getProfile(userId));
  }

  @PutMapping("/profile")
  public ResponseEntity<UserProfileResponse> updateProfile(
      @PathVariable UUID userId, @Valid @RequestBody UpdateUserProfileRequest request) {
    return ResponseEntity.ok(userSettingsService.updateProfile(userId, request));
  }

  @PutMapping("/password")
  public ResponseEntity<Void> changePassword(
      @PathVariable UUID userId, @Valid @RequestBody ChangePasswordRequest request) {
    userSettingsService.changePassword(userId, request);
    return ResponseEntity.noContent().build();
  }

  @PutMapping("/status")
  public ResponseEntity<UserProfileResponse> updateStatus(
      @PathVariable UUID userId, @Valid @RequestBody UpdateUserStatusRequest request) {
    return ResponseEntity.ok(userSettingsService.updateStatus(userId, request));
  }

  @GetMapping("/addresses")
  public ResponseEntity<List<AddressResponse>> getAddresses(@PathVariable UUID userId) {
    return ResponseEntity.ok(userSettingsService.getAddresses(userId));
  }

  @PostMapping("/addresses")
  public ResponseEntity<AddressResponse> addAddress(
      @PathVariable UUID userId, @Valid @RequestBody AddressRequest request) {
    return ResponseEntity.ok(userSettingsService.addAddress(userId, request));
  }

  @PutMapping("/addresses/{addressId}")
  public ResponseEntity<AddressResponse> updateAddress(
      @PathVariable UUID userId,
      @PathVariable UUID addressId,
      @Valid @RequestBody AddressRequest request) {
    return ResponseEntity.ok(userSettingsService.updateAddress(userId, addressId, request));
  }

  @DeleteMapping("/addresses/{addressId}")
  public ResponseEntity<Void> deleteAddress(
      @PathVariable UUID userId, @PathVariable UUID addressId) {
    userSettingsService.deleteAddress(userId, addressId);
    return ResponseEntity.noContent().build();
  }

  @GetMapping("/payments")
  public ResponseEntity<List<PaymentMethodResponse>> getPaymentMethods(@PathVariable UUID userId) {
    return ResponseEntity.ok(userSettingsService.getPaymentMethods(userId));
  }

  @PostMapping("/payments")
  public ResponseEntity<PaymentMethodResponse> addPaymentMethod(
      @PathVariable UUID userId, @Valid @RequestBody PaymentMethodRequest request) {
    return ResponseEntity.ok(userSettingsService.addPaymentMethod(userId, request));
  }

  @PutMapping("/payments/{methodId}")
  public ResponseEntity<PaymentMethodResponse> updatePaymentMethod(
      @PathVariable UUID userId,
      @PathVariable UUID methodId,
      @Valid @RequestBody PaymentMethodRequest request) {
    return ResponseEntity.ok(userSettingsService.updatePaymentMethod(userId, methodId, request));
  }

  @DeleteMapping("/payments/{methodId}")
  public ResponseEntity<Void> deletePaymentMethod(
      @PathVariable UUID userId, @PathVariable UUID methodId) {
    userSettingsService.deletePaymentMethod(userId, methodId);
    return ResponseEntity.noContent().build();
  }
}
