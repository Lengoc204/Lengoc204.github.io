package com.example.cleaning_be.booking.dto;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class StaffEarningResponse {
  private UUID bookingId;
  private String code;
  private String serviceName;
  private BigDecimal amount;
  private Instant paidAt;
}

