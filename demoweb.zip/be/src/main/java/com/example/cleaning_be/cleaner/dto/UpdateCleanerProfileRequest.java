package com.example.cleaning_be.cleaner.dto;

import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateCleanerProfileRequest {

  @NotNull private UUID userId;
  private String bio;
  private Integer yearsExperience;
  private BigDecimal hourlyRate;
  private String serviceArea;
}
