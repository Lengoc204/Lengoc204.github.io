package com.example.cleaning_be.servicecatalog.service;

import com.example.cleaning_be.servicecatalog.dto.ServiceResponse;
import com.example.cleaning_be.servicecatalog.repository.CleaningServiceRepository;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ServiceCatalogService {

  private final CleaningServiceRepository cleaningServiceRepository;

  public List<ServiceResponse> getActiveServices() {
    return cleaningServiceRepository.findByActiveTrue().stream()
        .map(
            service ->
                ServiceResponse.builder()
                    .id(service.getId())
                    .name(service.getName())
                    .description(service.getDescription())
                    .durationMinutes(service.getDurationMinutes())
                    .basePrice(service.getBasePrice())
                    .pricingUnit(service.getPricingUnit().name())
                    .build())
        .toList();
  }
}
