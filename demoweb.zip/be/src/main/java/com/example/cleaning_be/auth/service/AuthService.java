package com.example.cleaning_be.auth.service;

import com.example.cleaning_be.auth.dto.JwtResponse;
import com.example.cleaning_be.auth.dto.LoginRequest;
import com.example.cleaning_be.auth.dto.LogoutRequest;
import com.example.cleaning_be.auth.dto.RefreshTokenRequest;
import com.example.cleaning_be.auth.dto.SignupRequest;
import com.example.cleaning_be.auth.token.RefreshTokenService;
import com.example.cleaning_be.common.exception.BadRequestException;
import com.example.cleaning_be.common.exception.ErrorCode;
import com.example.cleaning_be.common.exception.UnauthorizedException;
import com.example.cleaning_be.config.JwtTokenProvider;
import com.example.cleaning_be.mapper.UserMapper;
import com.example.cleaning_be.user.entity.Role;
import com.example.cleaning_be.user.entity.User;
import com.example.cleaning_be.user.entity.UserLoginEvent;
import com.example.cleaning_be.user.repository.UserLoginEventRepository;
import com.example.cleaning_be.user.service.UserService;
import java.time.Instant;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Service
@RequiredArgsConstructor
public class AuthService {

  private final UserService userService;
  private final PasswordEncoder passwordEncoder;
  private final AuthenticationManager authenticationManager;
  private final JwtTokenProvider jwtTokenProvider;
  private final RefreshTokenService refreshTokenService;
  private final UserMapper userMapper;
  private final UserLoginEventRepository userLoginEventRepository;

  @Transactional
  public JwtResponse signup(SignupRequest request) {
    if (userService.emailExists(request.getEmail())) {
      throw new BadRequestException("Email has already been registered");
    }

    Role role = request.getRole() == null ? Role.CUSTOMER : request.getRole();
    if (role != Role.CUSTOMER && role != Role.STAFF && role != Role.ADMIN) {
      throw new BadRequestException("Role must be CUSTOMER, STAFF or ADMIN");
    }

    User user =
        User.builder()
            .email(request.getEmail())
            .fullName(request.getFullName())
            .phone(request.getPhone())
            .passwordHash(passwordEncoder.encode(request.getPassword()))
            .role(role)
            .build();

    if (request.getDefaultAddress() != null) {
      var address = userMapper.toAddress(request.getDefaultAddress());
      user.addAddress(address);
    }

    User persisted = userService.save(user);
    return buildTokenResponse(persisted);
  }

  @Transactional
  public JwtResponse login(LoginRequest request) {
    Authentication authentication =
        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                request.getEmail(), request.getPassword()));
    User user = userService.getByEmail(authentication.getName());
    recordLoginEvent(user);
    return buildTokenResponse(user);
  }

  @Transactional
  public JwtResponse refresh(RefreshTokenRequest request) {
    var refreshToken = refreshTokenService.validateToken(request.getRefreshToken());
    User user = refreshToken.getUser();
    String accessToken = jwtTokenProvider.generateAccessToken(user);
    String newRefreshToken = refreshTokenService.createRefreshToken(user);
    return JwtResponse.builder()
        .accessToken(accessToken)
        .refreshToken(newRefreshToken)
        .user(userMapper.toProfile(user))
        .build();
  }

  @Transactional
  public void logout(LogoutRequest request, String currentUserEmail) {
    var refreshToken = refreshTokenService.validateToken(request.getRefreshToken());
    if (!refreshToken.getUser().getEmail().equalsIgnoreCase(currentUserEmail)) {
      throw new UnauthorizedException(ErrorCode.TOKEN_INVALID);
    }
    refreshTokenService.revoke(refreshToken);
  }

  private JwtResponse buildTokenResponse(User user) {
    String accessToken = jwtTokenProvider.generateAccessToken(user);
    String refreshToken = refreshTokenService.createRefreshToken(user);
    return JwtResponse.builder()
        .accessToken(accessToken)
        .refreshToken(refreshToken)
        .user(userMapper.toProfile(user))
        .build();
  }

  private void recordLoginEvent(User user) {
    ServletRequestAttributes attributes =
        (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
    String ip =
        attributes != null && attributes.getRequest() != null
            ? attributes.getRequest().getRemoteAddr()
            : "UNKNOWN";
    String userAgent =
        attributes != null && attributes.getRequest() != null
            ? attributes.getRequest().getHeader("User-Agent")
            : "UNKNOWN";
    userLoginEventRepository.save(
        UserLoginEvent.builder()
            .user(user)
            .loginAt(Instant.now())
            .ipAddress(ip)
            .userAgent(userAgent)
            .build());
  }
}
