package com.example.cleaning_be.mapper;

import com.example.cleaning_be.address.dto.AddressRequest;
import com.example.cleaning_be.address.dto.AddressResponse;
import com.example.cleaning_be.address.entity.Address;
import com.example.cleaning_be.user.dto.UserProfileResponse;
import com.example.cleaning_be.user.entity.User;
import java.util.List;
import java.util.Set;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface UserMapper {

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "user", ignore = true)
  Address toAddress(AddressRequest request);

  @Mapping(target = "addresses", expression = "java(mapAddresses(user.getAddresses()))")
  UserProfileResponse toProfile(User user);

  default List<AddressResponse> mapAddresses(Set<Address> addresses) {
    return addresses == null
        ? List.of()
        : addresses.stream()
            .map(
                address ->
                AddressResponse.builder()
                    .id(address.getId())
                    .label(address.getLabel())
                    .street(address.getStreet())
                        .ward(address.getWard())
                        .district(address.getDistrict())
                        .city(address.getCity())
                        .province(address.getProvince())
                        .latitude(address.getLatitude())
                    .longitude(address.getLongitude())
                    .defaultAddress(address.isDefaultAddress())
                        .build())
            .toList();
  }
}
