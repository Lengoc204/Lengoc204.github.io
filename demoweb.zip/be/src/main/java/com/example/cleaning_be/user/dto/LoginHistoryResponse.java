package com.example.cleaning_be.user.dto;

import java.time.Instant;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class LoginHistoryResponse {
  private Instant loginAt;
  private String ipAddress;
  private String userAgent;
}

