package com.example.cleaning_be.payment.service;

import com.example.cleaning_be.booking.entity.Booking;
import com.example.cleaning_be.booking.entity.BookingStatus;
import com.example.cleaning_be.booking.repository.BookingRepository;
import com.example.cleaning_be.common.exception.BusinessException;
import com.example.cleaning_be.common.exception.ErrorCode;
import com.example.cleaning_be.common.exception.ResourceNotFoundException;
import com.example.cleaning_be.payment.dto.MockPaymentRequest;
import com.example.cleaning_be.payment.dto.PaymentResponse;
import com.example.cleaning_be.payment.entity.Payment;
import com.example.cleaning_be.payment.entity.PaymentStatus;
import com.example.cleaning_be.payment.repository.PaymentRepository;
import java.time.Instant;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PaymentCommandService {

  private final BookingRepository bookingRepository;
  private final PaymentRepository paymentRepository;

  @Transactional
  public PaymentResponse mockPayment(UUID bookingId, MockPaymentRequest request) {
    Booking booking =
        bookingRepository
            .findById(bookingId)
            .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.BOOKING_NOT_FOUND));

    if (booking.getCustomer() == null
        || !booking.getCustomer().getId().equals(request.getCustomerId())) {
      throw new BusinessException(
          ErrorCode.BAD_REQUEST, "Bạn không thể thanh toán cho đơn hàng của người khác.");
    }

    if (booking.getStatus() != BookingStatus.COMPLETED) {
      throw new BusinessException(
          ErrorCode.BAD_REQUEST, "Chỉ có thể thanh toán khi đơn đã hoàn thành.");
    }

    Payment payment =
        paymentRepository
            .findByBookingId(booking.getId())
            .orElse(
                Payment.builder()
                    .booking(booking)
                    .amount(booking.getTotalPrice())
                    .currency("VND")
                    .build());

    payment.setMethod(request.getMethod());
    payment.setStatus(PaymentStatus.PAID);
    payment.setPaidAt(Instant.now());
    payment.setAmount(booking.getTotalPrice());
    payment.setCurrency("VND");

    Payment saved = paymentRepository.save(payment);

    return PaymentResponse.builder()
        .paymentId(saved.getId())
        .bookingId(booking.getId())
        .amount(saved.getAmount())
        .currency(saved.getCurrency())
        .method(saved.getMethod())
        .status(saved.getStatus())
        .paidAt(saved.getPaidAt())
        .build();
  }
}
