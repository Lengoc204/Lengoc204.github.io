package com.example.cleaning_be.config;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Validated
@ConfigurationProperties(prefix = "security.jwt")
public record JwtProperties(
    @NotBlank String issuer,
    @NotBlank String secret,
    @NotNull @Positive Integer accessTokenExpirationMinutes,
    @NotNull @Positive Integer refreshTokenExpirationDays) {}
