package com.example.cleaning_be.cleaner.entity;

public enum VerificationStatus {
  PENDING,
  APPROVED,
  REJECTED
}
