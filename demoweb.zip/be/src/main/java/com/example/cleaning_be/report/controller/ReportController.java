package com.example.cleaning_be.report.controller;

import com.example.cleaning_be.report.dto.AdminDashboardSummaryResponse;
import com.example.cleaning_be.report.dto.BookingPipelineItemResponse;
import com.example.cleaning_be.report.dto.MonthlyRevenueResponse;
import com.example.cleaning_be.report.service.RevenueReportService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/reports")
@RequiredArgsConstructor
public class ReportController {

  private final RevenueReportService revenueReportService;

  @GetMapping("/revenue/monthly")
  public ResponseEntity<List<MonthlyRevenueResponse>> getMonthlyRevenue(
      @RequestParam(value = "months", defaultValue = "6") int months) {
    return ResponseEntity.ok(revenueReportService.getMonthlyRevenue(months));
  }

  @GetMapping("/admin/summary")
  public ResponseEntity<AdminDashboardSummaryResponse> getAdminSummary() {
    return ResponseEntity.ok(revenueReportService.getDashboardSummary());
  }

  @GetMapping("/admin/pipeline")
  public ResponseEntity<List<BookingPipelineItemResponse>> getPipeline(
      @RequestParam(value = "count", defaultValue = "5") int count) {
    return ResponseEntity.ok(revenueReportService.getRecentBookings(count));
  }

  @GetMapping("/admin/featured")
  public ResponseEntity<BookingPipelineItemResponse> getFeaturedBooking() {
    return ResponseEntity.ok(revenueReportService.getTopBooking());
  }
}
