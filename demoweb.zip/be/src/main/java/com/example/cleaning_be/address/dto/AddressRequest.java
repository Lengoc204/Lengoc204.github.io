package com.example.cleaning_be.address.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class AddressRequest {

  private String label;

  @NotBlank(message = "Street is required")
  private String street;

  private String ward;
  private String district;
  private String city;
  private String province;
  private Double latitude;
  private Double longitude;
  private boolean defaultAddress;
}
