package com.example.cleaning_be.booking.dto;

import com.example.cleaning_be.booking.entity.BookingStatus;
import com.example.cleaning_be.payment.entity.PaymentStatus;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class CustomerPaymentItemResponse {
  private UUID bookingId;
  private String code;
  private String serviceName;
  private OffsetDateTime scheduledDate;
  private BookingStatus bookingStatus;
  private BigDecimal totalPrice;
  private PaymentStatus paymentStatus;
  private UUID paymentId;
}

