package com.example.cleaning_be.user.dto;

import com.example.cleaning_be.user.entity.Role;
import com.example.cleaning_be.user.entity.UserStatus;
import java.time.Instant;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class UserSummaryResponse {
  private UUID id;
  private String fullName;
  private String email;
  private String phone;
  private Role role;
  private UserStatus status;
  private Instant createdAt;
}
