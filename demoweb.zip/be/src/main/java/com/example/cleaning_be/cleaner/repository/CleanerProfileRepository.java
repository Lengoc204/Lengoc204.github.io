package com.example.cleaning_be.cleaner.repository;

import com.example.cleaning_be.cleaner.entity.CleanerProfile;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CleanerProfileRepository extends JpaRepository<CleanerProfile, UUID> {
  Optional<CleanerProfile> findByUserId(UUID userId);
}
