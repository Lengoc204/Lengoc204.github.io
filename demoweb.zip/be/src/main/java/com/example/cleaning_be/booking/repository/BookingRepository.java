package com.example.cleaning_be.booking.repository;

import com.example.cleaning_be.booking.entity.Booking;
import com.example.cleaning_be.booking.entity.BookingStatus;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Booking, UUID> {
  List<Booking> findByCustomerId(UUID customerId);

  List<Booking> findByStatus(BookingStatus status);

  boolean existsByAddressId(UUID addressId);

  long countByStatus(BookingStatus status);

  List<Booking> findAllByOrderByCreatedAtDesc(Pageable pageable);

  List<Booking> findAllByOrderByTotalPriceDesc(Pageable pageable);
}
