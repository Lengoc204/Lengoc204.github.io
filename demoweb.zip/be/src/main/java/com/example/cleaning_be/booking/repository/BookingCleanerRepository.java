package com.example.cleaning_be.booking.repository;

import com.example.cleaning_be.booking.entity.AssignmentStatus;
import com.example.cleaning_be.booking.entity.BookingCleaner;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface BookingCleanerRepository extends JpaRepository<BookingCleaner, UUID> {
  List<BookingCleaner> findByCleanerId(UUID cleanerId);

  List<BookingCleaner> findByCleanerIdAndAssignmentStatus(
      UUID cleanerId, AssignmentStatus assignmentStatus);

  Optional<BookingCleaner> findTopByBookingIdAndCleanerIdOrderByCreatedAtDesc(
      UUID bookingId, UUID cleanerId);

  @Query(
      """
      SELECT bc
      FROM BookingCleaner bc
      WHERE bc.booking.id = :bookingId
        AND bc.cleaner.user.id = :staffUserId
      ORDER BY bc.createdAt DESC
      """)
  Optional<BookingCleaner> findLatestByBookingAndStaffUser(
      @Param("bookingId") UUID bookingId, @Param("staffUserId") UUID staffUserId);
}
