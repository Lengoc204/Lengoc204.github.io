package com.example.cleaning_be.report.dto;

import java.math.BigDecimal;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class MonthlyRevenueResponse {
  private int year;
  private int month;
  private BigDecimal totalAmount;
  private String label;
}

