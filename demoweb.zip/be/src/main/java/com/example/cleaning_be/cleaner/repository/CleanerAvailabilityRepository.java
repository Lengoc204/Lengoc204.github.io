package com.example.cleaning_be.cleaner.repository;

import com.example.cleaning_be.cleaner.entity.CleanerAvailability;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CleanerAvailabilityRepository extends JpaRepository<CleanerAvailability, UUID> {
  List<CleanerAvailability> findByCleanerId(UUID cleanerId);
}
