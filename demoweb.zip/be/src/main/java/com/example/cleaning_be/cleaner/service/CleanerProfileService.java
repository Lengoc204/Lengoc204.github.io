package com.example.cleaning_be.cleaner.service;

import com.example.cleaning_be.cleaner.dto.CleanerProfileResponse;
import com.example.cleaning_be.cleaner.dto.UpdateCleanerProfileRequest;
import com.example.cleaning_be.cleaner.entity.CleanerProfile;
import com.example.cleaning_be.cleaner.repository.CleanerProfileRepository;
import com.example.cleaning_be.common.exception.ErrorCode;
import com.example.cleaning_be.common.exception.ResourceNotFoundException;
import com.example.cleaning_be.user.entity.User;
import com.example.cleaning_be.user.repository.UserRepository;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class CleanerProfileService {

  private final CleanerProfileRepository cleanerProfileRepository;
  private final UserRepository userRepository;

  @Transactional(readOnly = true)
  public CleanerProfileResponse getProfile(UUID userId) {
    CleanerProfile profile = getOrCreateProfile(userId);
    return toResponse(profile);
  }

  @Transactional
  public CleanerProfileResponse updateProfile(UpdateCleanerProfileRequest request) {
    CleanerProfile profile = getOrCreateProfile(request.getUserId());
    if (request.getBio() != null) {
      profile.setBio(request.getBio());
    }
    if (request.getYearsExperience() != null) {
      profile.setYearsExperience(request.getYearsExperience());
    }
    if (request.getHourlyRate() != null) {
      profile.setHourlyRate(request.getHourlyRate());
    }
    if (request.getServiceArea() != null) {
      profile.setServiceArea(request.getServiceArea());
    }
    CleanerProfile saved = cleanerProfileRepository.save(profile);
    return toResponse(saved);
  }

  private CleanerProfile getOrCreateProfile(UUID userId) {
    return cleanerProfileRepository
        .findByUserId(userId)
        .orElseGet(
            () -> {
              User user =
                  userRepository
                      .findById(userId)
                      .orElseThrow(
                          () -> new ResourceNotFoundException(ErrorCode.USER_NOT_FOUND));
              CleanerProfile profile = new CleanerProfile();
              profile.setUser(user);
              profile.setCompletedJobs(0);
              profile.setRatingAverage(0.0);
              return cleanerProfileRepository.save(profile);
            });
  }

  private CleanerProfileResponse toResponse(CleanerProfile profile) {
    return CleanerProfileResponse.builder()
        .id(profile.getId())
        .userId(profile.getUser().getId())
        .bio(profile.getBio())
        .yearsExperience(profile.getYearsExperience())
        .hourlyRate(profile.getHourlyRate())
        .serviceArea(profile.getServiceArea())
        .completedJobs(profile.getCompletedJobs())
        .ratingAverage(profile.getRatingAverage())
        .verificationStatus(profile.getVerificationStatus())
        .build();
  }
}
