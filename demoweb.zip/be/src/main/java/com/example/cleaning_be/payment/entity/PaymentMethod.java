package com.example.cleaning_be.payment.entity;

public enum PaymentMethod {
  CASH,
  BANK_TRANSFER,
  VNPAY
}
