package com.example.cleaning_be.payment.dto;

import com.example.cleaning_be.payment.entity.PaymentMethod;
import jakarta.validation.constraints.NotNull;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MockPaymentRequest {

  @NotNull private UUID customerId;

  private PaymentMethod method = PaymentMethod.CASH;
}

