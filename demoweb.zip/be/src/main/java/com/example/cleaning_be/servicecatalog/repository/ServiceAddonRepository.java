package com.example.cleaning_be.servicecatalog.repository;

import com.example.cleaning_be.servicecatalog.entity.ServiceAddon;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceAddonRepository extends JpaRepository<ServiceAddon, UUID> {
  List<ServiceAddon> findByServiceId(UUID serviceId);
}
