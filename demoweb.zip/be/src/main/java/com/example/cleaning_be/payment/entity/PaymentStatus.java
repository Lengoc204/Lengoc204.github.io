package com.example.cleaning_be.payment.entity;

public enum PaymentStatus {
  PENDING,
  PAID,
  FAILED,
  REFUNDED
}
