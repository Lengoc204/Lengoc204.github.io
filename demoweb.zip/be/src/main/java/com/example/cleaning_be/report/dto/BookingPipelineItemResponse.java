package com.example.cleaning_be.report.dto;

import com.example.cleaning_be.booking.entity.BookingStatus;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class BookingPipelineItemResponse {
  private UUID bookingId;
  private String code;
  private String customerName;
  private String serviceName;
  private BookingStatus status;
  private BigDecimal totalPrice;
  private OffsetDateTime scheduledStart;
}

