package com.example.cleaning_be.payment.repository;

import com.example.cleaning_be.payment.entity.UserPaymentMethod;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserPaymentMethodRepository extends JpaRepository<UserPaymentMethod, UUID> {
  List<UserPaymentMethod> findByUserId(UUID userId);

  Optional<UserPaymentMethod> findByIdAndUserId(UUID id, UUID userId);
}

