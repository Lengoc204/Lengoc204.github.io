package com.example.cleaning_be.booking.service;

import com.example.cleaning_be.booking.dto.BookingSummaryResponse;
import com.example.cleaning_be.booking.dto.CustomerPaymentItemResponse;
import com.example.cleaning_be.booking.dto.StaffAssignmentResponse;
import com.example.cleaning_be.booking.dto.StaffBookingResponse;
import com.example.cleaning_be.booking.dto.StaffEarningResponse;
import com.example.cleaning_be.booking.entity.AssignmentStatus;
import com.example.cleaning_be.booking.entity.Booking;
import com.example.cleaning_be.booking.entity.BookingCleaner;
import com.example.cleaning_be.booking.entity.BookingStatus;
import com.example.cleaning_be.booking.repository.BookingCleanerRepository;
import com.example.cleaning_be.booking.repository.BookingRepository;
import com.example.cleaning_be.cleaner.entity.CleanerProfile;
import com.example.cleaning_be.cleaner.repository.CleanerProfileRepository;
import com.example.cleaning_be.payment.entity.PaymentStatus;
import com.example.cleaning_be.common.exception.ErrorCode;
import com.example.cleaning_be.common.exception.ResourceNotFoundException;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class BookingSummaryService {

  private final BookingRepository bookingRepository;
  private final BookingCleanerRepository bookingCleanerRepository;
  private final CleanerProfileRepository cleanerProfileRepository;

  @Transactional(readOnly = true)
  public List<BookingSummaryResponse> getCustomerBookings(UUID customerId) {
    List<Booking> bookings = bookingRepository.findByCustomerId(customerId);
    return bookings.stream()
        .map(
            booking ->
                BookingSummaryResponse.builder()
                    .id(booking.getId())
                    .code("#" + booking.getId().toString().substring(0, 8).toUpperCase())
                    .serviceName(booking.getService().getName())
                    .scheduledDate(booking.getScheduledStart().toLocalDate())
                    .status(booking.getStatus().name())
                    .totalPrice(booking.getTotalPrice())
                    .build())
        .toList();
  }

  @Transactional(readOnly = true)
  public List<StaffBookingResponse> getBookingsByStatus(BookingStatus status) {
    List<Booking> bookings = bookingRepository.findByStatus(status);
    return bookings.stream()
        .map(
            booking ->
                StaffBookingResponse.builder()
                    .id(booking.getId())
                    .code("#" + booking.getId().toString().substring(0, 8).toUpperCase())
                    .customerName(booking.getCustomer().getFullName())
                    .serviceName(booking.getService().getName())
                    .address(
                        booking.getAddress() != null
                            ? booking.getAddress().getStreet()
                            : "Địa chỉ chưa xác định")
                    .scheduledStart(booking.getScheduledStart())
                    .totalPrice(booking.getTotalPrice())
                    .status(booking.getStatus().name())
                    .build())
        .toList();
  }

  @Transactional(readOnly = true)
  public List<StaffAssignmentResponse> getCleanerAssignments(UUID staffUserId) {
    CleanerProfile cleaner =
        cleanerProfileRepository
            .findByUserId(staffUserId)
            .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.CLEANER_PROFILE_NOT_FOUND));

    return bookingCleanerRepository.findByCleanerId(cleaner.getId()).stream()
        .filter(assignment -> assignment.getAssignmentStatus() != AssignmentStatus.CANCELLED)
        .sorted(Comparator.comparing(a -> a.getBooking().getScheduledStart()))
        .map(this::mapToAssignmentResponse)
        .toList();
  }

  private StaffAssignmentResponse mapToAssignmentResponse(BookingCleaner assignment) {
    Booking booking = assignment.getBooking();
    return StaffAssignmentResponse.builder()
        .assignmentId(assignment.getId())
        .bookingId(booking.getId())
        .code("#" + booking.getId().toString().substring(0, 8).toUpperCase())
        .customerName(booking.getCustomer().getFullName())
        .serviceName(booking.getService().getName())
        .address(
            booking.getAddress() != null
                ? booking.getAddress().getStreet()
                : "Địa chỉ chưa xác định")
        .scheduledStart(booking.getScheduledStart())
        .scheduledEnd(booking.getScheduledEnd())
        .totalPrice(booking.getTotalPrice())
        .bookingStatus(booking.getStatus().name())
        .assignmentStatus(assignment.getAssignmentStatus().name())
        .assignedAt(assignment.getAssignedAt())
        .build();
  }

  @Transactional(readOnly = true)
  public List<CustomerPaymentItemResponse> getCustomerPayments(UUID customerId) {
    List<Booking> bookings = bookingRepository.findByCustomerId(customerId);
    return bookings.stream()
        .sorted(Comparator.comparing(Booking::getScheduledStart))
        .map(
            booking ->
                CustomerPaymentItemResponse.builder()
                    .bookingId(booking.getId())
                    .code("#" + booking.getId().toString().substring(0, 8).toUpperCase())
                    .serviceName(booking.getService().getName())
                    .scheduledDate(booking.getScheduledStart())
                    .bookingStatus(booking.getStatus())
                    .totalPrice(booking.getTotalPrice())
                    .paymentStatus(
                        booking.getPayment() != null ? booking.getPayment().getStatus() : null)
                    .paymentId(
                        booking.getPayment() != null ? booking.getPayment().getId() : null)
                    .build())
        .toList();
  }

  @Transactional(readOnly = true)
  public List<StaffEarningResponse> getStaffEarnings(UUID staffUserId) {
    CleanerProfile cleaner =
        cleanerProfileRepository
            .findByUserId(staffUserId)
            .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.CLEANER_PROFILE_NOT_FOUND));

    return bookingCleanerRepository.findByCleanerId(cleaner.getId()).stream()
        .map(BookingCleaner::getBooking)
        .filter(booking -> booking.getPayment() != null)
        .filter(booking -> booking.getPayment().getStatus() == PaymentStatus.PAID)
        .sorted(
            Comparator.comparing(
                    (Booking booking) ->
                        booking.getPayment() != null ? booking.getPayment().getPaidAt() : null,
                    Comparator.nullsLast(Comparator.naturalOrder()))
                .reversed())
        .map(
            booking ->
                StaffEarningResponse.builder()
                    .bookingId(booking.getId())
                    .code("#" + booking.getId().toString().substring(0, 8).toUpperCase())
                    .serviceName(booking.getService().getName())
                    .amount(booking.getPayment().getAmount())
                    .paidAt(booking.getPayment().getPaidAt())
                    .build())
        .toList();
  }
}
