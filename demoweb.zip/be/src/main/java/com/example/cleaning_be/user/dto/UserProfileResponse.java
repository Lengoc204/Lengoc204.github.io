package com.example.cleaning_be.user.dto;

import com.example.cleaning_be.address.dto.AddressResponse;
import com.example.cleaning_be.user.entity.Role;
import com.example.cleaning_be.user.entity.UserStatus;
import java.util.List;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class UserProfileResponse {
  private UUID id;
  private String email;
  private String fullName;
  private String phone;
  private Role role;
  private UserStatus status;
  private String avatarUrl;
  private List<AddressResponse> addresses;
}
