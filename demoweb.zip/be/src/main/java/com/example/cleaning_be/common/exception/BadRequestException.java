package com.example.cleaning_be.common.exception;

public class BadRequestException extends BusinessException {

  public BadRequestException(String message) {
    super(ErrorCode.BAD_REQUEST, message);
  }
}
