package com.example.cleaning_be.user.repository;

import com.example.cleaning_be.user.entity.Role;
import com.example.cleaning_be.user.entity.User;
import com.example.cleaning_be.user.entity.UserStatus;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, UUID> {
  boolean existsByEmailIgnoreCase(String email);

  Optional<User> findByEmailIgnoreCase(String email);

  List<User> findByRole(Role role);

  long countByRole(Role role);

  long countByRoleAndStatus(Role role, UserStatus status);
}
