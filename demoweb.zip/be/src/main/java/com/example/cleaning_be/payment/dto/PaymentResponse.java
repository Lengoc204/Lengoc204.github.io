package com.example.cleaning_be.payment.dto;

import com.example.cleaning_be.payment.entity.PaymentMethod;
import com.example.cleaning_be.payment.entity.PaymentStatus;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class PaymentResponse {
  private UUID paymentId;
  private UUID bookingId;
  private BigDecimal amount;
  private String currency;
  private PaymentStatus status;
  private PaymentMethod method;
  private Instant paidAt;
}

