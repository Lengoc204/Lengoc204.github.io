package com.example.cleaning_be.report.service;

import com.example.cleaning_be.booking.entity.Booking;
import com.example.cleaning_be.booking.entity.BookingStatus;
import com.example.cleaning_be.booking.repository.BookingRepository;
import com.example.cleaning_be.payment.entity.PaymentStatus;
import com.example.cleaning_be.payment.repository.MonthlyRevenueProjection;
import com.example.cleaning_be.payment.repository.PaymentRepository;
import com.example.cleaning_be.report.dto.BookingPipelineItemResponse;
import com.example.cleaning_be.report.dto.AdminDashboardSummaryResponse;
import com.example.cleaning_be.report.dto.MonthlyRevenueResponse;
import com.example.cleaning_be.user.entity.Role;
import com.example.cleaning_be.user.entity.UserStatus;
import com.example.cleaning_be.user.repository.UserRepository;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Comparator;
import java.util.List;
import org.springframework.data.domain.PageRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class RevenueReportService {

  private final PaymentRepository paymentRepository;
  private final BookingRepository bookingRepository;
  private final UserRepository userRepository;

  @Transactional(readOnly = true)
  public List<MonthlyRevenueResponse> getMonthlyRevenue(int months) {
    int range = months <= 0 ? 6 : Math.min(months, 24);
    OffsetDateTime from =
        OffsetDateTime.now(ZoneOffset.UTC).withDayOfMonth(1).minusMonths(range - 1L).withHour(0).withMinute(0).withSecond(0).withNano(0);

    List<MonthlyRevenueProjection> raw =
        paymentRepository.findMonthlyRevenueSince(
            PaymentStatus.PAID, from.toInstant());

    return raw.stream()
        .sorted(Comparator.comparingInt(MonthlyRevenueProjection::getYear)
            .thenComparingInt(MonthlyRevenueProjection::getMonth))
        .map(
            item ->
                MonthlyRevenueResponse.builder()
                    .year(item.getYear())
                    .month(item.getMonth())
                    .totalAmount(item.getTotalAmount() == null ? BigDecimal.ZERO : item.getTotalAmount())
                    .label(String.format("%d-%02d", item.getYear(), item.getMonth()))
                    .build())
        .toList();
  }

  @Transactional(readOnly = true)
  public AdminDashboardSummaryResponse getDashboardSummary() {
    long totalBookings = bookingRepository.count();
    long pendingBookings = bookingRepository.countByStatus(BookingStatus.PENDING);
    long totalStaff = userRepository.countByRole(Role.STAFF);
    long activeStaff = userRepository.countByRoleAndStatus(Role.STAFF, UserStatus.ACTIVE);
    long totalCustomers = userRepository.countByRole(Role.CUSTOMER);
    long activeCustomers = userRepository.countByRoleAndStatus(Role.CUSTOMER, UserStatus.ACTIVE);

    return AdminDashboardSummaryResponse.builder()
        .totalBookings(totalBookings)
        .pendingBookings(pendingBookings)
        .activeStaff(activeStaff)
        .totalStaff(totalStaff)
        .activeCustomers(activeCustomers)
        .totalCustomers(totalCustomers)
        .build();
  }

  @Transactional(readOnly = true)
  public List<BookingPipelineItemResponse> getRecentBookings(int count) {
    return bookingRepository.findAllByOrderByCreatedAtDesc(PageRequest.of(0, Math.max(count, 1))).stream()
        .map(this::mapBookingPipeline)
        .toList();
  }

  @Transactional(readOnly = true)
  public BookingPipelineItemResponse getTopBooking() {
    return bookingRepository.findAllByOrderByTotalPriceDesc(PageRequest.of(0, 1)).stream()
        .findFirst()
        .map(this::mapBookingPipeline)
        .orElse(null);
  }

  private BookingPipelineItemResponse mapBookingPipeline(Booking booking) {
    return BookingPipelineItemResponse.builder()
        .bookingId(booking.getId())
        .code("#" + booking.getId().toString().substring(0, 8).toUpperCase())
        .customerName(booking.getCustomer().getFullName())
        .serviceName(booking.getService().getName())
        .status(booking.getStatus())
        .totalPrice(booking.getTotalPrice())
        .scheduledStart(booking.getScheduledStart())
        .build();
  }
}
