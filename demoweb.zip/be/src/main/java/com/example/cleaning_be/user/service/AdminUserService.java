package com.example.cleaning_be.user.service;

import com.example.cleaning_be.common.exception.ErrorCode;
import com.example.cleaning_be.common.exception.ResourceNotFoundException;
import com.example.cleaning_be.user.dto.LoginHistoryResponse;
import com.example.cleaning_be.user.dto.UserSummaryResponse;
import com.example.cleaning_be.user.entity.Role;
import com.example.cleaning_be.user.entity.User;
import com.example.cleaning_be.user.entity.UserLoginEvent;
import com.example.cleaning_be.user.repository.UserLoginEventRepository;
import com.example.cleaning_be.user.repository.UserRepository;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AdminUserService {

  private final UserRepository userRepository;
  private final UserLoginEventRepository loginEventRepository;

  @Transactional(readOnly = true)
  public List<UserSummaryResponse> getUsers(Role role) {
    List<User> users = role == null ? userRepository.findAll() : userRepository.findByRole(role);
    return users.stream()
        .map(
            user ->
                UserSummaryResponse.builder()
                    .id(user.getId())
                    .fullName(user.getFullName())
                    .email(user.getEmail())
                    .phone(user.getPhone())
                    .role(user.getRole())
                    .status(user.getStatus())
                    .createdAt(user.getCreatedAt())
                    .build())
        .toList();
  }

  @Transactional(readOnly = true)
  public List<LoginHistoryResponse> getLoginHistory(UUID userId) {
    userRepository
        .findById(userId)
        .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.USER_NOT_FOUND));
    List<UserLoginEvent> events =
        loginEventRepository.findTop50ByUserIdOrderByLoginAtDesc(userId);
    return events.stream()
        .map(
            event ->
                LoginHistoryResponse.builder()
                    .loginAt(event.getLoginAt())
                    .ipAddress(event.getIpAddress())
                    .userAgent(event.getUserAgent())
                    .build())
        .toList();
  }
}

