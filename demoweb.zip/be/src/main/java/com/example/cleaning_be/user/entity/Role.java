package com.example.cleaning_be.user.entity;

public enum Role {
  CUSTOMER,
  STAFF,
  ADMIN
}
