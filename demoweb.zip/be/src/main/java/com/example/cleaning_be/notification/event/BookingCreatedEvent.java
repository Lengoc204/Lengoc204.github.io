package com.example.cleaning_be.notification.event;

import java.util.UUID;

public record BookingCreatedEvent(UUID bookingId) {}
