package com.example.cleaning_be.booking.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class BookingSummaryResponse {
  private UUID id;
  private String code;
  private String serviceName;
  private LocalDate scheduledDate;
  private String status;
  private BigDecimal totalPrice;
}
