package com.example.cleaning_be.booking.dto;

import com.example.cleaning_be.booking.entity.BookingStatus;
import jakarta.validation.constraints.NotNull;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookingStatusUpdateRequest {

  @NotNull private UUID staffId;

  @NotNull private BookingStatus status;
}

