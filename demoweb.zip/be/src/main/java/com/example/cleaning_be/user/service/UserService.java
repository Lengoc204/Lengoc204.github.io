package com.example.cleaning_be.user.service;

import com.example.cleaning_be.common.exception.ErrorCode;
import com.example.cleaning_be.common.exception.ResourceNotFoundException;
import com.example.cleaning_be.user.entity.Role;
import com.example.cleaning_be.user.entity.User;
import com.example.cleaning_be.user.repository.UserRepository;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserService {

  private final UserRepository userRepository;

  public User getByEmail(String email) {
    return userRepository
        .findByEmailIgnoreCase(email)
        .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.USER_NOT_FOUND));
  }

  public boolean emailExists(String email) {
    return userRepository.existsByEmailIgnoreCase(email);
  }

  public User getById(UUID id) {
    return userRepository
        .findById(id)
        .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.USER_NOT_FOUND));
  }

  public List<User> findByRole(Role role) {
    return role == null ? userRepository.findAll() : userRepository.findByRole(role);
  }

  @Transactional
  public User save(User user) {
    return userRepository.save(user);
  }
}
