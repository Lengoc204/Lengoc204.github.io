package com.example.cleaning_be.payment.repository;

import java.math.BigDecimal;

public interface MonthlyRevenueProjection {
  Integer getYear();

  Integer getMonth();

  BigDecimal getTotalAmount();
}

