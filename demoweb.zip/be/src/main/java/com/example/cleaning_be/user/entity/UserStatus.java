package com.example.cleaning_be.user.entity;

public enum UserStatus {
  ACTIVE,
  INACTIVE
}
