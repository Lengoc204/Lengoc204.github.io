package com.example.cleaning_be.booking.service;

import com.example.cleaning_be.address.entity.Address;
import com.example.cleaning_be.address.repository.AddressRepository;
import com.example.cleaning_be.booking.dto.BookingClaimRequest;
import com.example.cleaning_be.booking.dto.BookingDetailResponse;
import com.example.cleaning_be.booking.dto.BookingReleaseRequest;
import com.example.cleaning_be.booking.dto.BookingStatusUpdateRequest;
import com.example.cleaning_be.booking.dto.CreateBookingRequest;
import com.example.cleaning_be.booking.entity.Booking;
import com.example.cleaning_be.booking.entity.BookingCleaner;
import com.example.cleaning_be.booking.entity.AssignmentStatus;
import com.example.cleaning_be.booking.entity.BookingStatus;
import com.example.cleaning_be.booking.repository.BookingCleanerRepository;
import com.example.cleaning_be.booking.repository.BookingRepository;
import com.example.cleaning_be.cleaner.entity.CleanerProfile;
import com.example.cleaning_be.cleaner.repository.CleanerProfileRepository;
import com.example.cleaning_be.common.exception.BusinessException;
import com.example.cleaning_be.common.exception.ErrorCode;
import com.example.cleaning_be.common.exception.ResourceNotFoundException;
import com.example.cleaning_be.payment.entity.Payment;
import com.example.cleaning_be.payment.entity.PaymentMethod;
import com.example.cleaning_be.payment.entity.PaymentStatus;
import com.example.cleaning_be.payment.repository.PaymentRepository;
import com.example.cleaning_be.servicecatalog.entity.CleaningService;
import com.example.cleaning_be.servicecatalog.repository.CleaningServiceRepository;
import com.example.cleaning_be.user.entity.User;
import com.example.cleaning_be.user.repository.UserRepository;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.Optional;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class BookingCommandService {

  private final BookingRepository bookingRepository;
  private final UserRepository userRepository;
  private final CleaningServiceRepository cleaningServiceRepository;
  private final AddressRepository addressRepository;
  private final BookingCleanerRepository bookingCleanerRepository;
  private final CleanerProfileRepository cleanerProfileRepository;
  private final PaymentRepository paymentRepository;

  @Transactional
  public BookingDetailResponse createBooking(CreateBookingRequest request) {
    User customer = getUser(request.getCustomerId());
    CleaningService service = getService(request.getServiceId());
    Address address = createAddressIfNeeded(request, customer);

    BookingStatus status =
        request.getStatus() == null ? BookingStatus.PENDING : request.getStatus();

    Booking booking =
        Booking.builder()
            .customer(customer)
            .service(service)
            .address(address)
            .scheduledStart(request.getScheduledStart())
            .scheduledEnd(request.getScheduledEnd())
            .status(status)
            .totalPrice(request.getTotalPrice())
            .notes(request.getNotes())
            .build();

    Booking saved = bookingRepository.save(booking);
    return mapToResponse(saved);
  }

  private BookingDetailResponse mapToResponse(Booking booking) {
    String code = "#" + booking.getId().toString().substring(0, 8).toUpperCase();
    return BookingDetailResponse.builder()
        .id(booking.getId())
        .code(code)
        .customerId(booking.getCustomer().getId())
        .serviceId(booking.getService().getId())
        .addressId(booking.getAddress().getId())
        .serviceName(booking.getService().getName())
        .scheduledStart(booking.getScheduledStart())
        .scheduledEnd(booking.getScheduledEnd())
        .status(booking.getStatus())
        .totalPrice(booking.getTotalPrice())
        .notes(booking.getNotes())
        .build();
  }

  private User getUser(UUID userId) {
    return userRepository
        .findById(userId)
        .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.USER_NOT_FOUND));
  }

  private CleaningService getService(UUID serviceId) {
    return cleaningServiceRepository
        .findById(serviceId)
        .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.SERVICE_NOT_FOUND));
  }
  private Address createAddressIfNeeded(CreateBookingRequest request, User customer) {
    Address address =
        Address.builder()
            .user(customer)
            .label(request.getLabel())
            .street(request.getStreet())
            .ward(request.getWard())
            .district(request.getDistrict())
            .city(request.getCity())
            .province(request.getProvince())
            .latitude(request.getLatitude())
            .longitude(request.getLongitude())
            .defaultAddress(false)
            .build();
    return addressRepository.save(address);
  }

  @Transactional
  public BookingDetailResponse claimBooking(UUID bookingId, BookingClaimRequest request) {
    Booking booking =
        bookingRepository
            .findById(bookingId)
            .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.BOOKING_NOT_FOUND));

    if (booking.getStatus() != BookingStatus.PENDING) {
      throw new BusinessException(ErrorCode.BOOKING_ALREADY_ASSIGNED);
    }

    CleanerProfile cleaner = getCleanerProfile(request.getStaffId());

    List<BookingCleaner> existingAssignments =
        bookingCleanerRepository.findByCleanerId(cleaner.getId());
    boolean hasConflict =
        existingAssignments.stream()
            .filter(assignment -> assignment.getAssignmentStatus() == AssignmentStatus.ASSIGNED)
            .map(BookingCleaner::getBooking)
            .anyMatch(existing -> overlaps(existing, booking));

    if (hasConflict && !request.isForceAssign()) {
      throw new BusinessException(
          ErrorCode.BOOKING_TIME_CONFLICT,
          "Ca làm mới trùng thời gian với ca hiện có. Vui lòng xác nhận lại.");
    }

    booking.setStatus(BookingStatus.CONFIRMED);
    bookingRepository.save(booking);

    BookingCleaner assignment =
        BookingCleaner.builder()
            .booking(booking)
            .cleaner(cleaner)
            .assignedAt(Instant.now())
            .assignmentStatus(AssignmentStatus.ASSIGNED)
            .build();
    bookingCleanerRepository.save(assignment);

    return mapToResponse(booking);
  }

  @Transactional
  public BookingDetailResponse releaseBooking(UUID bookingId, BookingReleaseRequest request) {
    Booking booking =
        bookingRepository
            .findById(bookingId)
            .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.BOOKING_NOT_FOUND));

    CleanerProfile cleaner = getCleanerProfile(request.getStaffId());

    if (booking.getStatus() != BookingStatus.CONFIRMED) {
      throw new BusinessException(
          ErrorCode.BOOKING_RELEASE_NOT_ALLOWED,
          "Chỉ có thể hủy các đơn đang ở trạng thái đã xác nhận.");
    }

    BookingCleaner assignment =
        bookingCleanerRepository
            .findTopByBookingIdAndCleanerIdOrderByCreatedAtDesc(bookingId, cleaner.getId())
            .orElseThrow(
                () -> new ResourceNotFoundException(ErrorCode.BOOKING_ASSIGNMENT_NOT_FOUND));

    if (assignment.getAssignmentStatus() != AssignmentStatus.ASSIGNED) {
      throw new BusinessException(
          ErrorCode.BOOKING_RELEASE_NOT_ALLOWED,
          "Đơn đã ở trạng thái không thể hủy nhận.");
    }

    booking.setStatus(BookingStatus.PENDING);
    bookingRepository.save(booking);

    assignment.setAssignmentStatus(AssignmentStatus.CANCELLED);
    bookingCleanerRepository.save(assignment);

    return mapToResponse(booking);
  }

  @Transactional
  public BookingDetailResponse updateBookingStatus(
      UUID bookingId, BookingStatusUpdateRequest request) {
    Booking booking =
        bookingRepository
            .findById(bookingId)
            .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.BOOKING_NOT_FOUND));

    CleanerProfile cleaner = getCleanerProfile(request.getStaffId());

    BookingCleaner assignment =
        bookingCleanerRepository
            .findLatestByBookingAndStaffUser(bookingId, request.getStaffId())
            .orElseThrow(
                () -> new ResourceNotFoundException(ErrorCode.BOOKING_ASSIGNMENT_NOT_FOUND));

    if (assignment.getAssignmentStatus() != AssignmentStatus.ASSIGNED) {
      throw new BusinessException(
          ErrorCode.BOOKING_RELEASE_NOT_ALLOWED, "Đơn đã không còn ở trạng thái có thể cập nhật.");
    }

    BookingStatus current = booking.getStatus();
    BookingStatus target = request.getStatus();

    switch (target) {
      case IN_PROGRESS -> {
        if (current != BookingStatus.CONFIRMED) {
          throw new BusinessException(
              ErrorCode.BAD_REQUEST, "Chỉ có thể chuyển sang đang thực hiện từ trạng thái đã nhận.");
        }
        booking.setStatus(BookingStatus.IN_PROGRESS);
      }
      case COMPLETED -> {
        if (current != BookingStatus.IN_PROGRESS) {
          throw new BusinessException(
              ErrorCode.BAD_REQUEST,
              "Chỉ có thể hoàn thành những đơn đang trong quá trình thực hiện.");
        }
        booking.setStatus(BookingStatus.COMPLETED);
        assignment.setAssignmentStatus(AssignmentStatus.COMPLETED);
        ensurePaymentRecord(booking);
      }
      case CANCELLED -> {
        if (current != BookingStatus.CONFIRMED && current != BookingStatus.IN_PROGRESS) {
          throw new BusinessException(
              ErrorCode.BAD_REQUEST, "Chỉ có thể hủy các đơn đã nhận hoặc đang xử lý.");
        }
        booking.setStatus(BookingStatus.PENDING);
        assignment.setAssignmentStatus(AssignmentStatus.CANCELLED);
      }
      case CONFIRMED -> {
        booking.setStatus(BookingStatus.CONFIRMED);
      }
      default -> throw new BusinessException(ErrorCode.BAD_REQUEST, "Trạng thái không hợp lệ.");
    }

    bookingRepository.save(booking);
    bookingCleanerRepository.save(assignment);
    return mapToResponse(booking);
  }

  private boolean overlaps(Booking existing, Booking target) {
    OffsetDateTime existingStart = existing.getScheduledStart();
    OffsetDateTime existingEnd = resolveEnd(existing);
    OffsetDateTime targetStart = target.getScheduledStart();
    OffsetDateTime targetEnd = resolveEnd(target);

    return existingStart.isBefore(targetEnd) && targetStart.isBefore(existingEnd);
  }

  private OffsetDateTime resolveEnd(Booking booking) {
    if (booking.getScheduledEnd() != null) {
      return booking.getScheduledEnd();
    }
    Integer duration = booking.getService().getDurationMinutes();
    if (duration != null && duration > 0) {
      return booking.getScheduledStart().plusMinutes(duration);
    }
    return booking.getScheduledStart().plusHours(2);
  }

  private CleanerProfile getCleanerProfile(UUID staffId) {
    return cleanerProfileRepository
        .findByUserId(staffId)
        .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.CLEANER_PROFILE_NOT_FOUND));
  }
  private Payment ensurePaymentRecord(Booking booking) {
    Optional<Payment> existing = paymentRepository.findByBookingId(booking.getId());
    if (existing.isPresent()) {
      Payment payment = existing.get();
      payment.setAmount(booking.getTotalPrice());
      payment.setCurrency("VND");
      return paymentRepository.save(payment);
    }
    Payment payment =
        Payment.builder()
            .booking(booking)
            .amount(booking.getTotalPrice())
            .currency("VND")
            .method(PaymentMethod.CASH)
            .status(PaymentStatus.PENDING)
            .build();
    return paymentRepository.save(payment);
  }
}
