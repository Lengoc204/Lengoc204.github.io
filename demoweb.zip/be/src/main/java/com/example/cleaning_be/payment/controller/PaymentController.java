package com.example.cleaning_be.payment.controller;

import com.example.cleaning_be.payment.dto.MockPaymentRequest;
import com.example.cleaning_be.payment.dto.PaymentResponse;
import com.example.cleaning_be.payment.service.PaymentCommandService;
import jakarta.validation.Valid;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/payments")
@RequiredArgsConstructor
public class PaymentController {

  private final PaymentCommandService paymentCommandService;

  @PostMapping("/{bookingId}/mock")
  public ResponseEntity<PaymentResponse> mockPayment(
      @PathVariable UUID bookingId, @Valid @RequestBody MockPaymentRequest request) {
    return ResponseEntity.ok(paymentCommandService.mockPayment(bookingId, request));
  }
}

