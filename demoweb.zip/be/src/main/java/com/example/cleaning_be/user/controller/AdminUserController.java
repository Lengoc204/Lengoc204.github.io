package com.example.cleaning_be.user.controller;

import com.example.cleaning_be.user.dto.LoginHistoryResponse;
import com.example.cleaning_be.user.dto.UserSummaryResponse;
import com.example.cleaning_be.user.entity.Role;
import com.example.cleaning_be.user.service.AdminUserService;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/admin/users")
@RequiredArgsConstructor
public class AdminUserController {

  private final AdminUserService adminUserService;

  @GetMapping
  public ResponseEntity<List<UserSummaryResponse>> listUsers(
      @RequestParam(value = "role", required = false) Role role) {
    return ResponseEntity.ok(adminUserService.getUsers(role));
  }

  @GetMapping("/{userId}/logins")
  public ResponseEntity<List<LoginHistoryResponse>> getLoginHistory(@PathVariable UUID userId) {
    return ResponseEntity.ok(adminUserService.getLoginHistory(userId));
  }
}

