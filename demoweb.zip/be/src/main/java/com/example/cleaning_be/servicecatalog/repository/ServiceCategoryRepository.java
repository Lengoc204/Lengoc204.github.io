package com.example.cleaning_be.servicecatalog.repository;

import com.example.cleaning_be.servicecatalog.entity.ServiceCategory;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceCategoryRepository extends JpaRepository<ServiceCategory, UUID> {
  Optional<ServiceCategory> findByNameIgnoreCase(String name);
}
