package com.example.cleaning_be.booking.controller;

import com.example.cleaning_be.booking.dto.BookingClaimRequest;
import com.example.cleaning_be.booking.dto.BookingDetailResponse;
import com.example.cleaning_be.booking.dto.BookingReleaseRequest;
import com.example.cleaning_be.booking.dto.BookingStatusUpdateRequest;
import com.example.cleaning_be.booking.dto.BookingSummaryResponse;
import com.example.cleaning_be.booking.dto.CreateBookingRequest;
import com.example.cleaning_be.booking.dto.CustomerPaymentItemResponse;
import com.example.cleaning_be.booking.dto.StaffAssignmentResponse;
import com.example.cleaning_be.booking.dto.StaffBookingResponse;
import com.example.cleaning_be.booking.dto.StaffEarningResponse;
import com.example.cleaning_be.booking.entity.BookingStatus;
import com.example.cleaning_be.booking.service.BookingCommandService;
import com.example.cleaning_be.booking.service.BookingSummaryService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/bookings")
@RequiredArgsConstructor
public class BookingController {

  private final BookingSummaryService bookingSummaryService;
  private final BookingCommandService bookingCommandService;

  @GetMapping("/customer_summary")
  public ResponseEntity<List<BookingSummaryResponse>> getCustomerSummary(
      @RequestParam("customerId") UUID customerId) {
    return ResponseEntity.ok(bookingSummaryService.getCustomerBookings(customerId));
  }

  @GetMapping("/pending")
  public ResponseEntity<List<StaffBookingResponse>> getPendingBookings(
      @RequestParam(value = "status", defaultValue = "PENDING") BookingStatus status) {
    return ResponseEntity.ok(bookingSummaryService.getBookingsByStatus(status));
  }

  @GetMapping("/staff_schedule")
  public ResponseEntity<List<StaffAssignmentResponse>> getStaffSchedule(
      @RequestParam("staffId") UUID staffId) {
    return ResponseEntity.ok(bookingSummaryService.getCleanerAssignments(staffId));
  }

  @PostMapping("/{bookingId}/claim")
  public ResponseEntity<BookingDetailResponse> claimBooking(
      @PathVariable UUID bookingId, @Valid @RequestBody BookingClaimRequest request) {
    return ResponseEntity.ok(bookingCommandService.claimBooking(bookingId, request));
  }

  @PostMapping("/{bookingId}/release")
  public ResponseEntity<BookingDetailResponse> releaseBooking(
      @PathVariable UUID bookingId, @Valid @RequestBody BookingReleaseRequest request) {
    return ResponseEntity.ok(bookingCommandService.releaseBooking(bookingId, request));
  }

  @PutMapping("/{bookingId}/status")
  public ResponseEntity<BookingDetailResponse> updateBookingStatus(
      @PathVariable UUID bookingId, @Valid @RequestBody BookingStatusUpdateRequest request) {
    return ResponseEntity.ok(bookingCommandService.updateBookingStatus(bookingId, request));
  }

  @PostMapping
  public ResponseEntity<BookingDetailResponse> createBooking(
      @Valid @RequestBody CreateBookingRequest request) {
    BookingDetailResponse response = bookingCommandService.createBooking(request);
    return ResponseEntity.status(201).body(response);
  }

  @GetMapping("/customer_payments")
  public ResponseEntity<List<CustomerPaymentItemResponse>> getCustomerPayments(
      @RequestParam("customerId") UUID customerId) {
    return ResponseEntity.ok(bookingSummaryService.getCustomerPayments(customerId));
  }

  @GetMapping("/staff/earnings")
  public ResponseEntity<List<StaffEarningResponse>> getStaffEarnings(
      @RequestParam("staffId") UUID staffId) {
    return ResponseEntity.ok(bookingSummaryService.getStaffEarnings(staffId));
  }
}
