package com.example.cleaning_be;

import com.example.cleaning_be.config.JwtProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
//http://localhost:8080/api/v1/docs/swagger-ui/index.html#/
@SpringBootApplication
@EnableConfigurationProperties(JwtProperties.class)
public class CleaningBeApplication {

  public static void main(String[] args) {
    SpringApplication.run(CleaningBeApplication.class, args);
  }
}
