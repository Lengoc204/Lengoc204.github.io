package com.example.cleaning_be.payment.dto;

import com.example.cleaning_be.payment.entity.PaymentMethod;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentMethodRequest {

  @NotNull(message = "Payment method is required")
  private PaymentMethod method;

  private String displayName;

  private String provider;

  private String accountNumber;

  private boolean defaultMethod;
}

