package com.example.cleaning_be.payment.repository;

import com.example.cleaning_be.payment.entity.Payment;
import com.example.cleaning_be.payment.entity.PaymentStatus;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface PaymentRepository extends JpaRepository<Payment, UUID> {
  Optional<Payment> findByBookingId(UUID bookingId);

  @Query(
      """
      SELECT YEAR(p.paidAt) AS year,
             MONTH(p.paidAt) AS month,
             SUM(p.amount)   AS totalAmount
      FROM Payment p
      WHERE p.status = :status
        AND p.paidAt IS NOT NULL
        AND p.paidAt >= :fromDate
      GROUP BY YEAR(p.paidAt), MONTH(p.paidAt)
      ORDER BY YEAR(p.paidAt) DESC, MONTH(p.paidAt) DESC
      """)
  List<MonthlyRevenueProjection> findMonthlyRevenueSince(
      @Param("status") PaymentStatus status, @Param("fromDate") Instant fromDate);
}
