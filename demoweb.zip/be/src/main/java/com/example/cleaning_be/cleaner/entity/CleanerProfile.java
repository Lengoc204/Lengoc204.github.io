package com.example.cleaning_be.cleaner.entity;

import com.example.cleaning_be.common.model.BaseAuditEntity;
import com.example.cleaning_be.user.entity.User;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "cleaner_profiles")
public class CleanerProfile extends BaseAuditEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.UUID)
  private UUID id;

  @OneToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "user_id")
  private User user;

  @Column(length = 500)
  private String bio;

  @Column(name = "years_experience")
  private Integer yearsExperience;

  @Column(name = "hourly_rate")
  private BigDecimal hourlyRate;

  @Column(name = "rating_avg")
  private Double ratingAverage;

  @Column(name = "completed_jobs")
  private Integer completedJobs;

  @Column(name = "service_area")
  private String serviceArea;

  @Enumerated(EnumType.STRING)
  @Column(name = "verification_status", nullable = false, length = 20)
  @Builder.Default
  private VerificationStatus verificationStatus = VerificationStatus.PENDING;
}
