package com.example.cleaning_be.servicecatalog.controller;

import com.example.cleaning_be.servicecatalog.dto.ServiceResponse;
import com.example.cleaning_be.servicecatalog.service.ServiceCatalogService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/services")
@RequiredArgsConstructor
public class ServiceCatalogController {

  private final ServiceCatalogService serviceCatalogService;

  @GetMapping("/active")
  public ResponseEntity<List<ServiceResponse>> getActiveServices() {
    return ResponseEntity.ok(serviceCatalogService.getActiveServices());
  }
}
