package com.example.cleaning_be.booking.dto;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class StaffAssignmentResponse {

  private UUID assignmentId;
  private UUID bookingId;
  private String code;
  private String customerName;
  private String serviceName;
  private String address;
  private OffsetDateTime scheduledStart;
  private OffsetDateTime scheduledEnd;
  private BigDecimal totalPrice;
  private String bookingStatus;
  private String assignmentStatus;
  private Instant assignedAt;
}

