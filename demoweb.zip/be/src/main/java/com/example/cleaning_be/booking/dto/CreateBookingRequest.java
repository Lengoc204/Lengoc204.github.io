package com.example.cleaning_be.booking.dto;

import com.example.cleaning_be.booking.entity.BookingStatus;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateBookingRequest {

  @NotNull private UUID customerId;
  @NotNull private UUID serviceId;
  @NotBlank private String street;
  private String label;
  private String ward;
  private String district;
  private String city;
  private String province;
  private Double latitude;
  private Double longitude;

  @NotNull private OffsetDateTime scheduledStart;
  private OffsetDateTime scheduledEnd;
  private BookingStatus status;
  @NotNull
  @DecimalMin(value = "0.0", inclusive = false, message = "totalPrice must be greater than 0")
  private BigDecimal totalPrice;
  private String notes;
}
