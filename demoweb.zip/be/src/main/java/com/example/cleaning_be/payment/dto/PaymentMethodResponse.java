package com.example.cleaning_be.payment.dto;

import com.example.cleaning_be.payment.entity.PaymentMethod;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class PaymentMethodResponse {
  private UUID id;
  private PaymentMethod method;
  private String displayName;
  private String provider;
  private String maskedNumber;
  private boolean defaultMethod;
}

