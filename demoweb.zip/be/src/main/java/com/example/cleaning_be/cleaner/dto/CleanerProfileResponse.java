package com.example.cleaning_be.cleaner.dto;

import com.example.cleaning_be.cleaner.entity.VerificationStatus;
import java.math.BigDecimal;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class CleanerProfileResponse {
  private UUID id;
  private UUID userId;
  private String bio;
  private Integer yearsExperience;
  private BigDecimal hourlyRate;
  private String serviceArea;
  private Integer completedJobs;
  private Double ratingAverage;
  private VerificationStatus verificationStatus;
}
