package com.example.cleaning_be.booking.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class StaffBookingResponse {
  private UUID id;
  private String code;
  private String customerName;
  private String serviceName;
  private String address;
  private OffsetDateTime scheduledStart;
  private BigDecimal totalPrice;
  private String status;
}
