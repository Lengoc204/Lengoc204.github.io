package com.example.cleaning_be.common.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public enum ErrorCode {
  USER_NOT_FOUND("USR_404", "User not found", HttpStatus.NOT_FOUND),
  EMAIL_ALREADY_USED("USR_409", "Email already registered", HttpStatus.CONFLICT),
  INVALID_CREDENTIALS("AUTH_401", "Invalid credentials", HttpStatus.UNAUTHORIZED),
  TOKEN_INVALID("AUTH_498", "Token is invalid or expired", HttpStatus.UNAUTHORIZED),
  ADDRESS_NOT_FOUND("ADDR_404", "Address not found", HttpStatus.NOT_FOUND),
  SERVICE_NOT_FOUND("SRV_404", "Service not found", HttpStatus.NOT_FOUND),
  BOOKING_NOT_FOUND("BKG_404", "Booking not found", HttpStatus.NOT_FOUND),
  BOOKING_ASSIGNMENT_NOT_FOUND("BKG_410", "Booking assignment not found", HttpStatus.NOT_FOUND),
  CLEANER_PROFILE_NOT_FOUND("CLN_404", "Cleaner profile not found", HttpStatus.NOT_FOUND),
  PAYMENT_METHOD_NOT_FOUND("PMT_404", "Payment method not found", HttpStatus.NOT_FOUND),
  BAD_REQUEST("GEN_400", "Invalid request", HttpStatus.BAD_REQUEST),
  BOOKING_ALREADY_ASSIGNED("BKG_409", "Booking has already been assigned", HttpStatus.CONFLICT),
  BOOKING_RELEASE_NOT_ALLOWED("BKG_422", "Booking cannot be released in current state", HttpStatus.CONFLICT),
  BOOKING_TIME_CONFLICT("BKG_428", "Booking time overlaps with existing assignment", HttpStatus.CONFLICT),
  INTERNAL_ERROR("GEN_500", "Unexpected server error", HttpStatus.INTERNAL_SERVER_ERROR);

  private final String code;
  private final String message;
  private final HttpStatus status;

  ErrorCode(String code, String message, HttpStatus status) {
    this.code = code;
    this.message = message;
    this.status = status;
  }
}
