package com.example.cleaning_be.booking.entity;

public enum AssignmentStatus {
  ASSIGNED,
  DECLINED,
  COMPLETED,
  CANCELLED
}
