package com.example.cleaning_be.user.repository;

import com.example.cleaning_be.user.entity.UserLoginEvent;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserLoginEventRepository extends JpaRepository<UserLoginEvent, UUID> {
  List<UserLoginEvent> findTop50ByUserIdOrderByLoginAtDesc(UUID userId);
}

