package com.example.cleaning_be.booking.dto;

import jakarta.validation.constraints.NotNull;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookingClaimRequest {

  @NotNull private UUID staffId;
  private boolean forceAssign;
}
