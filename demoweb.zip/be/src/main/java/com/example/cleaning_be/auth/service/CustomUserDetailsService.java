package com.example.cleaning_be.auth.service;

import com.example.cleaning_be.user.entity.User;
import com.example.cleaning_be.user.entity.UserStatus;
import com.example.cleaning_be.user.repository.UserRepository;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

  private final UserRepository userRepository;

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    User user =
        userRepository
            .findByEmailIgnoreCase(username)
            .orElseThrow(() -> new UsernameNotFoundException("User not found"));

    boolean enabled = user.getStatus() == UserStatus.ACTIVE;
    var authorities = List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().name()));
    return new org.springframework.security.core.userdetails.User(
        user.getEmail(), user.getPasswordHash(), enabled, true, true, true, authorities);
  }
}
