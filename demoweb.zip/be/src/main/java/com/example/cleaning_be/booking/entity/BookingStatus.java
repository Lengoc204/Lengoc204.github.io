package com.example.cleaning_be.booking.entity;

public enum BookingStatus {
  PENDING,
  CONFIRMED,
  IN_PROGRESS,
  COMPLETED,
  CANCELLED
}
