package com.example.cleaning_be.booking.dto;

import com.example.cleaning_be.booking.entity.BookingStatus;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class BookingDetailResponse {
  private UUID id;
  private String code;
  private UUID customerId;
  private UUID serviceId;
  private UUID addressId;
  private String serviceName;
  private OffsetDateTime scheduledStart;
  private OffsetDateTime scheduledEnd;
  private BookingStatus status;
  private BigDecimal totalPrice;
  private String notes;
}
