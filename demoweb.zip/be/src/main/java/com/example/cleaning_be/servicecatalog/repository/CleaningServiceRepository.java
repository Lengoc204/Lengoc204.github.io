package com.example.cleaning_be.servicecatalog.repository;

import com.example.cleaning_be.servicecatalog.entity.CleaningService;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CleaningServiceRepository extends JpaRepository<CleaningService, UUID> {
  List<CleaningService> findByActiveTrue();
}
