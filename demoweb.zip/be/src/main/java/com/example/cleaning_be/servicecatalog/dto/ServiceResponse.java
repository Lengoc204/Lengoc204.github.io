package com.example.cleaning_be.servicecatalog.dto;

import java.math.BigDecimal;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ServiceResponse {
  private UUID id;
  private String name;
  private String description;
  private Integer durationMinutes;
  private BigDecimal basePrice;
  private String pricingUnit;
}
