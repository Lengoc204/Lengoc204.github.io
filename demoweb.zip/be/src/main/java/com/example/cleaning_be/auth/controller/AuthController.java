package com.example.cleaning_be.auth.controller;

import com.example.cleaning_be.auth.dto.JwtResponse;
import com.example.cleaning_be.auth.dto.LoginRequest;
import com.example.cleaning_be.auth.dto.LogoutRequest;
import com.example.cleaning_be.auth.dto.RefreshTokenRequest;
import com.example.cleaning_be.auth.dto.SignupRequest;
import com.example.cleaning_be.auth.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

  private final AuthService authService;

  @PostMapping("/register")
  public ResponseEntity<JwtResponse> register(@Valid @RequestBody SignupRequest request) {
    return ResponseEntity.ok(authService.signup(request));
  }

  @PostMapping("/login")
  public ResponseEntity<JwtResponse> login(@Valid @RequestBody LoginRequest request) {
    return ResponseEntity.ok(authService.login(request));
  }

  @PostMapping("/refresh")
  public ResponseEntity<JwtResponse> refresh(@Valid @RequestBody RefreshTokenRequest request) {
    return ResponseEntity.ok(authService.refresh(request));
  }

  @PostMapping("/logout")
  @PreAuthorize("isAuthenticated()")
  public ResponseEntity<Void> logout(
      @Valid @RequestBody LogoutRequest request, Authentication authentication) {
    authService.logout(request, authentication.getName());
    return ResponseEntity.noContent().build();
  }
}
