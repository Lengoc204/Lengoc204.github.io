package com.example.cleaning_be.user.service;

import com.example.cleaning_be.address.dto.AddressRequest;
import com.example.cleaning_be.address.dto.AddressResponse;
import com.example.cleaning_be.address.entity.Address;
import com.example.cleaning_be.address.repository.AddressRepository;
import com.example.cleaning_be.booking.repository.BookingRepository;
import com.example.cleaning_be.common.exception.BadRequestException;
import com.example.cleaning_be.common.exception.ErrorCode;
import com.example.cleaning_be.common.exception.ResourceNotFoundException;
import com.example.cleaning_be.mapper.UserMapper;
import com.example.cleaning_be.payment.dto.PaymentMethodRequest;
import com.example.cleaning_be.payment.dto.PaymentMethodResponse;
import com.example.cleaning_be.payment.entity.UserPaymentMethod;
import com.example.cleaning_be.payment.repository.UserPaymentMethodRepository;
import com.example.cleaning_be.user.dto.ChangePasswordRequest;
import com.example.cleaning_be.user.dto.UpdateUserProfileRequest;
import com.example.cleaning_be.user.dto.UpdateUserStatusRequest;
import com.example.cleaning_be.user.dto.UserProfileResponse;
import com.example.cleaning_be.user.entity.User;
import com.example.cleaning_be.user.entity.UserStatus;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class UserSettingsService {

  private final UserService userService;
  private final AddressRepository addressRepository;
  private final UserPaymentMethodRepository userPaymentMethodRepository;
  private final BookingRepository bookingRepository;
  private final PasswordEncoder passwordEncoder;
  private final UserMapper userMapper;

  @Transactional
  public UserProfileResponse updateProfile(UUID userId, UpdateUserProfileRequest request) {
    User user = userService.getById(userId);
    user.setFullName(request.getFullName());
    user.setPhone(request.getPhone());
    user.setAvatarUrl(request.getAvatarUrl());
    return userMapper.toProfile(userService.save(user));
  }

  @Transactional
  public void changePassword(UUID userId, ChangePasswordRequest request) {
    User user = userService.getById(userId);
    if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPasswordHash())) {
      throw new BadRequestException("Mật khẩu hiện tại không đúng");
    }
    if (passwordEncoder.matches(request.getNewPassword(), user.getPasswordHash())) {
      throw new BadRequestException("Mật khẩu mới phải khác mật khẩu hiện tại");
    }
    user.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
    userService.save(user);
  }

  @Transactional
  public AddressResponse addAddress(UUID userId, AddressRequest request) {
    User user = userService.getById(userId);
    Address address = userMapper.toAddress(request);
    address.setUser(user);
    if (request.isDefaultAddress()) {
      unsetDefaultAddress(userId);
      address.setDefaultAddress(true);
    }
    Address saved = addressRepository.save(address);
    return toAddressResponse(saved);
  }

  @Transactional
  public AddressResponse updateAddress(UUID userId, UUID addressId, AddressRequest request) {
    Address address =
        addressRepository
            .findById(addressId)
            .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.ADDRESS_NOT_FOUND));
    if (!address.getUser().getId().equals(userId)) {
      throw new BadRequestException("Bạn không thể cập nhật địa chỉ này");
    }
    address.setLabel(request.getLabel());
    address.setStreet(request.getStreet());
    address.setWard(request.getWard());
    address.setDistrict(request.getDistrict());
    address.setCity(request.getCity());
    address.setProvince(request.getProvince());
    address.setLatitude(request.getLatitude());
    address.setLongitude(request.getLongitude());
    if (request.isDefaultAddress()) {
      unsetDefaultAddress(userId);
    }
    address.setDefaultAddress(request.isDefaultAddress());
    Address saved = addressRepository.save(address);
    return toAddressResponse(saved);
  }

  @Transactional
  public void deleteAddress(UUID userId, UUID addressId) {
    Address address =
        addressRepository
            .findById(addressId)
            .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.ADDRESS_NOT_FOUND));
    if (!address.getUser().getId().equals(userId)) {
      throw new BadRequestException("Bạn không thể xóa địa chỉ này");
    }
    if (bookingRepository.existsByAddressId(addressId)) {
      throw new BadRequestException("Địa chỉ này đã được sử dụng cho đơn đặt dịch vụ và không thể xóa.");
    }
    addressRepository.delete(address);
  }

  @Transactional
  public PaymentMethodResponse addPaymentMethod(UUID userId, PaymentMethodRequest request) {
    User user = userService.getById(userId);
    UserPaymentMethod method =
        UserPaymentMethod.builder()
            .user(user)
            .method(request.getMethod())
            .displayName(request.getDisplayName())
            .provider(request.getProvider())
            .maskedNumber(maskAccountNumber(request.getAccountNumber()))
            .defaultMethod(request.isDefaultMethod())
            .build();
    if (request.isDefaultMethod()) {
      unsetDefaultPayment(userId);
    }
    UserPaymentMethod saved = userPaymentMethodRepository.save(method);
    return toPaymentMethodResponse(saved);
  }

  @Transactional
  public PaymentMethodResponse updatePaymentMethod(
      UUID userId, UUID methodId, PaymentMethodRequest request) {
    UserPaymentMethod method =
        userPaymentMethodRepository
            .findByIdAndUserId(methodId, userId)
            .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.PAYMENT_METHOD_NOT_FOUND));
    method.setMethod(request.getMethod());
    method.setDisplayName(request.getDisplayName());
    method.setProvider(request.getProvider());
    if (StringUtils.hasText(request.getAccountNumber())) {
      method.setMaskedNumber(maskAccountNumber(request.getAccountNumber()));
    }
    if (request.isDefaultMethod()) {
      unsetDefaultPayment(userId);
    }
    method.setDefaultMethod(request.isDefaultMethod());
    UserPaymentMethod saved = userPaymentMethodRepository.save(method);
    return toPaymentMethodResponse(saved);
  }

  @Transactional
  public void deletePaymentMethod(UUID userId, UUID methodId) {
    UserPaymentMethod method =
        userPaymentMethodRepository
            .findByIdAndUserId(methodId, userId)
            .orElseThrow(() -> new ResourceNotFoundException(ErrorCode.PAYMENT_METHOD_NOT_FOUND));
    userPaymentMethodRepository.delete(method);
  }

  @Transactional(readOnly = true)
  public UserProfileResponse getProfile(UUID userId) {
    return userMapper.toProfile(userService.getById(userId));
  }

  @Transactional(readOnly = true)
  public List<AddressResponse> getAddresses(UUID userId) {
    userService.getById(userId);
    return addressRepository.findByUserId(userId).stream().map(this::toAddressResponse).toList();
  }

  @Transactional(readOnly = true)
  public List<PaymentMethodResponse> getPaymentMethods(UUID userId) {
    userService.getById(userId);
    return userPaymentMethodRepository.findByUserId(userId).stream()
        .map(this::toPaymentMethodResponse)
        .toList();
  }

  @Transactional
  public UserProfileResponse updateStatus(UUID userId, UpdateUserStatusRequest request) {
    User user = userService.getById(userId);
    user.setStatus(request.isActive() ? UserStatus.ACTIVE : UserStatus.INACTIVE);
    return userMapper.toProfile(userService.save(user));
  }

  private void unsetDefaultAddress(UUID userId) {
    List<Address> addresses = addressRepository.findByUserId(userId);
    addresses.stream()
        .filter(Address::isDefaultAddress)
        .forEach(
            address -> {
              address.setDefaultAddress(false);
              addressRepository.save(address);
            });
  }

  private void unsetDefaultPayment(UUID userId) {
    userPaymentMethodRepository.findByUserId(userId).stream()
        .filter(UserPaymentMethod::isDefaultMethod)
        .forEach(
            method -> {
              method.setDefaultMethod(false);
              userPaymentMethodRepository.save(method);
            });
  }

  private AddressResponse toAddressResponse(Address address) {
    return AddressResponse.builder()
        .id(address.getId())
        .label(address.getLabel())
        .street(address.getStreet())
        .ward(address.getWard())
        .district(address.getDistrict())
        .city(address.getCity())
        .province(address.getProvince())
        .latitude(address.getLatitude())
        .longitude(address.getLongitude())
        .defaultAddress(address.isDefaultAddress())
        .build();
  }

  private PaymentMethodResponse toPaymentMethodResponse(UserPaymentMethod method) {
    return PaymentMethodResponse.builder()
        .id(method.getId())
        .method(method.getMethod())
        .displayName(method.getDisplayName())
        .provider(method.getProvider())
        .maskedNumber(method.getMaskedNumber())
        .defaultMethod(method.isDefaultMethod())
        .build();
  }

  private String maskAccountNumber(String accountNumber) {
    if (!StringUtils.hasText(accountNumber)) {
      return null;
    }
    String trimmed = accountNumber.replaceAll("\\s+", "");
    if (trimmed.length() <= 4) {
      return trimmed;
    }
    String last4 = trimmed.substring(trimmed.length() - 4);
    return "****" + last4;
  }
}
