package com.example.cleaning_be.auth.dto;

import com.example.cleaning_be.address.dto.AddressRequest;
import com.example.cleaning_be.user.entity.Role;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignupRequest {

  @Email(message = "Email is invalid")
  @NotBlank(message = "Email is required")
  private String email;

  @NotBlank(message = "Full name is required")
  private String fullName;

  @Size(min = 6, message = "Password must be at least 6 characters")
  private String password;
  @NotBlank(message = "Phone number is required")
  private String phone;

  private Role role;

  @Valid private AddressRequest defaultAddress;
}
