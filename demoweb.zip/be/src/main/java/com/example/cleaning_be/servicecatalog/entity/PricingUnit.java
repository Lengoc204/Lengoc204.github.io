package com.example.cleaning_be.servicecatalog.entity;

public enum PricingUnit {
  PER_HOUR,
  PER_VISIT,
  PER_SQUARE_METER
}
