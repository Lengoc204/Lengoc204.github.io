package com.example.cleanbe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CleanbeApplicationTests {

  @Test
  void contextLoads() {}
}
