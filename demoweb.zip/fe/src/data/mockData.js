export const HERO_CARDS = [
  {
    id: 'card-1',
    image: '/images/Card.png',
    badge: 'Best rated',
    emojis: ['😡', '😕', '😐', '😊', '😍'],
  },
  {
    id: 'card-2',
    image: '/images/Image (2).png',
    stats: '30,000+',
    caption: 'Versioned clean ups',
  },
  {
    id: 'card-3',
    image: '/images/nguoi.png',
  },
]

export const SERVICES = [
  {
    title: 'Standard Cleaning',
    description: 'Phù hợp dọn dẹp định kỳ cho căn hộ & nhà riêng.',
    duration: '2-3h',
  },
  {
    title: 'Deep Cleaning',
    description: 'Xử lý các khu vực khó nhằn, vệ sinh tổng thể mùa lễ.',
    duration: '4-5h',
  },
  {
    title: 'Move-in/out',
    description: 'Làm sạch toàn bộ nhà trước khi chuyển dọn.',
    duration: '5-6h',
  },
]

export const USERS = [
  { username: 'admin', password: '123456', role: 'admin' },
  { username: 'staff', password: '123456', role: 'staff' },
  { username: 'customer', password: '123456', role: 'customer' },
]

export const adminData = {
  name: 'Quản trị viên',
  stats: [
    // { title: 'Tổng đơn hàng', value: '1,245', trend: '+12% MoM' },
    // { title: 'Nhân viên hoạt động', value: '35', trend: '4 đang nghỉ' },
    { title: 'Đánh giá trung bình', value: '4.8/5', trend: '182 review mới' },
  ],
  recentOrders: [
    { id: '#1001', customer: 'Nguyễn B', service: 'Dọn dẹp chuyên sâu', status: 'Hoàn thành', amount: '800K' },
    { id: '#1002', customer: 'Lê C', service: 'Vệ sinh kính', status: 'Đã hủy', amount: '350K' },
    { id: '#1003', customer: 'Phạm D', service: 'Combo tổng vệ sinh', status: 'Đang làm', amount: '1.2M' },
    { id: '#1004', customer: 'Trần E', service: 'Tổng vệ sinh nhà', status: 'Chờ thanh toán', amount: '1.5M' },
  ],
  staff: [
    { name: 'Nguyễn Văn Quang', role: 'Trưởng nhóm', jobs: 186, rating: 4.9 },
    { name: 'Lê Thị Hà', role: 'Deep clean', jobs: 142, rating: 4.7 },
    { name: 'Trần Thu Mai', role: 'Window care', jobs: 124, rating: 4.8 },
  ],
  feedback: [
    { id: '#F101', customer: 'Hoàng Lan', rating: 5, comment: 'Dịch vụ rất chuyên nghiệp và đúng giờ.' },
    { id: '#F099', customer: 'Đỗ Minh', rating: 4, comment: 'Cần thêm thời gian xử lý bếp nhưng vẫn hài lòng.' },
  ],
}

export const staffData = {
  name: 'Nguyễn Văn A',
  currentJob: {
    id: '#B-2056',
    status: 'Đang di chuyển',
    service: 'Dọn dẹp cao cấp',
    client: 'Lê Thị Bích',
    address: '123 Đường ABC, Quận 5, TP.HCM',
    time: '14:00 - 16:00 hôm nay',
  },
  schedule: [
    { time: '09:00 - 11:00', description: 'Dọn dẹp Tiêu chuẩn', code: '#B-345', status: 'Hoàn thành' },
    { time: '14:00 - 16:00', description: 'Dọn dẹp Cao cấp', code: '#A-123', status: 'Đang diễn ra' },
    { time: '17:00 - 19:00', description: 'Vệ sinh kính', code: '#C-789', status: 'Chờ bắt đầu' },
  ],
  notifications: [
    { type: 'HỆ THỐNG', content: 'Bạn được giao công việc #B-2057 vào 9:00 ngày mai.', time: '15 phút trước' },
    { type: 'QUẢN LÝ', content: 'Cập nhật chính sách thưởng mới Q3.', time: 'Hôm qua' },
    { type: 'HỆ THỐNG', content: 'Khách hàng #A-123 đã xác nhận.', time: '2 ngày trước' },
  ],
  profile: {
    title: 'Senior Cleaner',
    rating: 4.9,
    jobsCompleted: 42,
    onTimeRate: '98%',
    acceptanceRate: '100%',
  },
}

export const customerData = {
  user: {
    name: 'Nguyễn Văn A',
    email: 'nguyenvana@example.com',
    phone: '+84 912 345 678',
    address: '19 Hàng Buồm, Hà Nội',
    addresses: [
      {
        id: 'addr-1',
        label: 'Nhà riêng',
        street: '19 Hàng Buồm, Hà Nội',
        defaultAddress: true,
      },
      {
        id: 'addr-2',
        label: 'Văn phòng',
        street: '220 Cầu Giấy, Hà Nội',
        defaultAddress: false,
      },
    ],
  },
  availableServices: [
    { id: 'svc-home', name: 'Home Cleaning' },
    { id: 'svc-delivery', name: 'Package Delivery' },
    { id: 'svc-carwash', name: 'Car Wash' },
  ],
  orders: [
    { id: '#05', service: 'Car Wash', date: '2025-11-10', status: 'Đã lên lịch', amount: 220000 },
    { id: '#01', service: 'Home Cleaning', date: '2025-11-08', status: 'Đang di chuyển', amount: 350000 },
    { id: '#03', service: 'Package Delivery', date: '2025-11-07', status: 'Hoàn thành', amount: 250000 },
    { id: '#04', service: 'Home Cleaning', date: '2025-11-06', status: 'Hoàn thành', amount: 300000 },
  ],
  payments: [
    { id: '#P01', orderId: '#03', date: '2025-11-07', amount: 250000, status: 'Đã thanh toán' },
    { id: '#P02', orderId: '#04', date: '2025-11-06', amount: 300000, status: 'Đã thanh toán' },
    { id: '#P03', orderId: '#01', date: '2025-11-08', amount: 350000, status: 'Chờ xử lý' },
  ],
}
