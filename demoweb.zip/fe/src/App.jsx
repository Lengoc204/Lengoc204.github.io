import { useEffect, useState, useCallback } from 'react'
import { Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom'
import Navbar from './components/layout/Navbar'
import Footer from './components/layout/Footer'
import HomePage from './pages/HomePage'
import AdminDashboard from './pages/AdminDashboard'
import StaffWorkspace from './pages/StaffWorkspace'
import CustomerPortal from './pages/CustomerPortal'
import LoginModal from './components/modals/LoginModal'
import SignupModal from './components/modals/SignupModal'
import { loadAuthSession, saveAuthSession, clearAuthSession } from './services/authStorage'
import { logout as logoutApi, refresh as refreshApi } from './services/authService'

const roleRouteMap = {
  ADMIN: '/admin',
  STAFF: '/staff',
  CUSTOMER: '/customer',
}

const normalizeSession = (session) => {
  if (!session) return null
  const normalizedUser = {
    ...session.user,
    role: session.user?.role?.toUpperCase() || '',
  }
  return { ...session, user: normalizedUser }
}

function App() {
  const navigate = useNavigate()
  const location = useLocation()
  const [modals, setModals] = useState({ login: false, signup: false })
  const [session, setSession] = useState(() => normalizeSession(loadAuthSession()))
  const [user, setUser] = useState(() => session?.user ?? null)

  const openLogin = () => setModals((prev) => ({ ...prev, login: true }))
  const openSignup = () => setModals((prev) => ({ ...prev, signup: true }))
  const closeLogin = () => setModals((prev) => ({ ...prev, login: false }))
  const closeSignup = () => setModals((prev) => ({ ...prev, signup: false }))

  useEffect(() => {
    const stored = normalizeSession(loadAuthSession())
    if (stored) {
      setSession(stored)
      setUser(stored.user)
    }
  }, [])

  const handleBookNow = () => {
    navigate('/', { state: { sectionId: 'contact' } })
    openSignup()
  }

  const clearSessionState = useCallback(() => {
    setSession(null)
    setUser(null)
    clearAuthSession()
  }, [])

  const handleLoginSuccess = (authResponse) => {
    const normalized = normalizeSession(authResponse)
    setSession(normalized)
    setUser(normalized.user)
    saveAuthSession(normalized)
    setModals({ login: false, signup: false })
    const destination = roleRouteMap[normalized.user.role] || '/'
    navigate(destination, { replace: true })
  }

  const handleLogout = useCallback(async () => {
    if (session?.refreshToken && session?.accessToken) {
      try {
        await logoutApi({ refreshToken: session.refreshToken, accessToken: session.accessToken })
      } catch (error) {
        console.warn('Logout failed:', error.message)
      }
    }
    clearSessionState()
    navigate('/', { replace: true })
  }, [session, navigate, clearSessionState])

  const refreshSessionToken = useCallback(async () => {
    if (!session?.refreshToken) {
      clearSessionState()
      return null
    }
    try {
      const refreshed = await refreshApi(session.refreshToken)
      const normalized = normalizeSession(refreshed)
      setSession(normalized)
      setUser(normalized.user)
      saveAuthSession(normalized)
      return normalized
    } catch (error) {
      clearSessionState()
      return null
    }
  }, [session?.refreshToken, clearSessionState])

  const PrivateRoute = ({ children, allowedRoles }) => {
    if (!user) {
      return <Navigate to="/" replace />
    }
    if (allowedRoles && !allowedRoles.includes(user.role)) {
      const fallback = roleRouteMap[user.role] || '/'
      return <Navigate to={fallback} replace />
    }
    return children
  }

  const isDashboardRoute = ['/admin', '/staff', '/customer'].some((path) => location.pathname.startsWith(path))

  return (
    <div className="app-shell">
      {!isDashboardRoute && <Navbar onLogin={openLogin} onSignup={openSignup} onBookNow={handleBookNow} />}
      <Routes>
        <Route path="/" element={<HomePage onSignup={openSignup} onBookNow={handleBookNow} />} />
        <Route
          path="/admin"
          element={
            <PrivateRoute allowedRoles={['ADMIN']}>
              <AdminDashboard
                onLogout={handleLogout}
                session={session}
                refreshSession={refreshSessionToken}
              />
            </PrivateRoute>
          }
        />
        <Route
          path="/staff"
          element={
            <PrivateRoute allowedRoles={['STAFF']}>
              <StaffWorkspace
                onLogout={handleLogout}
                user={user}
                session={session}
                refreshSession={refreshSessionToken}
              />
            </PrivateRoute>
          }
        />
        <Route
          path="/customer"
          element={
            <PrivateRoute allowedRoles={['CUSTOMER']}>
              <CustomerPortal
                onLogout={handleLogout}
                user={user}
                session={session}
                refreshSession={refreshSessionToken}
              />
            </PrivateRoute>
          }
        />
        <Route
          path="*"
          element={
            <main className="page-shell">
              <div className="card centered">
                <h2>Không tìm thấy trang</h2>
                <p>Liên kết bạn truy cập hiện không tồn tại.</p>
              </div>
            </main>
          }
        />
      </Routes>
      {!isDashboardRoute && <Footer />}

      <LoginModal
        isOpen={modals.login}
        onClose={closeLogin}
        onOpenSignup={openSignup}
        onAuthenticated={handleLoginSuccess}
      />
      <SignupModal isOpen={modals.signup} onClose={closeSignup} onOpenLogin={openLogin} />
    </div>
  )
}

export default App
