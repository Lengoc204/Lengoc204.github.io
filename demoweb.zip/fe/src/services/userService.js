import { authorizedRequest } from './apiClient'

const settingsPath = (userId, suffix = '') => `/users/${userId}/settings${suffix}`

export function fetchUserProfile(userId, session, refreshSession) {
  return authorizedRequest(settingsPath(userId, '/profile'), {}, session, refreshSession)
}

export function updateUserProfile(userId, payload, session, refreshSession) {
  return authorizedRequest(
    settingsPath(userId, '/profile'),
    {
      method: 'PUT',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}

export function changePassword(userId, payload, session, refreshSession) {
  return authorizedRequest(
    settingsPath(userId, '/password'),
    {
      method: 'PUT',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}

export function fetchAddresses(userId, session, refreshSession) {
  return authorizedRequest(settingsPath(userId, '/addresses'), {}, session, refreshSession)
}

export function createAddress(userId, payload, session, refreshSession) {
  return authorizedRequest(
    settingsPath(userId, '/addresses'),
    {
      method: 'POST',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}

export function updateAddress(userId, addressId, payload, session, refreshSession) {
  return authorizedRequest(
    settingsPath(userId, `/addresses/${addressId}`),
    {
      method: 'PUT',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}

export function deleteAddress(userId, addressId, session, refreshSession) {
  return authorizedRequest(
    settingsPath(userId, `/addresses/${addressId}`),
    {
      method: 'DELETE',
    },
    session,
    refreshSession,
  )
}

export function fetchPaymentMethods(userId, session, refreshSession) {
  return authorizedRequest(settingsPath(userId, '/payments'), {}, session, refreshSession)
}

export function createPaymentMethod(userId, payload, session, refreshSession) {
  return authorizedRequest(
    settingsPath(userId, '/payments'),
    {
      method: 'POST',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}

export function updatePaymentMethod(userId, methodId, payload, session, refreshSession) {
  return authorizedRequest(
    settingsPath(userId, `/payments/${methodId}`),
    {
      method: 'PUT',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}

export function deletePaymentMethod(userId, methodId, session, refreshSession) {
  return authorizedRequest(
    settingsPath(userId, `/payments/${methodId}`),
    {
      method: 'DELETE',
    },
    session,
    refreshSession,
  )
}

export function fetchUsersByRole(role, session, refreshSession) {
  const query = role && role !== 'ALL' ? `?role=${role}` : ''
  return authorizedRequest(`/admin/users${query}`, {}, session, refreshSession)
}

export function fetchLoginHistory(targetUserId, session, refreshSession) {
  return authorizedRequest(
    `/admin/users/${targetUserId}/logins`,
    {},
    session,
    refreshSession,
  )
}

export function updateAccountStatus(userId, payload, session, refreshSession) {
  return authorizedRequest(
    settingsPath(userId, '/status'),
    {
      method: 'PUT',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}
