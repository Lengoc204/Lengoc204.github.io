import { authorizedRequest } from './apiClient'

export function fetchCleanerProfile(userId, session, refreshSession) {
  return authorizedRequest(
    `/cleaners/profile?userId=${userId}`,
    {},
    session,
    refreshSession,
  )
}

export function updateCleanerProfile(payload, session, refreshSession) {
  return authorizedRequest(
    '/cleaners/profile',
    {
      method: 'PUT',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}
