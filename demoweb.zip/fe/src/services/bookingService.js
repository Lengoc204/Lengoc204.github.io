import { authorizedRequest } from './apiClient'

export function fetchCustomerBookings(customerId, session, refreshSession) {
  const url = `/bookings/customer_summary?customerId=${customerId}`
  return authorizedRequest(url, {}, session, refreshSession)
}

export function createBooking(payload, session, refreshSession) {
  return authorizedRequest(
    '/bookings',
    {
      method: 'POST',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}

export function fetchActiveServices(session, refreshSession) {
  return authorizedRequest('/services/active', {}, session, refreshSession)
}

export function fetchPendingBookings(session, refreshSession, status = 'PENDING') {
  const url = `/bookings/pending?status=${status}`
  return authorizedRequest(url, {}, session, refreshSession)
}

export function claimBooking(bookingId, payload, session, refreshSession) {
  return authorizedRequest(
    `/bookings/${bookingId}/claim`,
    {
      method: 'POST',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}

export function fetchStaffSchedule(staffId, session, refreshSession) {
  const url = `/bookings/staff_schedule?staffId=${staffId}`
  return authorizedRequest(url, {}, session, refreshSession)
}

export function releaseBooking(bookingId, payload, session, refreshSession) {
  return authorizedRequest(
    `/bookings/${bookingId}/release`,
    {
      method: 'POST',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}

export function updateBookingStatus(bookingId, payload, session, refreshSession) {
  return authorizedRequest(
    `/bookings/${bookingId}/status`,
    {
      method: 'PUT',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}

export function fetchStaffEarnings(staffId, session, refreshSession) {
  const url = `/bookings/staff/earnings?staffId=${staffId}`
  return authorizedRequest(url, {}, session, refreshSession)
}

export function fetchCustomerPayments(customerId, session, refreshSession) {
  const url = `/bookings/customer_payments?customerId=${customerId}`
  return authorizedRequest(url, {}, session, refreshSession)
}
