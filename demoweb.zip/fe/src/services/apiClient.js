const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8080/api/v1'

async function parseResponse(response) {
  const contentType = response.headers.get('content-type') || ''
  const isJson = contentType.includes('application/json')
  const data = isJson ? await response.json() : null

  if (!response.ok) {
    const message = data?.message || 'Đã xảy ra lỗi không xác định'
    const error = new Error(message)
    error.status = response.status
    throw error
  }

  return data
}

export async function authorizedRequest(path, options = {}, session, refreshSession) {
  if (!session?.accessToken) {
    throw new Error('Bạn cần đăng nhập để thực hiện thao tác này')
  }

  const send = async (token) => {
    const headers = {
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...(options.headers ?? {}),
      Authorization: `Bearer ${token}`,
    }

    return fetch(`${API_BASE_URL}${path}`, {
      ...options,
      headers,
    })
  }

  let response = await send(session.accessToken)

  if (response.status === 401 && session?.refreshToken && refreshSession) {
    const refreshedSession = await refreshSession()
    if (refreshedSession?.accessToken) {
      response = await send(refreshedSession.accessToken)
    }
  }

  if (response.status === 401) {
    throw new Error('Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại')
  }

  return parseResponse(response)
}
