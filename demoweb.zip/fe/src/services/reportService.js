import { authorizedRequest } from './apiClient'

export function fetchMonthlyRevenue(months = 6, session, refreshSession) {
  const params = new URLSearchParams({ months })
  return authorizedRequest(`/reports/revenue/monthly?${params.toString()}`, {}, session, refreshSession)
}

export function fetchAdminSummary(session, refreshSession) {
  return authorizedRequest('/reports/admin/summary', {}, session, refreshSession)
}

export function fetchAdminPipeline(count = 5, session, refreshSession) {
  const params = new URLSearchParams({ count })
  return authorizedRequest(`/reports/admin/pipeline?${params.toString()}`, {}, session, refreshSession)
}

export function fetchFeaturedBooking(session, refreshSession) {
  return authorizedRequest('/reports/admin/featured', {}, session, refreshSession)
}
