import { authorizedRequest } from './apiClient'

export function mockPayment(bookingId, payload, session, refreshSession) {
  return authorizedRequest(
    `/payments/${bookingId}/mock`,
    {
      method: 'POST',
      body: JSON.stringify(payload),
    },
    session,
    refreshSession,
  )
}

