import { useLocation, useNavigate } from 'react-router-dom'

const navItems = [
  { label: 'Home', section: 'hero' },
  { label: 'Services', section: 'services' },
  { label: 'Pricing', section: 'pricing' },
  { label: 'About Us', section: 'about' },
  { label: 'FAQ', section: 'faq' },
  { label: 'Contact', section: 'contact' },
]

const Navbar = ({ onLogin, onSignup, onBookNow }) => {
  const location = useLocation()
  const navigate = useNavigate()
  const isHome = location.pathname === '/'

  const scrollToSection = (sectionId) => {
    if (location.pathname !== '/') {
      navigate('/', { state: { sectionId } })
      return
    }

    const section = document.getElementById(sectionId)
    section?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <header className={`navbar ${location.pathname !== '/' ? 'navbar-solid' : ''}`}>
      <div className="logo">Home Cleaning</div>
      <div className="navbar-right">
        <nav>
          {navItems.map((item) => {
            const active = isHome && item.section === 'hero'
            return (
              <button
                key={item.section}
                type="button"
                className={`nav-link ${active ? 'active' : ''}`}
                onClick={() => scrollToSection(item.section)}
              >
                {item.label}
              </button>
            )
          })}
        </nav>
        <div className="navbar-actions">
          <button type="button" className="btn-login" onClick={onLogin}>
            Login
          </button>
          <button type="button" className="btn-signup" onClick={onSignup}>
            Sign Up
          </button>
          <button type="button" className="btn-book" onClick={onBookNow}>
            Book Now
          </button>
        </div>
      </div>
    </header>
  )
}

export default Navbar
