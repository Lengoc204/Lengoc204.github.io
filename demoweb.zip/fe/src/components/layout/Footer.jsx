const Footer = () => (
  <footer>
    <div className="footer-content">
      <div className="review">
        <p>⭐️⭐️⭐️⭐️⭐️ Loved the service? Leave a review</p>
      </div>
      <div className="footer-buttons">
        <button type="button" className="btn-feedback">💬 Leave Feedback</button>
        <button type="button" className="btn-primary">📅 Book Now</button>
      </div>
    </div>
    <p className="footnote">© 2025 Home Cleaning. All rights reserved.</p>
  </footer>
)

export default Footer
