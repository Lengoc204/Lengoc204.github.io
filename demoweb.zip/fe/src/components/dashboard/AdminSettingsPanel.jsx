import { useEffect, useState } from 'react'
import {
  fetchUsersByRole,
  fetchLoginHistory,
  updateAccountStatus,
} from '../../services/userService'

const roleFilters = [
  { value: 'ALL', label: 'Tất cả' },
  { value: 'ADMIN', label: 'Admin' },
  { value: 'STAFF', label: 'Staff' },
  { value: 'CUSTOMER', label: 'Customer' },
]

const AdminSettingsPanel = ({ session, refreshSession }) => {
  const [selectedRole, setSelectedRole] = useState('ALL')
  const [users, setUsers] = useState([])
  const [usersLoading, setUsersLoading] = useState(false)
  const [usersError, setUsersError] = useState('')
  const [statusLoadingId, setStatusLoadingId] = useState(null)
  const [historyModal, setHistoryModal] = useState({
    open: false,
    user: null,
    entries: [],
    loading: false,
    error: '',
  })

  const hasSession = Boolean(session)

  useEffect(() => {
    if (hasSession) {
      loadUsers(selectedRole)
    }
  }, [selectedRole, hasSession])

  const loadUsers = async (role) => {
    try {
      setUsersLoading(true)
      const list = await fetchUsersByRole(role, session, refreshSession)
      setUsers(list)
      setUsersError('')
    } catch (error) {
      setUsersError(error.message || 'Không thể tải danh sách người dùng')
    } finally {
      setUsersLoading(false)
    }
  }

  const handleToggleStatus = async (user) => {
    if (user.role === 'ADMIN') return
    setStatusLoadingId(user.id)
    setUsersError('')
    try {
      await updateAccountStatus(user.id, { active: user.status !== 'ACTIVE' }, session, refreshSession)
      await loadUsers(selectedRole)
    } catch (error) {
      setUsersError(error.message || 'Không thể cập nhật trạng thái người dùng')
    } finally {
      setStatusLoadingId(null)
    }
  }

  const openHistoryModal = async (user) => {
    setHistoryModal({ open: true, user, entries: [], loading: true, error: '' })
    try {
      const data = await fetchLoginHistory(user.id, session, refreshSession)
      setHistoryModal((prev) => ({ ...prev, entries: data, loading: false }))
    } catch (error) {
      setHistoryModal((prev) => ({
        ...prev,
        loading: false,
        error: error.message || 'Không thể tải lịch sử đăng nhập',
      }))
    }
  }

  const closeHistoryModal = () =>
    setHistoryModal({
      open: false,
      user: null,
      entries: [],
      loading: false,
      error: '',
    })

  if (!hasSession) {
    return (
      <section className="panel">
        <h2>Cài đặt quản trị</h2>
        <p className="text-muted">Vui lòng đăng nhập để xem dữ liệu người dùng.</p>
      </section>
    )
  }

  return (
    <div className="panel-grid two">
      <article className="panel">
        <div className="panel-header">
          <div>
            <h2>Quản lý người dùng</h2>
            <p className="text-muted">Theo dõi trạng thái và lịch sử truy cập</p>
          </div>
          <select
            value={selectedRole}
            onChange={(event) => setSelectedRole(event.target.value)}
            className="input"
          >
            {roleFilters.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        {usersLoading ? (
          <p className="text-muted">Đang tải...</p>
        ) : usersError ? (
          <p className="form-error">{usersError}</p>
        ) : (
          <div
            className="table-wrapper"
            style={{ maxHeight: '420px', overflowY: 'auto', borderRadius: '0.75rem' }}
          >
            <table>
              <thead>
                <tr>
                  <th>Họ tên</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Trạng thái</th>
                  <th colSpan={2} style={{ minWidth: '160px' }}>
                    Thao tác
                  </th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => {
                  const canToggle = user.role === 'STAFF' || user.role === 'CUSTOMER'
                  return (
                    <tr key={user.id}>
                      <td>{user.fullName}</td>
                      <td>{user.email}</td>
                      <td>{user.role}</td>
                      <td>
                        <span className={`pill ${user.status === 'ACTIVE' ? 'success' : 'warning'}`}>
                          {user.status}
                        </span>
                      </td>
                      <td>
                        <button
                          type="button"
                          className="btn-text"
                          onClick={() => openHistoryModal(user)}
                        >
                          Xem lịch sử
                        </button>
                      </td>
                      <td>
                        <button
                          type="button"
                          className="btn-text danger"
                          disabled={
                            !canToggle || statusLoadingId === user.id || !session
                          }
                          onClick={() => handleToggleStatus(user)}
                        >
                          {statusLoadingId === user.id
                            ? 'Đang xử lý...'
                            : user.status === 'ACTIVE'
                              ? 'Vô hiệu'
                              : 'Kích hoạt'}
                        </button>
                      </td>
                    </tr>
                  )
                })}
                {users.length === 0 && (
                  <tr>
                    <td colSpan={6} className="text-muted" style={{ textAlign: 'center' }}>
                      Không có người dùng nào trong nhóm này
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </article>

      <article className="panel">
        <div className="panel-header">
          <div>
            <h2>Ghi chú bảo mật</h2>
          </div>
        </div>
        <p className="text-muted">
          • Sử dụng “Vô hiệu” để tạm khóa tài khoản khách hàng/staff.<br />
          • Nhấn “Xem lịch sử” để mở chi tiết đăng nhập trong một cửa sổ riêng có thể cuộn.<br />
          • Các hoạt động đăng nhập đáng ngờ nên được xử lý trong vòng 24 giờ.
        </p>
      </article>

      {historyModal.open && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(15, 23, 42, 0.45)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 30,
            padding: '1rem',
          }}
        >
          <div
            className="panel"
            style={{
              width: 'min(600px, 100%)',
              maxHeight: '80vh',
              display: 'flex',
              flexDirection: 'column',
              overflow: 'hidden',
            }}
          >
            <div className="panel-header" style={{ justifyContent: 'space-between' }}>
              <div>
                <p className="eyebrow">Lịch sử đăng nhập</p>
                <h3>{historyModal.user?.fullName}</h3>
              </div>
              <button type="button" className="btn-text" onClick={closeHistoryModal}>
                Đóng
              </button>
            </div>
            <div style={{ overflowY: 'auto', paddingRight: '0.25rem' }}>
              {historyModal.loading ? (
                <p className="text-muted">Đang tải dữ liệu...</p>
              ) : historyModal.error ? (
                <p className="form-error">{historyModal.error}</p>
              ) : historyModal.entries.length === 0 ? (
                <p className="text-muted">Chưa ghi nhận đăng nhập nào gần đây.</p>
              ) : (
                <ul className="list">
                  {historyModal.entries.map((entry) => (
                    <li key={`${entry.loginAt}-${entry.ipAddress}`}>
                      <div>
                        <strong>
                          {new Date(entry.loginAt).toLocaleString('vi-VN', {
                            dateStyle: 'medium',
                            timeStyle: 'short',
                          })}
                        </strong>
                        <p>IP: {entry.ipAddress || 'Không rõ'}</p>
                        <p className="text-muted">{entry.userAgent || 'Unknown agent'}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default AdminSettingsPanel
