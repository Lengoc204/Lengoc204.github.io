import { useCallback, useEffect, useMemo, useState } from 'react'
import {
  fetchUserProfile,
  updateUserProfile,
  changePassword,
  fetchAddresses,
  createAddress,
  updateAddress as updateAddressApi,
  deleteAddress as deleteAddressApi,
  fetchPaymentMethods,
  createPaymentMethod,
  updatePaymentMethod as updatePaymentMethodApi,
  deletePaymentMethod as deletePaymentMethodApi,
  updateAccountStatus,
} from '../../services/userService'

const paymentOptions = [
  { value: 'CASH', label: 'Tiền mặt' },
  { value: 'BANK_TRANSFER', label: 'Chuyển khoản' },
  { value: 'VNPAY', label: 'VNPay' },
]

const blankAddress = {
  label: '',
  street: '',
  city: '',
  province: '',
  defaultAddress: false,
}

const blankPayment = {
  method: 'CASH',
  displayName: '',
  provider: '',
  accountNumber: '',
  defaultMethod: false,
}

const tabConfig = [
  { key: 'profile', label: 'Thông tin' },
  { key: 'addresses', label: 'Địa chỉ' },
  { key: 'payments', label: 'Thanh toán' },
  { key: 'security', label: 'Bảo mật' },
]

const UserSettingsPanel = ({ userId, session, refreshSession, role }) => {
  const [activeTab, setActiveTab] = useState('profile')
  const [profile, setProfile] = useState(null)
  const [profileForm, setProfileForm] = useState({ fullName: '', phone: '', avatarUrl: '' })
  const [profileLoading, setProfileLoading] = useState(false)
  const [profileSaving, setProfileSaving] = useState(false)
  const [profileError, setProfileError] = useState('')

  const [addresses, setAddresses] = useState([])
  const [addressesLoading, setAddressesLoading] = useState(false)
  const [addressError, setAddressError] = useState('')
  const [addressForm, setAddressForm] = useState(blankAddress)
  const [editingAddressId, setEditingAddressId] = useState(null)

  const [payments, setPayments] = useState([])
  const [paymentsLoading, setPaymentsLoading] = useState(false)
  const [paymentError, setPaymentError] = useState('')
  const [paymentForm, setPaymentForm] = useState(blankPayment)
  const [editingPaymentId, setEditingPaymentId] = useState(null)

  const [passwordForm, setPasswordForm] = useState({ currentPassword: '', newPassword: '' })
  const [passwordSaving, setPasswordSaving] = useState(false)
  const [passwordMessage, setPasswordMessage] = useState('')
  const [passwordError, setPasswordError] = useState('')

  const [accountUpdating, setAccountUpdating] = useState(false)
  const [accountMessage, setAccountMessage] = useState('')
  const [accountError, setAccountError] = useState('')

  const canChangePassword = useMemo(
    () => role === 'CUSTOMER' || role === 'STAFF',
    [role],
  )
  const canToggleAccount = role === 'CUSTOMER' || role === 'STAFF'

  const visibleTabs = useMemo(() => {
    return tabConfig.filter((tab) => {
      if (tab.key === 'security' && !canChangePassword && !canToggleAccount) {
        return false
      }
      return true
    })
  }, [canChangePassword, canToggleAccount])

  useEffect(() => {
    if (!visibleTabs.find((tab) => tab.key === activeTab) && visibleTabs.length > 0) {
      setActiveTab(visibleTabs[0].key)
    }
  }, [visibleTabs, activeTab])

  const loadProfile = useCallback(async () => {
    if (!userId || !session) return
    try {
      setProfileLoading(true)
      const data = await fetchUserProfile(userId, session, refreshSession)
      setProfile(data)
      setProfileForm({
        fullName: data.fullName || '',
        phone: data.phone || '',
        avatarUrl: data.avatarUrl || '',
      })
      setProfileError('')
    } catch (error) {
      setProfileError(error.message || 'Không thể tải thông tin cá nhân')
    } finally {
      setProfileLoading(false)
    }
  }, [userId, session, refreshSession])

  const loadAddresses = useCallback(async () => {
    if (!userId || !session) return
    try {
      setAddressesLoading(true)
      const data = await fetchAddresses(userId, session, refreshSession)
      setAddresses(data)
      setAddressError('')
    } catch (error) {
      setAddressError(error.message || 'Không thể tải danh sách địa chỉ')
    } finally {
      setAddressesLoading(false)
    }
  }, [userId, session, refreshSession])

  const loadPayments = useCallback(async () => {
    if (!userId || !session) return
    try {
      setPaymentsLoading(true)
      const data = await fetchPaymentMethods(userId, session, refreshSession)
      setPayments(data)
      setPaymentError('')
    } catch (error) {
      setPaymentError(error.message || 'Không thể tải phương thức thanh toán')
    } finally {
      setPaymentsLoading(false)
    }
  }, [userId, session, refreshSession])

  useEffect(() => {
    loadProfile()
    loadAddresses()
    loadPayments()
  }, [loadProfile, loadAddresses, loadPayments])

  const handleProfileSubmit = async (event) => {
    event.preventDefault()
    if (!userId) return
    setProfileSaving(true)
    try {
      const updated = await updateUserProfile(userId, profileForm, session, refreshSession)
      setProfile(updated)
      setProfileError('')
    } catch (error) {
      setProfileError(error.message || 'Không thể cập nhật thông tin')
    } finally {
      setProfileSaving(false)
    }
  }

  const handleAddressSubmit = async (event) => {
    event.preventDefault()
    if (!userId) return
    setAddressError('')
    try {
      if (editingAddressId) {
        await updateAddressApi(userId, editingAddressId, addressForm, session, refreshSession)
      } else {
        await createAddress(userId, addressForm, session, refreshSession)
      }
      setAddressForm(blankAddress)
      setEditingAddressId(null)
      loadAddresses()
    } catch (error) {
      setAddressError(error.message || 'Không thể lưu địa chỉ')
    }
  }

  const handleDeleteAddress = async (addressId) => {
    if (!userId) return
    const confirmed = window.confirm('Bạn có chắc muốn xóa địa chỉ này?')
    if (!confirmed) return
    try {
      await deleteAddressApi(userId, addressId, session, refreshSession)
      if (editingAddressId === addressId) {
        setEditingAddressId(null)
        setAddressForm(blankAddress)
      }
      loadAddresses()
    } catch (error) {
      setAddressError(error.message || 'Không thể xóa địa chỉ')
    }
  }

  const handlePaymentSubmit = async (event) => {
    event.preventDefault()
    if (!userId) return
    setPaymentError('')
    try {
      if (editingPaymentId) {
        await updatePaymentMethodApi(userId, editingPaymentId, paymentForm, session, refreshSession)
      } else {
        await createPaymentMethod(userId, paymentForm, session, refreshSession)
      }
      setPaymentForm(blankPayment)
      setEditingPaymentId(null)
      loadPayments()
    } catch (error) {
      setPaymentError(error.message || 'Không thể lưu phương thức thanh toán')
    }
  }

  const handleDeletePayment = async (methodId) => {
    if (!userId) return
    const confirmed = window.confirm('Bạn có chắc muốn xóa phương thức thanh toán này?')
    if (!confirmed) return
    try {
      await deletePaymentMethodApi(userId, methodId, session, refreshSession)
      if (editingPaymentId === methodId) {
        setEditingPaymentId(null)
        setPaymentForm(blankPayment)
      }
      loadPayments()
    } catch (error) {
      setPaymentError(error.message || 'Không thể xóa phương thức thanh toán')
    }
  }

  const handlePasswordSubmit = async (event) => {
    event.preventDefault()
    if (!userId) return
    setPasswordSaving(true)
    setPasswordMessage('')
    setPasswordError('')
    try {
      await changePassword(userId, passwordForm, session, refreshSession)
      setPasswordMessage('Đổi mật khẩu thành công')
      setPasswordForm({ currentPassword: '', newPassword: '' })
    } catch (error) {
      setPasswordError(error.message || 'Không thể đổi mật khẩu')
    } finally {
      setPasswordSaving(false)
    }
  }

  const handleToggleAccount = async (active) => {
    if (!userId) return
    setAccountUpdating(true)
    setAccountMessage('')
    setAccountError('')
    try {
      const updated = await updateAccountStatus(userId, { active }, session, refreshSession)
      setProfile(updated)
      setAccountMessage(active ? 'Tài khoản đã mở lại.' : 'Tài khoản đã bị khóa.')
    } catch (error) {
      setAccountError(error.message || 'Không thể cập nhật trạng thái tài khoản')
    } finally {
      setAccountUpdating(false)
    }
  }

  if (!userId) {
    return (
      <section className="panel">
        <h2>Cài đặt tài khoản</h2>
        <p className="text-muted">Vui lòng đăng nhập để truy cập cài đặt.</p>
      </section>
    )
  }

  const renderProfileTab = () => (
    <div className="panel soft-card">
      {profileLoading ? (
        <p className="text-muted">Đang tải thông tin cá nhân...</p>
      ) : (
        <form className="modal-form" onSubmit={handleProfileSubmit}>
          <label className="modal-field">
            Họ tên
            <input
              name="fullName"
              value={profileForm.fullName}
              onChange={(event) =>
                setProfileForm((prev) => ({ ...prev, fullName: event.target.value }))
              }
              required
            />
          </label>
          <label className="modal-field">
            Số điện thoại
            <input
              name="phone"
              value={profileForm.phone}
              onChange={(event) =>
                setProfileForm((prev) => ({ ...prev, phone: event.target.value }))
              }
            />
          </label>
          <label className="modal-field">
            Ảnh đại diện (URL)
            <input
              name="avatarUrl"
              value={profileForm.avatarUrl}
              onChange={(event) =>
                setProfileForm((prev) => ({ ...prev, avatarUrl: event.target.value }))
              }
              placeholder="https://..."
            />
          </label>
          {profileError && <p className="form-error">{profileError}</p>}
          <button type="submit" className="btn-primary" disabled={profileSaving}>
            {profileSaving ? 'Đang lưu...' : 'Lưu thay đổi'}
          </button>
        </form>
      )}
      {profile && (
        <ul className="profile-grid" style={{ marginTop: '1.25rem' }}>
          <li>
            Trạng thái tài khoản <strong>{profile.status}</strong>
          </li>
          <li>
            Vai trò <strong>{profile.role}</strong>
          </li>
          <li>
            Email <strong>{profile.email}</strong>
          </li>
        </ul>
      )}
    </div>
  )

  const renderAddressesTab = () => (
    <div className="panel soft-card">
      {addressesLoading ? (
        <p className="text-muted">Đang tải địa chỉ...</p>
      ) : (
        <>
          <ul className="list" style={{ maxHeight: '220px', overflowY: 'auto' }}>
            {addresses.map((addr) => (
              <li key={addr.id}>
                <div>
                  <strong>{addr.label || 'Không có nhãn'}</strong>
                  <p>{[addr.street, addr.city, addr.province].filter(Boolean).join(', ')}</p>
                  {addr.defaultAddress && <span className="pill info">Địa chỉ mặc định</span>}
                </div>
                <div className="list-actions">
                  <button
                    type="button"
                    className="btn-text"
                    onClick={() => {
                      setEditingAddressId(addr.id)
                      setAddressForm({
                        label: addr.label || '',
                        street: addr.street || '',
                        city: addr.city || '',
                        province: addr.province || '',
                        defaultAddress: addr.defaultAddress,
                      })
                    }}
                  >
                    Sửa
                  </button>
                  <button
                    type="button"
                    className="btn-text danger"
                    onClick={() => handleDeleteAddress(addr.id)}
                  >
                    Xóa
                  </button>
                </div>
              </li>
            ))}
            {addresses.length === 0 && <li className="text-muted">Chưa có địa chỉ nào</li>}
          </ul>
        </>
      )}
      <form className="modal-form" onSubmit={handleAddressSubmit} style={{ marginTop: '1rem' }}>
        <h4>{editingAddressId ? 'Cập nhật địa chỉ' : 'Thêm địa chỉ mới'}</h4>
        <label className="modal-field">
          Nhãn
          <input
            name="label"
            value={addressForm.label}
            onChange={(event) =>
              setAddressForm((prev) => ({ ...prev, label: event.target.value }))
            }
            placeholder="Nhà riêng, Văn phòng..."
          />
        </label>
        <label className="modal-field">
          Địa chỉ chi tiết *
          <input
            name="street"
            value={addressForm.street}
            onChange={(event) =>
              setAddressForm((prev) => ({ ...prev, street: event.target.value }))
            }
            required
          />
        </label>
        <div className="modal-grid">
          <label className="modal-field">
            Thành phố
            <input
              name="city"
              value={addressForm.city}
              onChange={(event) =>
                setAddressForm((prev) => ({ ...prev, city: event.target.value }))
              }
            />
          </label>
          <label className="modal-field">
            Tỉnh
            <input
              name="province"
              value={addressForm.province}
              onChange={(event) =>
                setAddressForm((prev) => ({ ...prev, province: event.target.value }))
              }
            />
          </label>
        </div>
        <label className="checkbox">
          <input
            type="checkbox"
            checked={addressForm.defaultAddress}
            onChange={(event) =>
              setAddressForm((prev) => ({ ...prev, defaultAddress: event.target.checked }))
            }
          />
          <span>Sử dụng làm địa chỉ mặc định</span>
        </label>
        {addressError && <p className="form-error">{addressError}</p>}
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button type="submit" className="btn-primary">
            {editingAddressId ? 'Cập nhật' : 'Thêm địa chỉ'}
          </button>
          {editingAddressId && (
            <button
              type="button"
              className="btn-text"
              onClick={() => {
                setEditingAddressId(null)
                setAddressForm(blankAddress)
              }}
            >
              Hủy
            </button>
          )}
        </div>
      </form>
    </div>
  )

  const renderPaymentsTab = () => (
    <div className="panel soft-card">
      {paymentsLoading ? (
        <p className="text-muted">Đang tải phương thức thanh toán...</p>
      ) : (
        <ul className="list" style={{ maxHeight: '220px', overflowY: 'auto' }}>
          {payments.map((method) => (
            <li key={method.id}>
              <div>
                <strong>{method.displayName || method.method}</strong>
                <p>
                  {method.provider || 'Không rõ nhà cung cấp'} · {method.maskedNumber || '---'}
                </p>
                {method.defaultMethod && <span className="pill info">Mặc định</span>}
              </div>
              <div className="list-actions">
                <button
                  type="button"
                  className="btn-text"
                  onClick={() => {
                    setEditingPaymentId(method.id)
                    setPaymentForm({
                      method: method.method,
                      displayName: method.displayName || '',
                      provider: method.provider || '',
                      accountNumber: '',
                      defaultMethod: method.defaultMethod,
                    })
                  }}
                >
                  Sửa
                </button>
                <button
                  type="button"
                  className="btn-text danger"
                  onClick={() => handleDeletePayment(method.id)}
                >
                  Xóa
                </button>
              </div>
            </li>
          ))}
          {payments.length === 0 && <li className="text-muted">Chưa có phương thức nào</li>}
        </ul>
      )}
      <form className="modal-form" onSubmit={handlePaymentSubmit} style={{ marginTop: '1rem' }}>
        <h4>{editingPaymentId ? 'Cập nhật phương thức' : 'Thêm phương thức mới'}</h4>
        <label className="modal-field">
          Hình thức
          <select
            name="method"
            value={paymentForm.method}
            onChange={(event) =>
              setPaymentForm((prev) => ({ ...prev, method: event.target.value }))
            }
          >
            {paymentOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </label>
        <label className="modal-field">
          Tên hiển thị
          <input
            name="displayName"
            value={paymentForm.displayName}
            onChange={(event) =>
              setPaymentForm((prev) => ({ ...prev, displayName: event.target.value }))
            }
            placeholder="Ví dụ: Thẻ Techcombank"
          />
        </label>
        <label className="modal-field">
          Nhà cung cấp / Ngân hàng
          <input
            name="provider"
            value={paymentForm.provider}
            onChange={(event) =>
              setPaymentForm((prev) => ({ ...prev, provider: event.target.value }))
            }
          />
        </label>
        <label className="modal-field">
          Số tài khoản / Ví (chỉ nhập 1 lần)
          <input
            name="accountNumber"
            value={paymentForm.accountNumber}
            onChange={(event) =>
              setPaymentForm((prev) => ({ ...prev, accountNumber: event.target.value }))
            }
            placeholder="Ví dụ: 9704 xxxx xxxx"
          />
        </label>
        <label className="checkbox">
          <input
            type="checkbox"
            checked={paymentForm.defaultMethod}
            onChange={(event) =>
              setPaymentForm((prev) => ({ ...prev, defaultMethod: event.target.checked }))
            }
          />
          <span>Đặt làm phương thức mặc định</span>
        </label>
        {paymentError && <p className="form-error">{paymentError}</p>}
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button type="submit" className="btn-primary">
            {editingPaymentId ? 'Cập nhật' : 'Thêm'}
          </button>
          {editingPaymentId && (
            <button
              type="button"
              className="btn-text"
              onClick={() => {
                setEditingPaymentId(null)
                setPaymentForm(blankPayment)
              }}
            >
              Hủy
            </button>
          )}
        </div>
      </form>
    </div>
  )

  const renderSecurityTab = () => (
    <div className="panel soft-card">
      {canChangePassword && (
        <form className="modal-form" onSubmit={handlePasswordSubmit}>
          <h4>Đổi mật khẩu</h4>
          <label className="modal-field">
            Mật khẩu hiện tại
            <input
              type="password"
              name="currentPassword"
              value={passwordForm.currentPassword}
              onChange={(event) =>
                setPasswordForm((prev) => ({
                  ...prev,
                  currentPassword: event.target.value,
                }))
              }
              required
            />
          </label>
          <label className="modal-field">
            Mật khẩu mới
            <input
              type="password"
              name="newPassword"
              value={passwordForm.newPassword}
              onChange={(event) =>
                setPasswordForm((prev) => ({ ...prev, newPassword: event.target.value }))
              }
              required
              minLength={6}
            />
          </label>
          {passwordError && <p className="form-error">{passwordError}</p>}
          {passwordMessage && <p className="form-success">{passwordMessage}</p>}
          <button type="submit" className="btn-primary" disabled={passwordSaving}>
            {passwordSaving ? 'Đang cập nhật...' : 'Đổi mật khẩu'}
          </button>
        </form>
      )}

      {canToggleAccount && (
        <div style={{ marginTop: canChangePassword ? '2rem' : 0 }}>
          <h4>Trạng thái tài khoản</h4>
          <p className="text-muted">
            {profile?.status === 'INACTIVE'
              ? 'Tài khoản đang bị khóa. Bạn có thể mở lại bất kỳ lúc nào.'
              : 'Khóa tài khoản sẽ ngừng các đặt dịch vụ và thông báo.'}
          </p>
          {accountError && <p className="form-error">{accountError}</p>}
          {accountMessage && <p className="form-success">{accountMessage}</p>}
          <div style={{ display: 'flex', gap: '0.75rem', marginTop: '0.75rem' }}>
            <button
              type="button"
              className={profile?.status === 'ACTIVE' ? 'btn-outline' : 'btn-primary'}
              onClick={() => handleToggleAccount(profile?.status !== 'ACTIVE')}
              disabled={accountUpdating}
            >
              {accountUpdating
                ? 'Đang xử lý...'
                : profile?.status === 'ACTIVE'
                  ? 'Khóa tài khoản'
                  : 'Mở khóa tài khoản'}
            </button>
          </div>
        </div>
      )}
    </div>
  )

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'addresses':
        return renderAddressesTab()
      case 'payments':
        return renderPaymentsTab()
      case 'security':
        return renderSecurityTab()
      case 'profile':
      default:
        return renderProfileTab()
    }
  }

  return (
    <section className="eco-settings panel" style={{ background: '#f0fdf4', border: '1px solid #bbf7d0' }}>
      <div
        className="settings-tab-bar"
        style={{
          display: 'flex',
          gap: '0.75rem',
          flexWrap: 'wrap',
          background: '#ecfccb',
          padding: '0.75rem',
          borderRadius: '0.75rem',
        }}
      >
        {visibleTabs.map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setActiveTab(tab.key)}
            className={`btn-chip ${activeTab === tab.key ? 'active' : ''}`}
            style={{
              border: 'none',
              borderRadius: '999px',
              padding: '0.35rem 1rem',
              background: activeTab === tab.key ? '#22c55e' : '#ffffff',
              color: activeTab === tab.key ? '#fff' : '#15803d',
              fontWeight: 600,
              cursor: 'pointer',
              boxShadow: activeTab === tab.key ? '0 4px 12px rgba(34,197,94,0.4)' : 'none',
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div style={{ marginTop: '1.25rem' }}>{renderActiveTab()}</div>
    </section>
  )
}

export default UserSettingsPanel
