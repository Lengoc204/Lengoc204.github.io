import { useState } from 'react'

const LogoutButton = ({ onLogout }) => {
  const [loading, setLoading] = useState(false)

  const handleClick = async () => {
    if (!onLogout || loading) return
    setLoading(true)
    try {
      await onLogout()
    } finally {
      setLoading(false)
    }
  }

  return (
    <button type="button" className="logout-button" onClick={handleClick} disabled={!onLogout || loading}>
      {loading ? 'Đang đăng xuất...' : 'Đăng xuất'}
    </button>
  )
}

export default LogoutButton
