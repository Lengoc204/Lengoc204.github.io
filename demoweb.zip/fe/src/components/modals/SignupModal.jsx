import { useEffect, useState } from 'react'
import BaseModal from './BaseModal'
import { signup } from '../../services/authService'

const initialState = {
  fullName: '',
  email: '',
  phone: '',
  password: '',
  confirm: '',
  role: 'CUSTOMER',
  addressLabel: '',
  street: '',
  ward: '',
  district: '',
  city: '',
  province: '',
  latitude: '',
  longitude: '',
  defaultAddress: true,
}

const SignupModal = ({ isOpen, onClose, onOpenLogin }) => {
  const [form, setForm] = useState(initialState)
  const [submitted, setSubmitted] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!isOpen) {
      setSubmitted(false)
      setForm(initialState)
      setIsSubmitting(false)
      setError('')
    }
  }, [isOpen])

  const buildPayload = () => {
    const base = {
      email: form.email.trim(),
      fullName: form.fullName.trim(),
      password: form.password,
      phone: form.phone.trim() || null,
      role: form.role,
    }

    if (!form.street.trim()) {
      return base
    }

    return {
      ...base,
      defaultAddress: {
        label: form.addressLabel.trim() || 'Địa chỉ chính',
        street: form.street.trim(),
        ward: form.ward.trim() || null,
        district: form.district.trim() || null,
        city: form.city.trim() || null,
        province: form.province.trim() || null,
        latitude: form.latitude ? Number(form.latitude) : null,
        longitude: form.longitude ? Number(form.longitude) : null,
        defaultAddress: form.defaultAddress,
      },
    }
  }

  const submit = async (event) => {
    event.preventDefault()
    setError('')
    if (form.password !== form.confirm) {
      alert('Mật khẩu không khớp. Vui lòng kiểm tra lại.')
      return
    }
    setIsSubmitting(true)
    try {
      const payload = buildPayload()
      await signup(payload)
      setSubmitted(true)
    } catch (err) {
      setError(err.message)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <BaseModal isOpen={isOpen} onClose={onClose} title="Create your account">
      {submitted ? (
        <div className="success-state">
          <h4>Đăng ký thành công</h4>
          <p>Chúng tôi đã gửi email xác thực tới bạn. Đăng nhập để đặt lịch ngay!</p>
          <button
            type="button"
            className="btn-primary"
            onClick={() => {
              onClose()
              onOpenLogin()
            }}
          >
            Đi tới đăng nhập
          </button>
        </div>
      ) : (
        <form className="modal-form" onSubmit={submit}>
          <div className="modal-grid">
            <label className="modal-field">
              Họ và tên
              <input
                name="fullName"
                value={form.fullName}
                onChange={(event) => setForm((prev) => ({ ...prev, fullName: event.target.value }))}
                required
              />
            </label>
            <label className="modal-field">
              Email
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={(event) => setForm((prev) => ({ ...prev, email: event.target.value }))}
                required
              />
            </label>
          </div>
          <div className="modal-grid">
            <label className="modal-field">
              Số điện thoại
              <input
                name="phone"
                value={form.phone}
                onChange={(event) => setForm((prev) => ({ ...prev, phone: event.target.value }))}
                placeholder="0123 456 789"
              />
            </label>
            <label className="modal-field">
              Vai trò
              <select
                name="role"
                value={form.role}
                onChange={(event) => setForm((prev) => ({ ...prev, role: event.target.value }))}
                required
              >
                <option value="CUSTOMER">Customer</option>
                <option value="STAFF">Staff</option>
              </select>
            </label>
          </div>
          <div className="modal-grid">
            <label className="modal-field">
              Password
              <input
                type="password"
                name="password"
                value={form.password}
                onChange={(event) => setForm((prev) => ({ ...prev, password: event.target.value }))}
                required
              />
            </label>
            <label className="modal-field">
              Confirm password
              <input
                type="password"
                name="confirm"
                value={form.confirm}
                onChange={(event) => setForm((prev) => ({ ...prev, confirm: event.target.value }))}
                required
              />
            </label>
          </div>
          <fieldset className="modal-fieldset">
            <legend>Địa chỉ (tuỳ chọn)</legend>
            <div className="modal-grid">
              <label className="modal-field">
                Nhãn địa chỉ
                <input
                  name="addressLabel"
                  value={form.addressLabel}
                  onChange={(event) => setForm((prev) => ({ ...prev, addressLabel: event.target.value }))}
                  placeholder="Nhà riêng / Văn phòng"
                />
              </label>
              <label className="modal-field">
                Địa chỉ
                <input
                  name="street"
                  value={form.street}
                  onChange={(event) => setForm((prev) => ({ ...prev, street: event.target.value }))}
                  placeholder="Số nhà, tên đường"
                />
              </label>
            </div>
            <div className="modal-grid">
              <label className="modal-field">
                Phường/Xã
                <input
                  name="ward"
                  value={form.ward}
                  onChange={(event) => setForm((prev) => ({ ...prev, ward: event.target.value }))}
                />
              </label>
              <label className="modal-field">
                Quận/Huyện
                <input
                  name="district"
                  value={form.district}
                  onChange={(event) => setForm((prev) => ({ ...prev, district: event.target.value }))}
                />
              </label>
              <label className="modal-field">
                Thành phố
                <input
                  name="city"
                  value={form.city}
                  onChange={(event) => setForm((prev) => ({ ...prev, city: event.target.value }))}
                />
              </label>
              <label className="modal-field">
                Tỉnh
                <input
                  name="province"
                  value={form.province}
                  onChange={(event) => setForm((prev) => ({ ...prev, province: event.target.value }))}
                />
              </label>
            </div>
            <div className="modal-grid">
              <label className="modal-field">
                Latitude
                <input
                  name="latitude"
                  value={form.latitude}
                  onChange={(event) => setForm((prev) => ({ ...prev, latitude: event.target.value }))}
                  placeholder="10.12345"
                />
              </label>
              <label className="modal-field">
                Longitude
                <input
                  name="longitude"
                  value={form.longitude}
                  onChange={(event) => setForm((prev) => ({ ...prev, longitude: event.target.value }))}
                  placeholder="106.12345"
                />
              </label>
            </div>
            <label className="remember-me">
              <input
                type="checkbox"
                checked={form.defaultAddress}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, defaultAddress: event.target.checked }))
                }
              />
              Đặt làm địa chỉ mặc định
            </label>
          </fieldset>
          {error && <p className="form-error">{error}</p>}
          <button type="submit" className="btn-primary full">
            {isSubmitting ? 'Đang tạo...' : 'Create account'}
          </button>
          <p className="modal-footer-text">
            Đã có tài khoản?
            <button
              type="button"
              className="link"
              onClick={() => {
                onClose()
                onOpenLogin()
              }}
            >
              Đăng nhập
            </button>
          </p>
        </form>
      )}
    </BaseModal>
  )
}

export default SignupModal
