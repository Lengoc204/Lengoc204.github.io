import { useEffect, useState } from 'react'
import BaseModal from './BaseModal'
import { login } from '../../services/authService'

const LoginModal = ({ isOpen, onClose, onOpenSignup, onAuthenticated }) => {
  const [form, setForm] = useState({ email: '', password: '', remember: false })
  const [error, setError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    if (!isOpen) {
      setForm({ email: '', password: '', remember: false })
      setError('')
      setIsSubmitting(false)
    }
  }, [isOpen])

  const submit = async (event) => {
    event.preventDefault()
    setError('')
    setIsSubmitting(true)
    try {
      const session = await login({
        email: form.email.trim(),
        password: form.password,
      })

      onAuthenticated?.(session, form.remember)
      onClose()
    } catch (err) {
      setError(err.message || 'Đăng nhập thất bại.')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <BaseModal isOpen={isOpen} onClose={onClose} title="">
      <div className="login-brand">
        <span className="brand-dot" />
        <h3>Cleanify Admin</h3>
      </div>
      <form className="modal-form" onSubmit={submit}>
        <label className="modal-field">
          Email
          <input
            type="email"
            name="email"
            value={form.email}
            onChange={(event) => setForm((prev) => ({ ...prev, email: event.target.value }))}
            placeholder="name@example.com"
            required
          />
        </label>
        <label className="modal-field">
          Password
          <input
            type="password"
            name="password"
            value={form.password}
            onChange={(event) => setForm((prev) => ({ ...prev, password: event.target.value }))}
            placeholder="••••••••"
            required
          />
        </label>
        <div className="form-extra">
          <label className="remember-me">
            <input
              type="checkbox"
              checked={form.remember}
              onChange={(event) => setForm((prev) => ({ ...prev, remember: event.target.checked }))}
            />
            Remember me
          </label>
          <button type="button" className="link subtle">
            Forgot password?
          </button>
        </div>
        {error && <p className="form-error">{error}</p>}
        <button type="submit" className="btn-primary full">
          {isSubmitting ? 'Đang đăng nhập...' : 'Login'}
        </button>
        <p className="modal-note">Secure login. Your credentials are encrypted and protected.</p>
        <p className="modal-footer-text">
          Chưa có tài khoản?
          <button
            type="button"
            className="link"
            onClick={() => {
              onClose()
              onOpenSignup()
            }}
          >
            Đăng ký ngay
          </button>
        </p>
      </form>
    </BaseModal>
  )
}

export default LoginModal
