import { useEffect, useState } from 'react'
import BaseModal from './BaseModal'

const addressOptions = [
  { value: 'HOME', label: 'Nhà riêng' },
  { value: 'OFFICE', label: 'Văn phòng' },
]

const initialState = {
  serviceId: '',
  addressType: addressOptions[0].value,
  street: '',
  useDefaultAddress: false,
  scheduledStart: '',
  scheduledEnd: '',
  totalPrice: '',
  notes: '',
}

const BookingModal = ({
  isOpen,
  onClose,
  services = [],
  defaultAddress,
  serviceLoading,
  serviceError,
  onSubmit,
}) => {
  const [form, setForm] = useState(initialState)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!isOpen) {
      setForm(initialState)
      setSubmitting(false)
      setError('')
    } else {
      setForm((prev) => ({
        ...initialState,
        serviceId: prev.serviceId,
        addressType: prev.addressType,
      }))
    }
  }, [isOpen])

  const toIsoString = (value) => {
    if (!value) return null
    const date = new Date(value)
    return date.toISOString()
  }

  const submit = async (event) => {
    event.preventDefault()
    if (!onSubmit) return
    setSubmitting(true)
    setError('')
    try {
      const typeLabel = addressOptions.find((opt) => opt.value === form.addressType)?.label
      await onSubmit({
        serviceId: form.serviceId,
        label: typeLabel || 'Địa chỉ khách hàng',
        street: form.street,
        scheduledStart: toIsoString(form.scheduledStart),
        scheduledEnd: toIsoString(form.scheduledEnd),
        totalPrice: Number(form.totalPrice),
        notes: form.notes || null,
      })
      onClose()
    } catch (err) {
      setError(err.message)
    } finally {
      setSubmitting(false)
    }
  }

  const handleToggleDefault = (checked) => {
    setForm((prev) => ({
      ...prev,
      useDefaultAddress: checked,
      street: checked && defaultAddress?.street ? defaultAddress.street : '',
    }))
  }

  return (
    <BaseModal isOpen={isOpen} onClose={onClose} title="Đặt dịch vụ mới">
      <form className="modal-form" onSubmit={submit}>
        <label className="modal-field">
          Chọn dịch vụ
          <select
            value={form.serviceId}
            onChange={(event) => setForm((prev) => ({ ...prev, serviceId: event.target.value }))}
            required
            disabled={serviceLoading || !services.length}
          >
            <option value="">
              {serviceLoading ? 'Đang tải...' : ' -- Chọn dịch vụ --'}
            </option>
            {services.map((service) => (
              <option key={service.id} value={service.id}>
                {service.name}
              </option>
            ))}
          </select>
        </label>
        {serviceError && <p className="form-error">{serviceError}</p>}

        <label className="modal-field">
          Nhãn địa chỉ
          <select
            value={form.addressType}
            onChange={(event) => setForm((prev) => ({ ...prev, addressType: event.target.value }))}
          >
            {addressOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </label>

        <label className="modal-field">
          Địa chỉ chi tiết
          <input
            name="street"
            value={form.street}
            onChange={(event) => setForm((prev) => ({ ...prev, street: event.target.value }))}
            placeholder="Số nhà, tên đường"
            required
            disabled={form.useDefaultAddress && Boolean(defaultAddress?.street)}
          />
        </label>

        <label className="remember-me">
          <input
            type="checkbox"
            checked={form.useDefaultAddress}
            onChange={(event) => handleToggleDefault(event.target.checked)}
            disabled={!defaultAddress?.street}
          />
          Sử dụng địa chỉ mặc định (địa chỉ khi đăng ký)
        </label>

        <div className="modal-grid">
          <label className="modal-field">
            Thời gian bắt đầu
            <input
              type="datetime-local"
              value={form.scheduledStart}
              onChange={(event) => setForm((prev) => ({ ...prev, scheduledStart: event.target.value }))}
              required
            />
          </label>
          <label className="modal-field">
            Thời gian kết thúc
            <input
              type="datetime-local"
              value={form.scheduledEnd}
              onChange={(event) => setForm((prev) => ({ ...prev, scheduledEnd: event.target.value }))}
            />
          </label>
        </div>

        <label className="modal-field">
          Chi phí dự kiến (VND)
          <input
            type="number"
            min="0"
            step="1000"
            value={form.totalPrice}
            onChange={(event) => setForm((prev) => ({ ...prev, totalPrice: event.target.value }))}
            required
          />
        </label>

        <label className="modal-field">
          Ghi chú
          <textarea
            rows={3}
            value={form.notes}
            onChange={(event) => setForm((prev) => ({ ...prev, notes: event.target.value }))}
          />
        </label>

        {error && <p className="form-error">{error}</p>}

        <button type="submit" className="btn-primary full" disabled={submitting}>
          {submitting ? 'Đang đặt...' : 'Xác nhận đặt'}
        </button>
      </form>
    </BaseModal>
  )
}

export default BookingModal
