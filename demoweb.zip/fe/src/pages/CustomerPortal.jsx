import { useCallback, useEffect, useMemo, useState } from 'react'
import { customerData } from '../data/mockData'
import LogoutButton from '../components/common/LogoutButton'
import BookingModal from '../components/modals/BookingModal'
import UserSettingsPanel from '../components/dashboard/UserSettingsPanel'
import {
  createBooking,
  fetchActiveServices,
  fetchCustomerBookings,
  fetchCustomerPayments,
} from '../services/bookingService'
import { mockPayment } from '../services/paymentService'

const statusTone = {
  'Scheduled': 'pill info',
  'on the move': 'pill info',
  'Completed': 'pill success',
  'Pending': 'pill warning',
  Paid: 'pill success',
  Pending: 'pill warning',
}

const navLinks = [
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'orders', label: 'Orders' },
  { key: 'payments', label: 'Payments' },
  { key: 'profile', label: 'Profile' },
  { key: 'settings', label: 'Settings' },
]

const CustomerPortal = ({ user, onLogout, session, refreshSession }) => {
  const [orders, setOrders] = useState([])
  const [loadingOrders, setLoadingOrders] = useState(false)
  const [ordersError, setOrdersError] = useState('')
  const nextBooking = customerData.orders[0]
  const displayName = user?.fullName || customerData.user.name
  const customerId = user?.id
  const [activeTab, setActiveTab] = useState('dashboard')
  const [isBookingModalOpen, setBookingModalOpen] = useState(false)
  const [services, setServices] = useState([])
  const [serviceLoading, setServiceLoading] = useState(false)
  const [serviceError, setServiceError] = useState('')
  const [paymentItems, setPaymentItems] = useState([])
  const [paymentsLoading, setPaymentsLoading] = useState(false)
  const [paymentsError, setPaymentsError] = useState('')
  const [paymentNotice, setPaymentNotice] = useState({ type: '', message: '' })
  const [payingId, setPayingId] = useState(null)
  const userRole = user?.role || 'CUSTOMER'
  const defaultAddress =
    user?.addresses?.find((addr) => addr.defaultAddress) ||
    user?.addresses?.[0] ||
    (customerData.user.addresses?.[0] ?? null)

  useEffect(() => {
    if (!customerId || !session) {
      setOrders([])
      return
    }
    setLoadingOrders(true)
    setOrdersError('')
    fetchCustomerBookings(customerId, session, refreshSession)
      .then((data) => setOrders(data))
      .catch((error) => setOrdersError(error.message))
      .finally(() => setLoadingOrders(false))
  }, [customerId, session, refreshSession])

  useEffect(() => {
    if (!session) {
      setServices([])
      return
    }
    setServiceLoading(true)
    setServiceError('')
    fetchActiveServices(session, refreshSession)
      .then((data) => {
        if (Array.isArray(data)) {
          setServices(data)
        } else {
          setServices([])
        }
      })
      .catch((error) => {
        setServiceError(error.message)
        setServices([])
      })
      .finally(() => setServiceLoading(false))
  }, [session, refreshSession])

  const bookingList = useMemo(() => {
    if (orders.length === 0) {
      return customerData.orders.map((order) => ({
        id: order.id,
        serviceName: order.service,
        scheduledDate: order.date,
        status: order.status,
        totalPrice: order.amount,
      }))
    }
    return orders.map((order) => ({
      id: order.code,
      serviceName: order.serviceName,
      scheduledDate: order.scheduledDate,
      status: order.status,
      totalPrice: order.totalPrice,
    }))
  }, [orders])

  const totalSpent = useMemo(() => {
    if (orders.length === 0) {
      return customerData.orders.reduce((sum, order) => sum + Number(order.amount || 0), 0)
    }
    return orders.reduce((sum, order) => sum + Number(order.totalPrice || 0), 0)
  }, [orders])

  const primaryAddress = useMemo(() => {
    const preferred =
      user?.addresses?.find((address) => address.defaultAddress) ||
      user?.addresses?.[0]
    if (preferred) {
      return [preferred.street, preferred.city, preferred.province].filter(Boolean).join(', ')
    }
    return customerData.user.address
  }, [user])

  const loadPayments = useCallback(async (options = {}) => {
    if (!options.preserveNotice) {
      setPaymentNotice({ type: '', message: '' })
    }
    if (!customerId || !session) {
      setPaymentItems([])
      return
    }
    try {
      setPaymentsLoading(true)
      const data = await fetchCustomerPayments(customerId, session, refreshSession)
      setPaymentItems(Array.isArray(data) ? data : [])
      setPaymentsError('')
    } catch (error) {
      setPaymentsError(error.message || 'Không thể tải danh sách thanh toán')
    } finally {
      setPaymentsLoading(false)
    }
  }, [customerId, session, refreshSession])

  useEffect(() => {
    if (customerId && session) {
      loadPayments({ preserveNotice: true })
    }
  }, [customerId, session, loadPayments])

  useEffect(() => {
    if (activeTab === 'payments') {
      loadPayments()
    }
  }, [activeTab, loadPayments])

  const handleMockPayment = async (paymentItem) => {
    if (!customerId || !session || !paymentItem) return
    const canPay =
      paymentItem.bookingStatus === 'COMPLETED' && paymentItem.paymentStatus !== 'PAID'
    if (!canPay) {
      setPaymentNotice({
        type: 'warning',
        message: 'Form must be completed before payment.',
      })
      return
    }
    setPayingId(paymentItem.bookingId)
    setPaymentsError('')
    try {
      await mockPayment(
        paymentItem.bookingId,
        { customerId },
        session,
        refreshSession,
      )
      await loadPayments()
      setPaymentNotice({
        type: 'success',
        message: 'Payment successful! Thank you for using the service.',
      })
    } catch (error) {
      setPaymentsError(error.message || 'Payment failed, please try again.')
    } finally {
      setPayingId(null)
    }
  }

  const renderMainContent = () => {
    if (activeTab === 'settings') {
      return (
        <UserSettingsPanel
          userId={customerId}
          session={session}
          refreshSession={refreshSession}
          role={userRole}
        />
      )
    }

    if (activeTab === 'payments') {
      return (
        <section className="panel">
          <div className="panel-header">
            <div>
              <h2>Thanh toán dịch vụ</h2>
              <p className="text-muted">Track status and make payment upon completion</p>
            </div>
            <button
              type="button"
              className="btn-outline"
              onClick={loadPayments}
              disabled={paymentsLoading}
            >
              {paymentsLoading ? 'Đang tải...' : 'Làm mới'}
            </button>
          </div>
          {paymentNotice.message && (
            <p className={paymentNotice.type === 'success' ? 'form-success' : 'form-error'}>
              {paymentNotice.message}
            </p>
          )}
          {paymentsError && <p className="form-error">{paymentsError}</p>}
          {paymentsLoading ? (
            <p className="text-muted">Loading payment data...</p>
          ) : paymentItems.length === 0 ? (
            <p className="text-muted">You have no pending orders.</p>
          ) : (
            <div className="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>Code</th>
                    <th>Service</th>
                    <th>Job status</th>
                    <th>Payment status</th>
                    <th>Price</th>
                    <th>Operation</th>
                  </tr>
                </thead>
                <tbody>
                  {paymentItems.map((item) => {
                    const canPay =
                      item.bookingStatus === 'COMPLETED' &&
                      item.paymentStatus !== 'PAID'
                    return (
                      <tr key={item.bookingId}>
                        <td>{item.code}</td>
                        <td>{item.serviceName}</td>
                        <td>
                          <span className="pill info">{item.bookingStatus}</span>
                        </td>
                        <td>
                          <span className={`pill ${item.paymentStatus === 'PAID' ? 'success' : 'ghost'}`}>
                            {item.paymentStatus || 'Chưa tạo'}
                          </span>
                        </td>
                        <td>
                          {Number(item.totalPrice || 0).toLocaleString('vi-VN', {
                            style: 'currency',
                            currency: 'VND',
                          })}
                        </td>
                        <td>
                          <button
                            type="button"
                            className="btn-outline"
                            disabled={payingId === item.bookingId}
                            onClick={() => handleMockPayment(item)}
                          >
                            {payingId === item.bookingId ? 'Paying...' : 'Payment'}
                          </button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )
    }

    if (activeTab !== 'dashboard') {
      const currentTab = navLinks.find((link) => link.key === activeTab)
      return (
        <section className="panel">
          <div className="panel-header">
            <h2>{currentTab?.label || 'Function'}</h2>
          </div>
          <p className="text-muted">This feature will be updated soon.</p>
        </section>
      )
    }

    return (
      <>
        <section className="stat-grid">
          <article className="panel stat-card">
            <p className="eyebrow">Next booking</p>
            <h3>{nextBooking.service}</h3>
            <span>{nextBooking.date}</span>
          </article>
          <article className="panel stat-card">
            <p className="eyebrow">Address</p>
            <h3>{primaryAddress}</h3>
            <span>{user?.phone || customerData.user.phone}</span>
          </article>
          <article className="panel stat-card">
            <p className="eyebrow">Total spent</p>
            <h3>{totalSpent.toLocaleString('vi-VN')}₫</h3>
            <span>
              {orders.length > 0
                ? `${orders.length} bookings`
                : `${customerData.orders.length} bookings`}
            </span>
          </article>
        </section>

        <section className="panel-grid two">
          <article className="panel wide">
            <div className="panel-header">
              <h2>Đơn hàng</h2>
            </div>
            <div className="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>Code</th>
                    <th>Service</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Price</th>
                  </tr>
                </thead>
                <tbody>
                  {loadingOrders ? (
                    <tr>
                      <td colSpan={5} style={{ textAlign: 'center', padding: '1rem' }}>
                        Loading order...
                      </td>
                    </tr>
                  ) : ordersError ? (
                    <tr>
                      <td
                        colSpan={5}
                        className="form-error"
                        style={{ textAlign: 'center', padding: '1rem' }}
                      >
                        {ordersError}
                      </td>
                    </tr>
                  ) : (
                    bookingList.map((order) => (
                      <tr key={order.id}>
                        <td>{order.id}</td>
                        <td>{order.serviceName}</td>
                        <td>{order.scheduledDate}</td>
                        <td>
                          <span className={statusTone[order.status] || 'pill'}>{order.status}</span>
                        </td>
                        <td>
                          {Number(order.totalPrice || 0).toLocaleString('vi-VN', {
                            style: 'currency',
                            currency: 'VND',
                          })}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </article>
          <article className="panel">
            <div className="panel-header">
              <div>
                <h2>Thanh toán</h2>
                <p className="text-muted">Overview of recent orders</p>
              </div>
              <button
                type="button"
                className="btn-text"
                onClick={() => loadPayments({ preserveNotice: true })}
                disabled={paymentsLoading}
              >
                {paymentsLoading ? 'Loading...' : 'Refresh'}
              </button>
            </div>
            {paymentsLoading ? (
              <p className="text-muted">Loading data...</p>
            ) : paymentItems.length === 0 ? (
              <p className="text-muted">No payments yet.</p>
            ) : (
              <div className="table-wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>Code</th>
                      <th>Order</th>
                      <th>Date</th>
                      <th>Status</th>
                      <th>Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paymentItems.slice(0, 3).map((item) => (
                      <tr key={item.bookingId}>
                        <td>{item.code}</td>
                        <td>{item.bookingId.toString().slice(0, 8)}</td>
                        <td>
                          {item.scheduledDate
                            ? new Date(item.scheduledDate).toLocaleDateString('vi-VN', {
                                dateStyle: 'medium',
                              })
                            : '--'}
                        </td>
                        <td>
                          <span
                            className={`pill ${
                              item.paymentStatus === 'PAID' ? 'success' : 'warning'
                            }`}
                          >
                            {item.paymentStatus === 'PAID' ? 'Paid' : 'Pending'}
                          </span>
                        </td>
                        <td>
                          {Number(item.totalPrice || 0).toLocaleString('vi-VN', {
                            style: 'currency',
                            currency: 'VND',
                          })}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </article>
        </section>

        <section className="panel-grid two">
          <article className="panel">
            <div className="panel-header">
              <h2>Personal information</h2>
            </div>
            <ul className="profile-grid">
              <li>
                Email <strong>{user?.email || customerData.user.email}</strong>
              </li>
              <li>
                Phone number <strong>{user?.phone || customerData.user.phone}</strong>
              </li>
              <li>
                Address <strong>{primaryAddress}</strong>
              </li>
            </ul>
          </article>
          <article className="panel">
            <div className="panel-header">
              <h2>Service Notes</h2>
            </div>
            <p className="text-muted">
              You can update special requests to the cleaning staff before arriving. 
              For example: prioritize the kitchen area, bring glass cleaning tools, etc.
            </p>
            <button type="button" className="btn-outline" style={{ marginTop: '1rem' }}>
              Update request
            </button>
          </article>
        </section>
      </>
    )
  }

  return (
    <div className="dashboard-layout">
      <aside className="dashboard-sidebar">
        <div className="sidebar-brand">
          <span className="brand-dot" />
          <div>
            <p className="brand-title">Service Portal</p>
            <small>Customer</small>
          </div>
        </div>
        <nav className="sidebar-nav">
          {navLinks.map((item) => (
            <button
              key={item.key}
              type="button"
              className={`sidebar-link ${activeTab === item.key ? 'active' : ''}`}
              onClick={() => setActiveTab(item.key)}
            >
              {item.label}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <LogoutButton onLogout={onLogout} />
        </div>
      </aside>

      <main className="dashboard-main">
        <header className="dash-header">
          <div>
            <p>Hello,</p>
            <h1>{displayName}</h1>
          </div>
          <button
            type="button"
            className="btn-primary"
            onClick={() => setBookingModalOpen(true)}
            disabled={serviceLoading}
          >
            {serviceLoading ? 'Loading service...' : 'Book new service'}
          </button>
        </header>
        {renderMainContent()}
      </main>

      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setBookingModalOpen(false)}
        services={services}
        defaultAddress={defaultAddress}
        serviceLoading={serviceLoading}
        serviceError={serviceError}
        onSubmit={async (payload) => {
          if (!customerId || !session?.accessToken) {
            throw new Error('You need to log in to book services.')
          }
          await createBooking(
            {
              ...payload,
              customerId,
            },
            session,
            refreshSession,
          )
          await fetchCustomerBookings(customerId, session, refreshSession).then((data) => setOrders(data))
        }}
      />
    </div>
  )
}

export default CustomerPortal
