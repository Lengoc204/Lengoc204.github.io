import { useEffect, useMemo, useState } from 'react'
import { adminData } from '../data/mockData'
import LogoutButton from '../components/common/LogoutButton'
import AdminSettingsPanel from '../components/dashboard/AdminSettingsPanel'
import {
  fetchMonthlyRevenue,
  fetchAdminSummary,
  fetchAdminPipeline,
  fetchFeaturedBooking,
} from '../services/reportService'

const navLinks = [
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'orders', label: 'Orders' },
  { key: 'customers', label: 'Customers' },
  { key: 'team', label: 'Team' },
  { key: 'payments', label: 'Payments' },
  { key: 'feedback', label: 'Feedback' },
  { key: 'settings', label: 'Settings' },
]

const kpis = [
  { label: 'On-time completion rate', value: '95%', target: 'Target 90%' },
  { label: 'Re-signing order', value: '62%', target: '+8% MoM' },
  { label: 'Customer satisfaction score', value: '4.8/5', target: '182 new reviews' },
]

const statusTone = {
  'Complete': 'pill success',
  'Cancelled': 'pill danger',
  'In progress': 'pill info',
  'Pending': 'pill warning',
}

const AdminDashboard = ({ onLogout, session, refreshSession }) => {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [revenueSeries, setRevenueSeries] = useState([])
  const [revenueLoading, setRevenueLoading] = useState(false)
  const [revenueError, setRevenueError] = useState('')
  const [summary, setSummary] = useState(null)
  const [summaryError, setSummaryError] = useState('')
  const [pipeline, setPipeline] = useState([])
  const [pipelineError, setPipelineError] = useState('')
  const [featuredBooking, setFeaturedBooking] = useState(null)

  useEffect(() => {
    if (!session) return
    let ignore = false
    const loadRevenue = async () => {
      try {
        setRevenueLoading(true)
        const data = await fetchMonthlyRevenue(6, session, refreshSession)
        if (!ignore) {
          setRevenueSeries(Array.isArray(data) ? data : [])
          setRevenueError('')
        }
      } catch (error) {
        if (!ignore) {
          setRevenueError(error.message || 'Không thể tải dữ liệu doanh thu')
          setRevenueSeries([])
        }
      } finally {
        if (!ignore) {
          setRevenueLoading(false)
        }
      }
    }
    loadRevenue()
    const loadSummary = async () => {
      try {
        const data = await fetchAdminSummary(session, refreshSession)
        if (!ignore) {
          setSummary(data)
          setSummaryError('')
        }
      } catch (error) {
        if (!ignore) {
          setSummary(null)
          setSummaryError(error.message || 'Unable to load overview data')
        }
      }
    }
    const loadPipelineData = async () => {
      try {
        const [pipelineData, featured] = await Promise.all([
          fetchAdminPipeline(5, session, refreshSession),
          fetchFeaturedBooking(session, refreshSession),
        ])
        if (!ignore) {
          setPipeline(Array.isArray(pipelineData) ? pipelineData : [])
          setPipelineError('')
          setFeaturedBooking(featured || null)
        }
      } catch (error) {
        if (!ignore) {
          setPipeline([])
          setPipelineError(error.message || 'Unable to load pipeline today')
          setFeaturedBooking(null)
        }
      }
    }

    loadSummary()
    loadPipelineData()
    return () => {
      ignore = true
    }
  }, [session, refreshSession])

  const currentMonthRevenue = useMemo(() => {
    if (!revenueSeries.length) return null
    return revenueSeries[revenueSeries.length - 1]
  }, [revenueSeries])

  const chartData = useMemo(() => {
    if (!revenueSeries.length) {
      return { path: '', labels: [], values: [], coords: [], width: 360, height: 160, axisMax: 0 }
    }
    const values = revenueSeries.map((item) => Number(item.totalAmount || 0))
    const paddedValues = values.length >= 12 ? values.slice(-12) : values
    const labels =
      revenueSeries.length >= 12
        ? revenueSeries.slice(-12).map((item) => item.label)
        : revenueSeries.map((item) => item.label)

    const max = Math.max(...paddedValues, 1)
    const min = Math.min(...paddedValues, 0)
    const range = max - min || 1
    const width = 360
    const height = 160
    const coords = paddedValues.map((value, index) => {
      const x =
        paddedValues.length === 1
          ? width / 2
          : (index / (paddedValues.length - 1)) * width
      const y = height - ((value - min) / range) * height
      return { x, y, value, label: labels[index] }
    })
    const path = coords
      .map((point, idx) => `${idx === 0 ? 'M' : 'L'}${point.x.toFixed(1)},${point.y.toFixed(1)}`)
      .join(' ')
    return { path, labels, values: paddedValues, coords, width, height, axisMax: max }
  }, [revenueSeries])

  const formatCurrency = (value) =>
    Number(value || 0).toLocaleString('vi-VN', { style: 'currency', currency: 'VND' })

  const renderMainContent = () => {
    if (activeTab === 'settings') {
      return <AdminSettingsPanel session={session} refreshSession={refreshSession} />
    }

    if (activeTab !== 'dashboard') {
      const currentTab = navLinks.find((nav) => nav.key === activeTab)
      return (
        <section className="panel">
          <div className="panel-header">
            <h2>{currentTab?.label || 'Function'}</h2>
          </div>
          <p className="text-muted">Content for this section is under development.</p>
        </section>
      )
    }

    return (
      <>
        <section className="stat-grid">
          <article className="panel stat-card" style={{ background: '#ecfccb' }}>
            <div className="stat-icon" style={{ background: '#15803d', color: '#f0fdf4' }}>
              ₫
            </div>
            <div>
              <p className="eyebrow">This month's revenue</p>
              <h3>
                {revenueLoading
                  ? 'Đang tải...'
                  : currentMonthRevenue
                      ? formatCurrency(currentMonthRevenue.totalAmount)
                      : '--'}
              </h3>
              <span>
                {currentMonthRevenue ? currentMonthRevenue.label : 'No data yet'}
                {revenueError && <span className="form-error" style={{ display: 'block' }}>{revenueError}</span>}
              </span>
            </div>
          </article>
          {summaryError && (
            <article className="panel stat-card">
              <div className="stat-icon">!</div>
              <div>
                <p className="form-error">{summaryError}</p>
                <span>Unable to load overview data.</span>
              </div>
            </article>
          )}
          <article className="panel stat-card">
            <div className="stat-icon">B</div>
            <div>
              <p className="eyebrow">Tổng đơn</p>
              <h3>
                {summary ? summary.totalBookings : summaryError ? '--' : 'Đang tải...'}
              </h3>
              <span>
                Đang chờ: {summary ? summary.pendingBookings : '--'}
              </span>
            </div>
          </article>
          <article className="panel stat-card">
            <div className="stat-icon">S</div>
            <div>
              <p className="eyebrow">Operations staff</p>
              <h3>{summary ? summary.activeStaff : summaryError ? '--' : 'Loading...'}</h3>
              <span>
                Đang nghỉ: {summary ? Math.max(summary.totalStaff - summary.activeStaff, 0) : '--'}
              </span>
            </div>
          </article>
          <article className="panel stat-card">
            <div className="stat-icon">C</div>
            <div>
              <p className="eyebrow">Active customers</p>
              <h3>{summary ? summary.activeCustomers : summaryError ? '--' : 'Loading...'}</h3>
              <span>
                Đang nghỉ:{' '}
                {summary ? Math.max(summary.totalCustomers - summary.activeCustomers, 0) : '--'}
              </span>
            </div>
          </article>
          {adminData.stats.map((stat) => (
            <article key={stat.title} className="panel stat-card">
              <div className="stat-icon">{stat.title.charAt(0)}</div>
              <div>
                <p className="eyebrow">{stat.title}</p>
                <h3>{stat.value}</h3>
                <span>{stat.trend}</span>
              </div>
            </article>
          ))}
        </section>

        <section className="panel-grid two">
          <article className="panel">
            <div className="panel-header">
              <div>
                <p className="eyebrow">General</p>
                <h2>Doanh thu tháng</h2>
              </div>
              <button type="button" className="btn-text">
                Chi tiết
              </button>
            </div>
          <div className="chart-placeholder" style={{ minHeight: '200px', position: 'relative' }}>
            {revenueLoading ? (
              <p className="text-muted">Loading revenue data...</p>
            ) : revenueError ? (
              <p className="form-error">{revenueError}</p>
            ) : !revenueSeries.length ? (
              <p className="text-muted">No transactions have been recorded yet.</p>
            ) : (
              <>
                <svg width="100%" height="200" viewBox="0 0 360 200" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="revenueGradient" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="#22c55e" stopOpacity="0.4" />
                      <stop offset="100%" stopColor="#bbf7d0" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <path
                    d={`${chartData.path} L${chartData.width},${chartData.height} L0,${chartData.height} Z`}
                    fill="url(#revenueGradient)"
                    stroke="none"
                  />
                  <path
                    d={chartData.path}
                    fill="none"
                    stroke="#16a34a"
                    strokeWidth="3"
                    strokeLinejoin="round"
                    strokeLinecap="round"
                  />
                  {chartData.coords.map((point, index) => (
                    <g key={point.label}>
                      <circle
                        cx={point.x}
                        cy={point.y}
                        r={4}
                        fill="#22c55e"
                        stroke="#fff"
                        strokeWidth="2"
                      />
                      <g>
                        <rect
                          x={point.x - 50}
                          y={point.y - 45}
                          width="100"
                          height="38"
                          rx="6"
                          ry="6"
                          fill="#0f172a"
                          opacity="0"
                          className="chart-tooltip"
                        />
                        <text
                          x={point.x}
                          y={point.y - 30}
                          textAnchor="middle"
                          fill="#fff"
                          fontSize="12"
                          className="chart-tooltip-text"
                        >
                          {point.label}
                        </text>
                        <text
                          x={point.x}
                          y={point.y - 15}
                          textAnchor="middle"
                          fill="#bae6fd"
                          fontSize="12"
                          className="chart-tooltip-text"
                        >
                          {formatCurrency(point.value)}
                        </text>
                      </g>
                    </g>
                  ))}
                </svg>
                <div className="chart-legend hover-list">
                  {chartData.coords.map((point) => (
                    <div key={point.label}>
                      <p className="eyebrow">{point.label}</p>
                      <strong>{formatCurrency(point.value)}</strong>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </article>

          <article className="panel">
            <div className="panel-header">
              <h2>Mục tiêu & KPI</h2>
            </div>
            <ul className="metric-list">
              {kpis.map((item) => (
                <li key={item.label}>
                  <div>
                    <p>{item.label}</p>
                    <span>{item.target}</span>
                  </div>
                  <strong>{item.value}</strong>
                </li>
              ))}
            </ul>
          </article>
        </section>

        <section className="panel-grid two">
          <article className="panel wide">
            <div className="panel-header">
              <div>
                <p className="eyebrow">Most recent order</p>
                <h2>Pipeline today</h2>
              </div>
              <button type="button" className="btn-text">
                Xem tất cả
              </button>
            </div>
            {pipelineError ? (
              <p className="form-error">{pipelineError}</p>
            ) : pipeline.length === 0 ? (
              <p className="text-muted">No orders have been recorded today.</p>
            ) : (
              <div className="table-wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>Code</th>
                      <th>Customer</th>
                      <th>Service</th>
                      <th>Status</th>
                      <th>Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pipeline.map((order) => (
                      <tr key={order.bookingId}>
                        <td>{order.code}</td>
                        <td>{order.customerName}</td>
                        <td>{order.serviceName}</td>
                        <td>
                          <span className={statusTone[order.status] || 'pill'}>
                            {order.status}
                          </span>
                        </td>
                        <td>
                          {Number(order.totalPrice || 0).toLocaleString('vi-VN', {
                            style: 'currency',
                            currency: 'VND',
                          })}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </article>

          <article className="panel">
            <div className="panel-header">
              <h2>Featured bookings</h2>
            </div>
            {featuredBooking ? (
              <div className="booking-card">
                <p>Code: {featuredBooking.code}</p>
                <p>Service: {featuredBooking.serviceName}</p>
                <p>Customer: {featuredBooking.customerName}</p>
                <p>
                  Price:{' '}
                  {Number(featuredBooking.totalPrice || 0).toLocaleString('vi-VN', {
                    style: 'currency',
                    currency: 'VND',
                  })}
                </p>
                <button type="button" className="btn-primary full">
                  Order management
                </button>
              </div>
            ) : (
              <p className="text-muted">No featured orders yet.</p>
            )}
          </article>
        </section>

        <section className="panel-grid two">
          <article className="panel">
            <div className="panel-header">
              <h2>Outstanding staff</h2>
            </div>
            <ul className="list">
              {adminData.staff.map((member) => (
                <li key={member.name}>
                  <div>
                    <h4>{member.name}</h4>
                    <p>{member.role}</p>
                  </div>
                  <span className="chip">
                    {member.jobs} jobs · ⭐ {member.rating}
                  </span>
                </li>
              ))}
            </ul>
          </article>

          <article className="panel">
            <div className="panel-header">
              <h2>Operational Timeline</h2>
            </div>
            <ul className="timeline">
              {adminData.recentOrders.map((order) => (
                <li key={order.id}>
                  <p>{order.service}</p>
                  <span>{order.customer}</span>
                </li>
              ))}
            </ul>
          </article>
        </section>

        <section className="panel-grid two">
          <article className="panel">
            <div className="panel-header">
              <h2>Customer feedback</h2>
            </div>
            <ul className="feedback-list">
              {adminData.feedback.map((item) => (
                <li key={item.id}>
                  <div>
                    <h4>{item.customer}</h4>
                    <p>{item.comment}</p>
                  </div>
                  <span>⭐ {item.rating}</span>
                </li>
              ))}
            </ul>
          </article>

          <article className="panel">
            <div className="panel-header">
              <h2>Internal notes</h2>
            </div>
            <p className="text-muted">
              Monitor the progress of marketing campaigns and balance shifts for the staff team this week.
            </p>
            <button type="button" className="btn-outline full" style={{ marginTop: '1rem' }}>
              Add notes
            </button>
          </article>
        </section>
      </>
    )
  }

  return (
    <div className="dashboard-layout">
    <aside className="dashboard-sidebar">
      <div className="sidebar-brand">
        <span className="brand-dot" />
        <div>
          <p className="brand-title">Cleanify</p>
          <small>Admin Suite</small>
        </div>
      </div>

      <nav className="sidebar-nav">
        {navLinks.map((item) => (
          <button
            key={item.key}
            type="button"
            className={`sidebar-link ${activeTab === item.key ? 'active' : ''}`}
            onClick={() => setActiveTab(item.key)}
          >
            {item.label}
          </button>
        ))}
      </nav>

      <div className="sidebar-card">
        <h4>Need more insights?</h4>
        <p>Upgrade to unlock realtime analytics and automation.</p>
        <button type="button" className="btn-primary full">
          Upgrade
        </button>
      </div>

      <div className="sidebar-footer">
        <LogoutButton onLogout={onLogout} />
      </div>
    </aside>

    <main className="dashboard-main">
      <header className="dash-header">
        <div>
          <p>Welcome back</p>
          <h1>{adminData.name}</h1>
        </div>
        <div className="dash-header-actions">
          <button type="button" className="btn-outline">
            Export report
          </button>
          <div className="avatar">
            <span>{adminData.name.charAt(0)}</span>
          </div>
        </div>
      </header>
      {renderMainContent()}
    </main>
  </div>
  )
}

export default AdminDashboard
