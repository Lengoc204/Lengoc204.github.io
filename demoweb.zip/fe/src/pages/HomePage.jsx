import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { HERO_CARDS, SERVICES } from '../data/mockData'

const highlights = ['🌿 Eco friendly products', '🧹 Background checked staff', '⏱ Flexible scheduling']

const faqList = [
  { question: 'Can I change my cleaning schedule?', answer: 'You can change up to 12 hours before your appointment time without charge.' },
  { question: 'Do you bring any tools?', answer: 'Cleanify team carries full range of environmentally friendly tools and chemicals.' },
]

const priceTiers = [
  { title: 'Standard', desc: 'Small apartment, basic bathroom.', price: '350.000đ', hours: '2h - 3h' },
  { title: 'Premium', desc: '2-3 bedroom house, deep cleaning.', price: '650.000đ', hours: '4h - 5h', featured: true },
  { title: 'Move-out', desc: 'House/room handover, full cleaning.', price: '950.000đ', hours: '5h - 6h' },
]

const supportInfo = [
  { icon: '✉️', label: 'support@freshnest.com' },
  { icon: '📞', label: '034 567 8999' },
  { icon: '📍', label: '1 - Trịnh Văn Bô - Hà Nội' },
]

const HomePage = ({ onSignup, onBookNow }) => {
  const location = useLocation()

  useEffect(() => {
    const sectionId = location.state?.sectionId
    if (sectionId) {
      const target = document.getElementById(sectionId)
      target?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }, [location])

  return (
    <main className="page-shell">
      <section className="hero-surface" id="hero">
        <div className="media-stack">
          <div className="media-grid">
            {HERO_CARDS.map((card) => (
              <article key={card.id} className={`media-card ${card.id}`}>
                <img src={card.image} alt="cleaning showcase" />
                {card.stats && (
                  <div className="media-stat">
                    <strong>{card.stats}</strong>
                    <span>{card.caption}</span>
                  </div>
                )}
              </article>
            ))}
          </div>
          <div className="media-note">
            <span>Best ratings</span>
            <div className="emoji-row">
              {HERO_CARDS[0].emojis?.map((emoji) => (
                <span key={emoji}>{emoji}</span>
              ))}
            </div>
          </div>
        </div>
        <div className="hero-copy">
          <div className="hero-chip">Home • Services • Happiness</div>
          <h1>Home Cleaning</h1>
          <p>
            At Home Cleaning, we believe a clean home is a happy home. Our team delivers reliable, professional, and
            affordable services — from regular housekeeping to deep cleaning. With trained staff, eco-friendly products, and
            a focus on quality, we bring comfort, freshness, and peace of mind.
          </p>
          <div className="hero-cta">
            <button type="button" className="btn-primary" onClick={onBookNow}>
              Explore More
            </button>
            <button type="button" className="btn-outline" onClick={onSignup}>
              Sign Up
            </button>
          </div>
          <ul className="hero-highlights">
            {highlights.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </section>

      <section className="services" id="services">
        <header>
          <p className="eyebrow">Our Services</p>
          <h2>Outstanding services we provide</h2>
        </header>
        <div className="service-grid">
          {SERVICES.map((service) => (
            <article key={service.title} className="service-card">
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <span>{service.duration}</span>
            </article>
          ))}
        </div>
      </section>

      <section className="pricing" id="pricing">
        <header>
          <p className="eyebrow">Pricing</p>
          <h2>Choose a package that fits your budget</h2>
        </header>
        <div className="pricing-grid">
          {priceTiers.map((tier) => (
            <article key={tier.title} className={`price-card ${tier.featured ? 'featured' : ''}`}>
              <div>
                <h3>{tier.title}</h3>
                <p>{tier.desc}</p>
              </div>
              <strong>{tier.price}</strong>
              <span>{tier.hours}</span>
            </article>
          ))}
        </div>
      </section>

      <section className="about-band" id="about">
        <div>
          <p className="eyebrow">About us</p>
          <h3>5+ years helping over 30,000 families keep their homes clean</h3>
          <p>
            Our staff undergo regular training, background checks and follow safety procedures. 
            We use environmentally friendly products and carry all necessary equipment.
          </p>
        </div>
      </section>

      <section className="faq-band" id="faq">
        <header>
          <p className="eyebrow">FAQ</p>
          <h2>Frequently Asked Questions</h2>
        </header>
        <div className="faq-list">
          {faqList.map((item) => (
            <article key={item.question}>
              <h4>{item.question}</h4>
              <p>{item.answer}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="contact-support" id="contact">
        <header>
          <p className="eyebrow">Contact & Support</p>
          <h2>Contact now for consultation</h2>
        </header>
        <div className="contact-grid">
          <div className="contact-card">
            <form onSubmit={(event) => event.preventDefault()}>
              <label>
                Your name
                <input type="text" placeholder="Full name" required />
              </label>
              <label>
                Email
                <input type="email" placeholder="you@example.com" required />
              </label>
              <label>
                Message
                <textarea placeholder="Tell us how we can help" rows="4" required />
              </label>
              <button type="submit" className="btn-send">
                ✈️ Send
              </button>
            </form>
          </div>
          <div className="support-card">
            <div className="support-items">
              {supportInfo.map((info) => (
                <div key={info.label}>
                  <span>{info.icon}</span>
                  <p>{info.label}</p>
                </div>
              ))}
            </div>
            <button type="button" className="chatbot-btn">
              💬 Open AI Chatbot
            </button>
            <div className="socials">
              <a href="https://facebook.com" target="_blank" rel="noreferrer">
                Facebook
              </a>
              <a href="https://www.instagram.com" target="_blank" rel="noreferrer">
                Instagram
              </a>
              <a href="https://zalo.me" target="_blank" rel="noreferrer">
                Zalo
              </a>
            </div>
            <div className="map-box">
              <img src="/images/Map.png" alt="Map of the office" />
            </div>
          </div>
        </div>
      </section>

      <section className="review-bar">
        <p>⭐️⭐️⭐️⭐️⭐️ Loved the service? Leave a review</p>
        <div className="footer-buttons">
          <button className="btn-feedback">💬 Leave Feedback</button>
          <button className="btn-primary" onClick={onBookNow}>
            📅 Book Now
          </button>
        </div>
      </section>
    </main>
  )
}

export default HomePage
