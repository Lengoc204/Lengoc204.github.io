import { useCallback, useEffect, useMemo, useState } from 'react'
import { staffData } from '../data/mockData'
import LogoutButton from '../components/common/LogoutButton'
import {
  fetchPendingBookings,
  claimBooking,
  fetchStaffSchedule,
  updateBookingStatus,
  fetchStaffEarnings,
} from '../services/bookingService'
import { fetchCleanerProfile, updateCleanerProfile } from '../services/staffService'
import UserSettingsPanel from '../components/dashboard/UserSettingsPanel'

const navLinks = [
  { key: 'dashboard', label: 'Trang chủ' },
  { key: 'schedule', label: 'Lịch làm' },
  { key: 'notifications', label: 'Thông báo' },
  { key: 'profile', label: 'Hồ sơ' },
  { key: 'settings', label: 'Cài đặt' },
]

const assignmentStatusMap = {
  ASSIGNED: 'Đang nhận',
  COMPLETED: 'Hoàn thành',
  DECLINED: 'Từ chối',
  CANCELLED: 'Đã hủy',
}

const statusActionMap = {
  CONFIRMED: [
    { status: 'IN_PROGRESS', label: 'Bắt đầu' },
    { status: 'CANCELLED', label: 'Hủy nhận' },
  ],
  IN_PROGRESS: [
    { status: 'COMPLETED', label: 'Hoàn thành' },
    { status: 'CANCELLED', label: 'Hủy nhận' },
  ],
}

const StaffWorkspace = ({ onLogout, user, session, refreshSession }) => {
  const data = staffData || {}
  const currentJob = data.currentJob || {}
  const defaultProfile = data.profile || {}
  const userId = user?.id
  const feedback = defaultProfile.feedback || []
  const [pendingBookings, setPendingBookings] = useState([])
  const [pendingLoading, setPendingLoading] = useState(false)
  const [pendingError, setPendingError] = useState('')
  const [selectedBooking, setSelectedBooking] = useState(null)
  const [claimError, setClaimError] = useState('')
  const [claimRequiresForce, setClaimRequiresForce] = useState(false)
  const [claimLoading, setClaimLoading] = useState(false)
  const [profileData, setProfileData] = useState(null)
  const [profileForm, setProfileForm] = useState({
    bio: '',
    yearsExperience: '',
    hourlyRate: '',
    serviceArea: '',
  })
  const [profileLoading, setProfileLoading] = useState(false)
  const [profileError, setProfileError] = useState('')
  const [profileSaving, setProfileSaving] = useState(false)
  const [scheduleBookings, setScheduleBookings] = useState([])
  const [scheduleLoading, setScheduleLoading] = useState(false)
  const [scheduleError, setScheduleError] = useState('')
  const [statusUpdating, setStatusUpdating] = useState(false)
  const [statusError, setStatusError] = useState('')
  const [earnings, setEarnings] = useState([])
  const [earningsLoading, setEarningsLoading] = useState(false)
  const [earningsError, setEarningsError] = useState('')
  const [selectedContext, setSelectedContext] = useState(null)
  const [activeTab, setActiveTab] = useState('dashboard')

  const clearSelection = () => {
    setSelectedBooking(null)
    setSelectedContext(null)
    setStatusError('')
    setClaimError('')
    setClaimRequiresForce(false)
  }

  const loadPending = useCallback(async () => {
    if (!session) {
      setPendingBookings([])
      return
    }
    try {
      setPendingLoading(true)
      const list = await fetchPendingBookings(session, refreshSession)
      setPendingBookings(list)
      setPendingError('')
    } catch (err) {
      setPendingError(err.message || 'Không thể tải danh sách công việc')
    } finally {
      setPendingLoading(false)
    }
  }, [session, refreshSession])

  const loadSchedule = useCallback(async () => {
    if (!session || !userId) {
      setScheduleBookings([])
      return
    }
    try {
      setScheduleLoading(true)
      const assignments = await fetchStaffSchedule(userId, session, refreshSession)
      setScheduleBookings(Array.isArray(assignments) ? assignments : [])
      setScheduleError('')
    } catch (err) {
      setScheduleError(err.message || 'Không thể tải lịch làm')
    } finally {
      setScheduleLoading(false)
    }
  }, [session, refreshSession, userId])

  const loadEarnings = useCallback(async () => {
    if (!session || !userId) {
      setEarnings([])
      return
    }
    try {
      setEarningsLoading(true)
      const data = await fetchStaffEarnings(userId, session, refreshSession)
      setEarnings(Array.isArray(data) ? data : [])
      setEarningsError('')
    } catch (err) {
      setEarningsError(err.message || 'Không thể tải thông báo')
    } finally {
      setEarningsLoading(false)
    }
  }, [session, refreshSession, userId])

  useEffect(() => {
    let intervalId
    loadPending()
    if (session) {
      intervalId = setInterval(loadPending, 10000)
    }
    return () => {
      if (intervalId) clearInterval(intervalId)
    }
  }, [loadPending, session])

  useEffect(() => {
    if (!session || !userId) {
      setProfileData(null)
      setProfileForm({ bio: '', yearsExperience: '', hourlyRate: '', serviceArea: '' })
      return
    }
    const loadProfile = async () => {
      try {
        setProfileLoading(true)
        const data = await fetchCleanerProfile(user.id, session, refreshSession)
        setProfileData(data)
        setProfileForm({
          bio: data.bio || '',
          yearsExperience: data.yearsExperience ?? '',
          hourlyRate: data.hourlyRate ?? '',
          serviceArea: data.serviceArea || '',
        })
        setProfileError('')
      } catch (err) {
        setProfileError(err.message || 'Không thể tải hồ sơ')
      } finally {
        setProfileLoading(false)
      }
    }
    loadProfile()
  }, [session, refreshSession, userId])

useEffect(() => {
  loadSchedule()
}, [loadSchedule])

useEffect(() => {
  if (activeTab === 'schedule') {
    loadSchedule()
  }
  if (activeTab === 'notifications') {
    loadEarnings()
  }
}, [activeTab, loadSchedule, loadEarnings])

  const currentAssignment = useMemo(() => {
    const active =
      scheduleBookings.find(
        (booking) =>
          (booking.bookingStatus === 'IN_PROGRESS' || booking.bookingStatus === 'CONFIRMED') &&
          booking.assignmentStatus === 'ASSIGNED',
      ) || scheduleBookings[0]
    return active
      ? {
          id: active.bookingId,
          code: active.code,
          customer: active.customerName,
          service: active.serviceName,
          time: active.formattedTime
            ? active.formattedTime
            : active.scheduledStart
              ? new Date(active.scheduledStart).toLocaleString('vi-VN', {
                  dateStyle: 'medium',
                  timeStyle: 'short',
                })
              : '--',
          address: active.address,
          status: active.bookingStatus,
        }
      : null
  }, [scheduleBookings])

  const formattedBookings = useMemo(
      () =>
        pendingBookings.map((booking) => ({
          ...booking,
          formattedTime: booking.scheduledStart
            ? new Date(booking.scheduledStart).toLocaleString('vi-VN', {
                dateStyle: 'medium',
                timeStyle: 'short',
              })
            : '--',
        })),
      [pendingBookings],
    )

  const formattedSchedule = useMemo(
      () =>
        scheduleBookings.map((booking) => ({
          ...booking,
          formattedTime: booking.scheduledStart
            ? new Date(booking.scheduledStart).toLocaleString('vi-VN', {
                dateStyle: 'medium',
                timeStyle: 'short',
              })
            : '--',
        })),
      [scheduleBookings],
    )

  const handleSelectBooking = (booking, context = 'dashboard') => {
    const normalizedStatus = booking.status || booking.bookingStatus || ''
    setSelectedBooking({ ...booking, status: normalizedStatus })
    setSelectedContext(context)
    setClaimError('')
    setClaimRequiresForce(false)
    setStatusError('')
  }

  const handleClaim = async (forceAssign = false) => {
    if (!selectedBooking || !userId) {
      setClaimError('Không xác định được nhân viên nhận đơn.')
      return
    }
    setClaimLoading(true)
    setClaimError('')
    try {
      await claimBooking(
        selectedBooking.id,
        { staffId: userId, forceAssign },
        session,
        refreshSession,
      )
      clearSelection()
      setClaimRequiresForce(false)
      await loadPending()
      await loadSchedule()
    } catch (err) {
      if (err.status === 409) {
        setClaimRequiresForce(true)
        setClaimError(err.message || 'Ca làm trùng thời gian. Xác nhận nếu muốn nhận tiếp.')
      } else {
        setClaimError(err.message || 'Không thể nhận đơn. Vui lòng thử lại.')
      }
    } finally {
      setClaimLoading(false)
    }
  }

  const handleStatusUpdate = async (booking, nextStatus) => {
    const bookingId = booking?.id || booking?.bookingId
    if (!bookingId || !userId) return
    setStatusError('')
    setStatusUpdating(true)
    try {
      await updateBookingStatus(
        bookingId,
        { staffId: userId, status: nextStatus },
        session,
        refreshSession,
      )
      await loadSchedule()
      clearSelection()
    } catch (err) {
      setStatusError(err.message || 'Không thể cập nhật trạng thái')
    } finally {
      setStatusUpdating(false)
    }
  }

  const handleProfileChange = (event) => {
    const { name, value } = event.target
    setProfileForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleProfileSave = async (event) => {
    event.preventDefault()
    if (!userId) return
    setProfileSaving(true)
    setProfileError('')
    try {
      const payload = {
        userId,
        bio: profileForm.bio,
        yearsExperience:
            profileForm.yearsExperience === '' ? null : Number(profileForm.yearsExperience),
        hourlyRate: profileForm.hourlyRate === '' ? null : Number(profileForm.hourlyRate),
        serviceArea: profileForm.serviceArea,
      }
      const updated = await updateCleanerProfile(payload, session, refreshSession)
      setProfileData(updated)
      setProfileForm({
        bio: updated.bio || '',
        yearsExperience: updated.yearsExperience ?? '',
        hourlyRate: updated.hourlyRate ?? '',
        serviceArea: updated.serviceArea || '',
      })
    } catch (err) {
      setProfileError(err.message || 'Không thể cập nhật hồ sơ')
    } finally {
      setProfileSaving(false)
    }
  }

  const renderMainContent = () => {
    if (activeTab === 'settings') {
      return (
        <UserSettingsPanel
          userId={userId}
          session={session}
          refreshSession={refreshSession}
          role={user?.role}
        />
      )
    }

    if (activeTab === 'profile') {
      return (
        <section className="panel-grid two">
          <article className="panel">
            <div className="panel-header">
              <h2>Hồ sơ của tôi</h2>
            </div>
            {profileLoading ? (
              <p className="text-muted">Đang tải hồ sơ...</p>
            ) : (
              <form className="modal-form" onSubmit={handleProfileSave}>
                <label className="modal-field">
                  Giới thiệu
                  <textarea
                    rows={3}
                    name="bio"
                    value={profileForm.bio}
                    onChange={handleProfileChange}
                    placeholder="Hãy mô tả kinh nghiệm / điểm mạnh của bạn"
                  />
                </label>
                <div className="modal-grid">
                  <label className="modal-field">
                    Số năm kinh nghiệm
                    <input
                      type="number"
                      min="0"
                      name="yearsExperience"
                      value={profileForm.yearsExperience}
                      onChange={handleProfileChange}
                    />
                  </label>
                  <label className="modal-field">
                    Đơn giá mỗi giờ (VND)
                    <input
                      type="number"
                      min="0"
                      step="10000"
                      name="hourlyRate"
                      value={profileForm.hourlyRate}
                      onChange={handleProfileChange}
                    />
                  </label>
                </div>
                <label className="modal-field">
                  Khu vực làm việc
                  <input
                    name="serviceArea"
                    value={profileForm.serviceArea}
                    onChange={handleProfileChange}
                    placeholder="Ví dụ: Quận 1, Quận 3"
                  />
                </label>
                {profileError && <p className="form-error">{profileError}</p>}
                <button type="submit" className="btn-primary" disabled={profileSaving}>
                  {profileSaving ? 'Đang lưu...' : 'Lưu hồ sơ'}
                </button>
              </form>
            )}
            {profileData && (
              <ul className="profile-grid" style={{ marginTop: '1rem' }}>
                <li>
                  Jobs completed <strong>{profileData.completedJobs ?? 0}</strong>
                </li>
                <li>
                  Đánh giá <strong>⭐ {profileData.ratingAverage ?? 0}</strong>
                </li>
                <li>
                  Trạng thái xác minh <strong>{profileData.verificationStatus}</strong>
                </li>
              </ul>
            )}
          </article>
          <article className="panel">
            <div className="panel-header">
              <h2>Phản hồi gần đây</h2>
            </div>
            <ul className="feedback-list">
              {feedback.map((fb) => (
                <li key={fb.client}>
                  <div>
                    <p>{fb.content}</p>
                    <span>
                      {fb.client} · {fb.date}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          </article>
        </section>
      )
    }

    if (activeTab === 'schedule') {
      return (
        <section className="panel">
          <div className="panel-header">
            <div>
              <h2>Lịch làm</h2>
              <p className="text-muted">Các đơn bạn đã nhận</p>
            </div>
            <button
              type="button"
              className="btn-outline"
              onClick={loadSchedule}
              disabled={scheduleLoading}
            >
              {scheduleLoading ? 'Đang tải...' : 'Làm mới'}
            </button>
          </div>
          {scheduleLoading ? (
            <p className="text-muted">Đang tải lịch làm...</p>
          ) : scheduleError ? (
            <p className="form-error">{scheduleError}</p>
          ) : formattedSchedule.length === 0 ? (
            <p className="text-muted">Bạn chưa có đơn nào được giao.</p>
          ) : (
            <div className="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>Mã</th>
                    <th>Dịch vụ</th>
                    <th>Khách hàng</th>
                    <th>Trạng thái</th>
                    <th>Địa chỉ</th>
                    <th>Thời gian</th>
                    <th>Chi phí</th>
                  </tr>
                </thead>
                <tbody>
                  {formattedSchedule.map((booking) => {
                    const bookingStatus = booking.bookingStatus || booking.status || 'UNKNOWN'
                    return (
                    <tr
                      key={booking.assignmentId}
                      onClick={() => handleSelectBooking(booking, 'schedule')}
                        style={{
                          cursor: 'pointer',
                          backgroundColor:
                            selectedBooking?.id === booking.id || selectedBooking?.bookingId === booking.bookingId
                              ? '#f0fdfa'
                              : 'transparent',
                        }}
                      >
                        <td>{booking.code}</td>
                        <td>{booking.serviceName}</td>
                        <td>{booking.customerName}</td>
                        <td>
                          <span className="pill info">{bookingStatus}</span>
                          <span className="text-muted" style={{ marginLeft: '0.35rem' }}>
                            · {assignmentStatusMap[booking.assignmentStatus] || booking.assignmentStatus}
                          </span>
                        </td>
                        <td>{booking.address}</td>
                        <td>{booking.formattedTime}</td>
                        <td>
                          {Number(booking.totalPrice || 0).toLocaleString('vi-VN', {
                            style: 'currency',
                            currency: 'VND',
                          })}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
          {selectedBooking && selectedContext === 'schedule' && activeTab === 'schedule' && (
            <div className="panel" style={{ marginTop: '1.5rem' }}>
              <div className="panel-header">
                <div>
                  <h3>
                    Đơn: {selectedBooking.code}{' '}
                    <span className="pill ghost">
                      {(selectedBooking.status || selectedBooking.bookingStatus || '').toString()}
                    </span>
                  </h3>
                  <p className="text-muted">
                    {selectedBooking.customerName} · {selectedBooking.serviceName}
                  </p>
                </div>
              </div>
              <p>
                <strong>Địa chỉ:</strong> {selectedBooking.address}
              </p>
              <p>
                <strong>Thời gian:</strong> {selectedBooking.formattedTime}
              </p>
              <p>
                <strong>Chi phí:</strong>{' '}
                {Number(selectedBooking.totalPrice || 0).toLocaleString('vi-VN', {
                  style: 'currency',
                  currency: 'VND',
                })}
              </p>
              {statusError && <p className="form-error">{statusError}</p>}
              <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1rem', flexWrap: 'wrap' }}>
                {statusActionMap[selectedBooking.status]
                  ? statusActionMap[selectedBooking.status].map((action) => (
                      <button
                        key={action.status}
                        type="button"
                        className="btn-outline"
                        onClick={() => handleStatusUpdate(selectedBooking, action.status)}
                        disabled={statusUpdating}
                      >
                        {statusUpdating ? 'Đang xử lý...' : action.label}
                      </button>
                    ))
                  : (
                      <span className="text-muted">Không còn hành động khả dụng.</span>
                    )}
                <button type="button" className="btn-text" onClick={clearSelection}>
                  Đóng
                </button>
              </div>
            </div>
          )}
        </section>
      )
    }

    if (activeTab === 'notifications') {
      return (
        <section className="panel">
          <div className="panel-header">
            <div>
              <h2>Thông báo thu nhập</h2>
              <p className="text-muted">Danh sách các đơn đã được thanh toán</p>
            </div>
            <button
              type="button"
              className="btn-outline"
              onClick={loadEarnings}
              disabled={earningsLoading}
            >
              {earningsLoading ? 'Đang tải...' : 'Làm mới'}
            </button>
          </div>
          {earningsError && <p className="form-error">{earningsError}</p>}
          {earningsLoading ? (
            <p className="text-muted">Đang tải dữ liệu...</p>
          ) : earnings.length === 0 ? (
            <p className="text-muted">Chưa có khoản thu nào.</p>
          ) : (
            <ul className="list">
              {earnings.map((earning) => (
                <li key={earning.bookingId}>
                  <div>
                    <strong>
                      {earning.serviceName} · {earning.code}
                    </strong>
                    <p>
                      Nhận{' '}
                      {Number(earning.amount || 0).toLocaleString('vi-VN', {
                        style: 'currency',
                        currency: 'VND',
                      })}
                    </p>
                  </div>
                  <span className="text-muted">
                    {earning.paidAt
                      ? new Date(earning.paidAt).toLocaleString('vi-VN', {
                          dateStyle: 'medium',
                          timeStyle: 'short',
                        })
                      : '--'}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      )
    }

    return (
      <>
        <section className="panel">
          <div className="panel-header">
            <h2>Công việc hiện tại</h2>
          </div>
          {currentAssignment ? (
            <div className="job-meta">
              <div>
                <p>Mã booking</p>
                <strong>{currentAssignment.code}</strong>
              </div>
              <div>
                <p>Khách hàng</p>
                <strong>{currentAssignment.customer}</strong>
              </div>
              <div>
                <p>Thời gian</p>
                <strong>{currentAssignment.time}</strong>
              </div>
              <div>
                <p>Trạng thái</p>
                <span className="pill info">{currentAssignment.status}</span>
              </div>
            </div>
          ) : (
            <p className="text-muted">Bạn chưa có công việc nào.</p>
          )}
          <p className="text-muted">
            Địa chỉ: {currentAssignment?.address || '--'}
          </p>
        </section>

        <section className="panel">
          <div className="panel-header">
            <div>
              <h2>Việc chờ xử lý</h2>
              <p className="text-muted">Tự động cập nhật mỗi 10 giây</p>
            </div>
            <span className="pill ghost">{formattedBookings.length} bookings</span>
          </div>
          {pendingLoading ? (
            <p className="text-muted">Đang tải danh sách công việc...</p>
          ) : pendingError ? (
            <p className="form-error">{pendingError}</p>
          ) : formattedBookings.length === 0 ? (
            <p className="text-muted">Hiện không có công việc nào đang chờ xử lý.</p>
          ) : (
            <div className="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>Mã</th>
                    <th>Khách hàng</th>
                    <th>Dịch vụ</th>
                    <th>Địa chỉ</th>
                    <th>Thời gian</th>
                    <th>Chi phí</th>
                  </tr>
                </thead>
                <tbody>
                  {formattedBookings.map((booking) => (
                    <tr
                      key={booking.id}
                      onClick={() => handleSelectBooking(booking)}
                      style={{
                        cursor: 'pointer',
                        backgroundColor:
                          selectedBooking?.id === booking.id ? '#f0fdfa' : 'transparent',
                      }}
                    >
                      <td>{booking.code}</td>
                      <td>{booking.customerName}</td>
                      <td>{booking.serviceName}</td>
                      <td>{booking.address}</td>
                      <td>{booking.formattedTime}</td>
                      <td>
                        {Number(booking.totalPrice || 0).toLocaleString('vi-VN', {
                          style: 'currency',
                          currency: 'VND',
                        })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {selectedBooking && selectedContext !== 'schedule' && (
            <div className="panel" style={{ marginTop: '1.5rem' }}>
              <div className="panel-header">
                <div>
                  <h3>Đơn đã chọn: {selectedBooking.code}</h3>
                  <p className="text-muted">
                    {selectedBooking.customerName} · {selectedBooking.serviceName}
                  </p>
                </div>
              </div>
              <p>
                <strong>Địa chỉ:</strong> {selectedBooking.address}
              </p>
              <p>
                <strong>Thời gian:</strong> {selectedBooking.formattedTime}
              </p>
              <p>
                <strong>Chi phí:</strong>{' '}
                {Number(selectedBooking.totalPrice || 0).toLocaleString('vi-VN', {
                  style: 'currency',
                  currency: 'VND',
                })}
              </p>
              {claimError && <p className="form-error">{claimError}</p>}
              <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1rem', flexWrap: 'wrap' }}>
                <button
                  type="button"
                  className="btn-primary"
                  onClick={() => handleClaim(false)}
                  disabled={claimLoading}
                >
                  {claimLoading && !claimRequiresForce ? 'Đang nhận...' : 'Nhận đơn'}
                </button>
                {claimRequiresForce && (
                  <button
                    type="button"
                    className="btn-outline"
                    onClick={() => handleClaim(true)}
                    disabled={claimLoading}
                  >
                    {claimLoading ? 'Đang xác nhận...' : 'Nhận dù trùng lịch'}
                  </button>
                )}
                <button type="button" className="btn-text" onClick={clearSelection}>
                  Đóng
                </button>
              </div>
            </div>
          )}
        </section>
      </>
    )
  }

  return (
    <div className="dashboard-layout">
      <aside className="dashboard-sidebar">
        <div className="sidebar-brand">
          <span className="brand-dot" />
          <div>
            <p className="brand-title">Cleanify Staff</p>
            <small>Workspace</small>
        </div>
      </div>
      <nav className="sidebar-nav">
        {navLinks.map((item) => (
          <button
            key={item.key}
            type="button"
            className={`sidebar-link ${activeTab === item.key ? 'active' : ''}`}
            onClick={() => setActiveTab(item.key)}
          >
            {item.label}
          </button>
        ))}
      </nav>
      <div className="sidebar-footer">
        <LogoutButton onLogout={onLogout} />
      </div>
    </aside>

    <main className="dashboard-main">
      <header className="dash-header">
        <div>
          <p>Xin chào,</p>
          <h1>{user?.fullName || data.name || 'Nhân viên'}</h1>
        </div>
        <button type="button" className="btn-primary">
          Cập nhật trạng thái
        </button>
      </header>

      {renderMainContent()}
    </main>
  </div>
  )
}

export default StaffWorkspace
